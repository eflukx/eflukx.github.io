					BOGUS.EXE
				***************************


About BOGUS
This program was developed to generate web pages richly populated with bogus e-mail
addresses. It uses four "core" files, words.txt basewords.txt random.txt and html.txt
These files must be in the same directory (folder) as BOGUS.EXE

The wordlists may be edited at will, and you may add phrases to basewords.txt to make
the final web page look more "real". The maximum number of active lines in basewords.txt
is 250 - this is sufficient to generate complete nonsense pages, but with a "genuine"
look (for steenkin' spam-bots, anyway).

The html.txt file contains a number of domain extensions, and you may customise these.
The maximum number supported is 100.  These are in the form ...
.com
.co.uk
.org
.gov.it
... etc. (up to 100 domain extensions may be added, and will be selected at random)

# Comments and instructions are prefixed with a "hash" or "pound sign", and you must
# be careful that all comment lines start with "#"

As supplied, BOGUS comes with a database of 60,387 words, and these are used to create a
smaller file, random.txt.  A new random file should be created every so often to ensure
that e-mail addresses are not repeated - there are bound to be some repeats, but spam-bots
should not notice.

The opening and closing "tags" allow you to customise the page, and accept standard HTML
commands, such as <b>bold</b>, paragraph breaks, etc. They can also be used for links to
other pages (containing more bogus addresses :-)

				***************************
Let's all fight spam by polluting the spammers' mailing lists to the extent that they are
completely useless to the scum spammers or anyone else!
				***************************


License
The program is freeware, and may be re-distributed at no cost to anyone, anywhere.
The program may be disassembled, reverse engineered or re-written if you desire,
and redistributed in any format (please include suitable word lists though, to ensure
that appropriately random HTML pages can be created.

If you enjoy the ability to create web pages with huge numbers of randomly generated
e-mail addresses, then please send an e-mail rode@sound.au.com and let me know.


Disclaimer of Warranty
No warranty is given or implied for this software. You use it at your own risk absolutely
and agree to hold Rod Elliott and ESP (hereinafter known as ESP) harmless against any 
action that may be taken against you for your use of or inability to use the software.

Furthermore, you hold ESP harmless against any loss or damage you may incur (howsoever 
caused). Your use of the BOGUS program confirms your acceptance of these terms and 
conditions without reservation or recourse.

Every precaution has been taken to ensure that the software is virus free and will not 
cause harm to your system, however it is understood and accepted that all and any bugs,
errors in programming or other faults (regardless of whether ESP has been advised of the
existence of such bugs, faults or errors or not) are unintentional and you agree than no
action of any sort shall be taken against ESP for any loss or damage you may incur as the
direct or indirect result of your use of the software.


WARNING
It is inevitable that a program such as this will create the occasional address that is 
valid. This can be minimised by using the "random names" function, which will create 
e-mail user names that are a random number of characters (and numbers) in length - from
6 to 12 characters and digits.

Although valid user names are still possible, this will reduce the likelihood to a (small)
degree.

I apologise in advance to any person who finds him/herself on a spammer's list because of
the BOGUS program - this is absolutely not the intention, and hopefully the risk is small.

The risk may be reduced further by checking domain names or editing the file words.txt to
remove names that may be valid domains, but this is a very tedious exercise and should not
be needed.

