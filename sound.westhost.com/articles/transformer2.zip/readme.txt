How to use the exel sheet?

0. Purpose
This Exel-Sheet is made for convenient "linear PSU" design. This is a PSU made using a transformer, rectifier diodes and filtering capacitors. The load presented to the PSU is a resistor. The sheet was tested against SPICE simulations and has shown accuracy to about 2% or better.

However, since not all possible configurations can be checked it should always be verified by a subsequent SPICE 
simulation.


1. Assumptions
This Exel-Sheet tries to model the nonlinear behaviour of such a PSU with simple equations and estimations. The transformer is modelled as a nonideal voltage source, i.e. an ideal voltage soure plus series resistance. It uses only SI units (m,A,V, Ohm, etc.).

Four common circuits can be calculated:
-single coil transformer with diode bridge "Bridge"
-double coil transformer with diode bridge for each coil "d. Bridge", dual ouput voltage, very heavy load (1000W) 
-center tap two coil circuit with two diodes for single output  voltage "Center", only usefull for very low power and low voltage, less diode drop 
-center tap two coil circuit with for diodes for dual output "d. Center", for low to high output power until the highest, less diode losses than "d. Bridge"

Usally a given transformer is specified with Uneff (effective value of secondary voltage under full resistive load, and Pn (nominal output power with said resistive load) and loss factor f (ratio between U0eff and Uneff, U0eff beeing the effective value of output voltage with no load), and of course the primary effective voltage Unetz.

I.e.: U0eff=f*Uneff

Out of Pn and Uneff we get the load current In (In=Pn/Un). The series resistance is therefore 

(U0eff-Uneff)/Ineff=(f*Uneff-Uneff)/Ineff
=Uneff*(f-1)/In
=Uneff**2*(f-1)/Pn

the later is convenient because it uses only the usually given parameters. This applies also to transformers with several identical coils. It does not apply for additional auxilary windings and taps, which can have lower power spec and therefore more series resistance as perhaps expected.

The sheet works for one coil or two identical coils, due to the symmetry of the circuit and load situation the same current and voltage values will appear. Therefore they are only given once in the sheet.

Sadly, f is not given by many vendors. So the Exel-Sheet has some heuristic formula to determine f out of the transformer total power rating. This works from about 5 VA up to 1000 VA. This is no big science, but relates to the usual tradeoffs when winding tranformer coils. The value is valid for toroidal types, f is often lower for EI types. 

However, if you can obtain a datasheet with f, then do not use the heuristic value.

The Exel-Sheet does also inlcude mains voltage variation. In central Europe this is tending to +-10% of the nominal value, guaranteed at the house main power entry. Some additional wiring can be added to that (be it house installation or 
additional cables, perhaps during live shows). The transformed total mains resistance will simply add to the transformer series resistance.

The remaining interesting part of the formulas is derived by approximating the voltage sine waves with parabola, in order to get any analytic result. Unfortunately the resulting nonlinear equation can only be solved by program, I used an iteration approach in this Exel sheet.

The load is assumed to be a resistor. In reality this not always the case. Some circuits tend to be constant current drains (regulator plus electronic circuit). Others have variable current consumption (power amplifiers), but also there 
the current does not depend on PSU voltage. A starting point for the later cases is to make the delivered output power equal, i.e. choosing the output current and resistor in that way.

2. How to do it

The Exel sheet has a yellow title range. Below that on the left hand side we find explanations to the parameters, the salmon colored column shows the parameter name. The next column is commonly used for all four possible circuits, the next four colums cary the results and entries for each circuit individualy.

First you have to enter data into the white common fields. Each field must be filled. Most of this is very easy. You enter:

-the Si diode dropout voltage [Ud] (recommended 1V) 
-specify peak-to-peak ripple voltage under load [Ubrss] 
-the desired nominal output current [Ia] (together with output voltage  
 this will define the deliverd power) 
-the current form factor [alpha}. The transformer has to deliver current peaks instead sine AC current, the copper losses will be higher than nominal.

This makes it necessary to use a higher transformer nominal power. Underdimensioning can lead to

 1.: more than nominal copper loss 
 2.: enormous heat development in coil wires

Usally alpha is chosen to be 1.5 ... 2, even large overdimensioning is possible with modern toroid types, because idle losses ar still low.

Imax >> In means that in this PSU the peak current is much larger than in the situation where the transformer drives only a resistive load to the rated power. One should compute the RMS value from simulation to estimate the loss. Based on that choose alpha to be higher. 

-your desired nominal DC output voltage [Uaminn] (just to remember) 

-your desired minimum nominal output voltage [Uamin] this has to be higher than Uaminn because of wiring losses and mains power variation, if the mains variation to lower is perhaps 10%, give Uamin 10% more, as a starting  point 
-the assumed wiring length from mains house entry to your transformer [L], in in normal house this can be 10 - 20 m, in a big hall this can be 100m 
-the mains wiring cross section area [A], typical 1.5 mm2 -the mains nominal effective voltage [Unetz] (e.g. 110V or 230V) 
-the mains AC frequency [fn] (e.g. 50Hz or 60Hz) 
-the mains tolerance upper value [tolup] (e.g. 10% by law in Germany,  meaning 230V and up to 253V) 
-the mains tolerance lower value [toloe] (e.g. -10% by law in Germany, meaning 230V and down to 207V)

You are done with the common data. Now you can decide which circuit column you need to use. It is only neccessary to fill in that column, but it is also possible to use serval or all in parallel for study or comparison.

Now the Exel sheet knows the output power [Pa], nominal power per coil [Pns], and the total nominal transformer power [Pn]. The heuristic formula can therefore suggest a value for the torroid loss factor [f]. If you have no better data, enter this value in the white field "actual transformer loss factor". Now you have completed all white fields, you are nearly done.

In the last step you solve the nonlinear equation by manual iteration. You enter a nominal coil voltage  [Uneff] (pink field) and change it, until the relative iteration difference [r] (light blue) is 0.0% (or near to that). In this case the single coil output voltage under load with infinitely large capacitor [Ua8] will match the iterated single coil output voltage [Uaber] (darker blue).

Now you have solved the equation, but is the worst case voltage [Ua-] as expected? You should compare this lowest per coil output voltage under load [Ua-] with your intended desired minimum nominal output voltage [Uaminn]. If [Ua-] is too low, the circuit will have too low voltage in case of low mains voltage, a longer than expected cable can add to that.

This makes perhaps no difference for a power amp, since a few % amplitude loss is not audible. In the case of a subsequent voltage regulator a too low voltage will simply mean loss of regulation with perhaps additional artefacts, this is clearly not aceptable. Give more [Uamin] in such a case, and iterate again.

Take care: this can influence the power, so the current [Ia] may need some adjustment, too. Finally power change can change loss factor [f], so this has also to be adapted. If the initial guess was good enough, little or no modification needs to be made on that side.

So now you are done. You should take the relevant data from the sheet (U0, Un, Pn, f) and do a SPICE simulation to verify. A second computation is always good, since you are going to spend a lot of money for a PSU!

3. What else does the sheet tell you

It not only tells you Uneff, Pn, f, Unetz to order your transformer, it also tells you the size of the filter capacitors Cl, and Ua0+, this idle output voltage plus tolerance tells you about the voltage stress these and other devices connected to your PSU have to take.

Imax is the periodic peak current in the transformer windings and diodes, so it will tell you something about fuse stress and diode stress.

The total rectifier loss power Pg and the maximum diode reverse voltage Usper+ will also help to buy the right rectifier.

All the devices need not only cope with the rated voltage stress, but even more has to be considered because of possible mains transients. A factor of 2 overdimensioning is not too expensive in most cases, an exploded cap or whole PSU plus circuit certainly is.

If your output voltage is so high that voltage overdimensioning is not possible, primary side varistors should be used to handle transients. They should be used anyway.

4. Explanation of Parameters

Ud : Input : Si diode voltage at high current (change this voltage for using tubes, or special diodes) 
Ubrss : Input : max. allowed typical peak-peak ripple voltage 
Ia : Input : desired nom. DC output current per coil (ohmic load) 
alpha : Input : current form factor (RMS > average!) 1.5 ... 2 
Uaminn : Input : desired minimum nominal output voltage, to remember your goal 
Uamin : Input : minimum nominal output voltage for computation 
rho : constant : Copper specific resistance 
L : Input : line lenght from house mains entry to transformer,one way 
A : Input : wire cross section area of this line with lenght L 
Rk : computed : resulting line resistance for both ways 
Unetz : Input : nominal effective mains voltage 
fn : Input : mains frequency 
tolup : Input : upper limit of mains voltage variation 
tolow : input : lower limit of mains voltage variation
�: computed : transformation ratio
�2 : computed : impedance transformation ratio 
Rks : computed : line resistance transformed to secondary, usually very small 
f : Input : actual used transformer loss factor 
f : computed : heuristical determined loss factor, no large difference with actually used, unless reason for this is known!
U0eff : computed : nominal sine AC effective transformer voltage per coil with no load 
Ineff : computed : nominal sine Ac effective transformer current per coil 
In : computed : nominal sine AC transformer peak current per coil, compare with Imax for a hint for alpha (value is doubled in case of Center circuit, since only one coil at a time is conducting in this rectifier circuit, while both are conducting with pure resistive load) 
Imax : computed : secondary peak current per coil, also current through diodes, compare with In to avoid core saturation 
Idm : computed : average diode current 
Pa : computed : total power per winding delivered to load resistor 
Pn : computed : total transformer power, including rectifier power, load power, all coils and factor alpha 
Pns : computed : Pn divided by number of coils (1, 2)
Ua0+ : computed : idle voltage on capacitor, including mains upper Ua0+ tolerance
Ua0 : computed : idle voltage on capacitor, nominal mains
Ua0- : computed : idle voltage on capacitor, including mains lower tolerance
Usper+ : computed : idle voltage stress on diodes, including mains upper usper+ tolerance
Ua8+ : computed : infinite capacitor voltage with load and mains upper Ua8+ tolerance, can be used to estimate e.g. amplifier losses
Ua-: computed : capacitor voltage (capacitance value Cl), including mains lower tolerance and line losses and ripple, lowest instantaneous value
Ua8 : computed : infinite capacitor voltage with load, nominal 
Ua8ber : computed : tryed infinite capacitor voltage with load 
r : computed : ratio between Ua8 and Ua8ber in %, error of iteration, minimize to 0.0!
Uneff : iteration input : nominal effective transformer secondary voltage, this value must be iterated to minimize r 
Rv : computation : load resistor that would draw Ia with infinite capacitor 
Ri : computation : transformer resistance for each coil
Ri+main : computation : effective transformer resistance for each coil, including line losses 
Cl : computed : capacitor size for give ripple, frequency, load 
Pd : computed : power loss per diode 
Pg : computed : total power loss, sum for all diodes 


 



