                                                 GENERAL INFORMATION

______________________________________________________________________
Sending the Encrypted File

The file is saved when you ckick on [Save] or [Save+Print], and is of the form ...

	99999.esp (where 9 represents any digit)

It is *not* sent automatically - you must create an e-mail to rode@sound.au.com and send the file as an attachment.  It *must not* be sent 'in-line' or it will be corrupted.

The encrypted output file is located in the same folder as the file 'ORDER.EXE'

______________________________________________________________________
Screen Resolution

The program is optimised for 1024 x 768 (or greater) screen resolution. If you do not see the [Read Me], [Save], [Save+Print], [Clear] and [Exit] buttons at the bottom of the form, then your screen is too small.

Please re-size your screen (at least temporarily) to use the form.

______________________________________________________________________
Load Errors

IMPORTANT - The support files needed are shown below ...

If you get an error message trying to run this program, you probably do not have the Microsoft VB6 run-time library installed on your machine.  Go to ...

    http://www.softwarepatch.com/windows/vbrun6download.htm

The download should start automatically.  The file is an executable.  Save it to your desktop, and double-click the file to install the VB6 components.  The downloaded file may then be deleted.

You may also need a copy of MSINET.OCX if it's not on your machine ... 

	http://sound.au.com/msinet.ocx

Just select 'Save to Disk'.  Then, copy (or move) it into the c:\windows\system32 folder. Next, open the run dialog 
box using "Start > Run..." and enter  ...

	regsvr32 msinet.ocx

If you are using Windows Vista or Windows 7, you need to save the file to c:\windows\sysWOW64 for 64 bit versions. Then, open the Start Menu and find 
Command Prompt, right click it, then select "run as administrator". A "DOS" window will open, then type

	regsvr32 msinet.ocx
______________________________________________________________________
Pricelist

The version and date of the pricelist is shown at the top right of the order form. Please compare this with ...

	http://sound.westhost.com/purchase.htm#encode

The version you use must match the version on the website.  ESP reserves the right to correct prices if the most current pricelist is not used.

______________________________________________________________________
About

ORDER.EXE is a small utility designed to encrypt an order (including credit card details) for safe transmission via the Internet.  While no claim is made that the encryption is unbreakable, this method of card detail transmission is nevertheless safer than almost any other method - possibly including fax.

The decryption software is exclusive to ESP, and is used on only one PC, and is on a secure machine to prevent unauthorised use or access.

The latest version checks the credit card number, and will not allow you to leave the field until it is correct.  If you just want to check prices, leave the credit card number field blank.

______________________________________________________________________
Security

The encryption used is one-way, so there is no way for you (or anyone else) to decrypt the data once it has been saved.  Unlike "Public Key Encryption" (such as PGP and similar), this provides a high level of security, as there is no password used - the encryption algorithm is hard coded, and relies heavily on identical coding and decoding programs at each end of the process.

Like anything, it is possible for the method I have used to be hacked, however a similar program I wrote some time ago proved to be too much for an experienced hacker, who eventually gave up in disgust.

______________________________________________________________________
Warranty

No warranty is expressed or implied as to the ultimate security of the software or the encrypted data.  It is infinitly more secure than a standard e-mail, and a great deal more secure than any of the various methods that have been suggested elsewhere, such as embedding the card details in a nursery rhyme or similar.

Use of the program is subject to the understanding that the user accepts full responsibility for any loss (howsoever caused) by using the software.

Whilst every precaution has been taken to assure that the program is secure and virus free, ESP can accept no responsibility for loss of data, credit card details or any financial loss.  For what it's worth, there has not been a single breach of security since the first release of the program in 2002.

          *** If you do not accept these conditions, you must not use the program. ***

______________________________________________________________________
Copyright

The program ORDER.EXE is copyright (c) 2002 Rod Elliott (Elliott Sound Products), and may not be de-compiled, reverse engineered or modified in any way. The program is provided as a convenience for ESP customers, and may not be sold or offered to any other party for any reason other than for the purchase of ESP circuit boards or other products.  Copyright is extended to all later versions after the original 2002 release.



