/*------------------------------------------------------------------------/
/  MARYEX-OB OLED display control module
/-------------------------------------------------------------------------/
/
/  Copyright (C) 2011, ChaN, all right reserved.
/
/ * This software is a free software and there is NO WARRANTY.
/ * No restriction on use. You can use, modify and redistribute it for
/   personal, non-profit or commercial products UNDER YOUR RESPONSIBILITY.
/ * Redistributions of source code must retain the above copyright notice.
/
/-------------------------------------------------------------------------*/

#include <string.h>
#include "LPC1100.h"
#include "disp.h"

#define _USE_DBCS	0	/* 0:ANK only, 1:Enable kanji chars */

#define CS_LOW()	{ GPIO0MASKED[1<<2] = (0<<2); }
#define CS_HIGH()	{ while (SSP0SR & 0x10); GPIO0MASKED[1<<2] = (1<<2); }

#define	CMD_WR(d)	{ while (!(SSP0SR & 2)); SSP0DR = (d); }			/* Write a command byte to the OLED */
#define	DATA_WRB(d)	{ while (!(SSP0SR & 2)); SSP0DR = 0x100 | (d); }	/* Write a data byte to the OLED */
#define	DATA_WPX(d)	{ while (!(SSP0SR & 2)); SSP0DR = 0x100 | (d >> 8); while (!(SSP0SR & 2)); SSP0DR = 0x100 | (d); }	/* Write a pixel to the OLED */


static int MaskT, MaskL, MaskR, MaskB;	/* Active drawing area */
static int LocX, LocY;			/* Current dot position */
static uint32_t ChrColor;		/* Current character color ((bg << 16) + fg) */
static const uint8_t *FontS;	/* Current font (ANK) */
#if _USE_DBCS
static const uint8_t *FontD;	/* Current font (Kanji) */
static uint8_t Sjis1;			/* Sjis leading byte */
#endif

/* Import FONTX2 files as byte array */
IMPORT_BIN_PART("fnt6x8.fnt", 0, 17+8*128, Fnt6x8);		/* const uint8_t Fnt6x8[17+8*128]; */



/*-----------------------------------------------------*/
/* Set rectangular area to be transferred              */

static
void disp_setrect (
	int left,		/* Left end (0 to 127) */
	int right,		/* Right end (0 to 127, >= left) */
	int top,		/* Top end (0 to 127) */
	int bottom		/* Bottom end (0 to 127, >= top) */
)
{
	CMD_WR(0x15);	/* Set H range */
	DATA_WRB(left); DATA_WRB(right);

	CMD_WR(0x75);	/* Set V range */
	DATA_WRB(top); DATA_WRB(bottom); 

	CMD_WR(0x5C);	/* Ready to receive pixel data */
}



/*-----------------------------------------------------*/
/* Initialize display module                           */

void disp_init (void)
{
	static const uint8_t initdata[] = {	/* UG-2828GDEDF11 initialization data */
		1, 0xA4,		/* All OFF */
		2, 0xFD, 0x12,	/* Unlock command */
		2, 0xFD, 0xB1,	/* Unlock command */
		1, 0xAE,		/* Sleep mode ON */
		2, 0xB3, 0xE1,	/* Freeuqncy = 0xE, Divider = 0x1 */
		2, 0xCA, 0x7F,	/* Mux ratio = 127 */
		2, 0xA2, 0x00,	/* Display offset = 0 */
		2, 0xA1, 0x00,	/* Display start line = 0 */
		2, 0xA0, 0x74,	/* 65k color, COM split, Reverse scan, Color seq = C-B-A */
		2, 0xB5, 0x00,	/* GPIO0,1 disabled */
		2, 0xAB, 0x01,	/* Enable internal regurator */
		4, 0xB4, 0xA0, 0xB5, 0x55,	/* External VSL */
		4, 0xC1, 0xC8, 0x80, 0xC8,	/* Contrast for A, B, C */
		2, 0xC7, 0x0A,	/* Master contrast = 10 */
		64, 0xB8, 1, 2, 2, 3, 4, 4, 5, 6, 7, 9, 10, 11, 13, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 37, 39, 42, 44, 47, 50, 53, 56, 59, 62, 65, 68, 71, 75, 78, 82, 85, 89, 93, 96, 100, 104, 108, 112, 116, 121, 125, 129, 134, 138, 143, 147, 152, 156, 161, 166, 171, 176, 181,  /* Gamma 1.6 */
		2, 0xB1, 0x32,	/* OLED driving phase length */
		4, 0xB2, 0xA4, 0x00, 0x00,
		2, 0xBB, 0x17,	/* Pre-charge voltage */
		2, 0xB6, 0x01,	/* 2nd pre-charge period */
		2, 0xBE, 0x05,	/* COM deselect voltage */
		1, 0xA6,		/* Reset to normal display */
		0
	};
	int n;
	const uint8_t *p;
	uint8_t cl;


	/* Initialize contorl port (SPI0) */
	GPIO0DIR |= _BV(2)|_BV(9)|_BV(6);	/* Set CS#, MOSI0 and SCK0 as output */
	GPIO1DIR |= _BV(8)|_BV(4);			/* Set RES#, OLED_POWER as output */
	GPIO1MASKED[1<<4] = (0<<4);			/* OLED_POWER = L */

	/* Reset OLED module */
	GPIO0MASKED[1<<2] = (1<<2);			/* CS# = H */
	GPIO1MASKED[1<<8] = (0<<8);			/* RES# = L */
	for (n = 0; n < 10000; n++) GPIO1MASKED[1<<8];
	GPIO1MASKED[1<<8] = (1<<8);			/* RES# = H */
	for (n = 0; n < 1000; n++) GPIO1MASKED[1<<8];

	/* Initialize SPI0 module and attach it to the I/O pad */
	__set_SYSAHBCLKCTRL(PCSSP0, 1);
	PRESETCTRL |= _BV(0);	/* Release SSP0 reset */
	SSP0CLKDIV = 1;			/* PCLK = sysclk */
	SSP0CPSR = 0x02;		/* fc=PCLK/2 */
	SSP0CR0 = 0x0008;		/* Mode-0, 9-bit */
	SSP0CR1 = 0x02;			/* Enable SPI */
	IOCON_SCK_LOC = 0x02;	/* SCK0 location = PIO0_6 */
	IOCON_PIO0_6 = 0x02;	/* SCK0 */
	IOCON_PIO0_9 = 0x01;	/* MOSI0 */
	IOCON_PIO0_8 = 0x11;	/* MISO0/pull-up */

	/* Send initialization parameters */
	CS_LOW();
	p = initdata;
	while ((cl = *p++) != 0) {
		CMD_WR(*p++); cl--;
		while (cl--) DATA_WRB(*p++);
	}
	CS_HIGH();

	/* Clear screen and Display ON */
	disp_mask(0, DISP_XS - 1, 0, DISP_YS - 1);
	disp_fill(0, DISP_XS - 1, 0, DISP_YS - 1, C_BLACK);
	CS_LOW();
	CMD_WR(0xAF);
	CS_HIGH();

	GPIO1MASKED[1<<4] = (1<<4);			/* OLED_POWER = H */
}



/*-----------------------------------------------------*/
/* Set active drawing area                             */
/*-----------------------------------------------------*/
/* The mask feature affects only disp_fill, disp_box,  */
/* disp_pset, disp_lineto and disp_blt function        */

void disp_mask (
	int left,		/* Left end of active window (0 to DISP_XS-1) */
	int right,		/* Right end of active window (0 to DISP_XS-1, >=left) */
	int top,		/* Top end of active window (0 to DISP_YS-1) */
	int bottom		/* Bottom end of active window (0 to DISP_YS-1, >=top) */
)
{
	if (left >= 0 && right < DISP_XS && left <= right && top >= 0 && bottom < DISP_XS && top <= bottom) {
		MaskL = left;
		MaskR = right;
		MaskT = top;
		MaskB = bottom;
	}
}



/*-----------------------------------------------------*/
/* Draw a solid rectangular                            */

void disp_fill (
	int left,		/* Left end (-32768 to 32767) */
	int right,		/* Right end (-32768 to 32767, >=left) */
	int top,		/* Top end (-32768 to 32767) */
	int bottom,		/* Bottom end (-32768 to 32767, >=top) */
	uint16_t color	/* Box color */
)
{
	uint32_t n;


	if (left > right || top > bottom) return; 	/* Check varidity */
	if (left > MaskR || right < MaskL  || top > MaskB || bottom < MaskT) return;	/* Check if in active area */

	if (top < MaskT) top = MaskT;		/* Clip top of rectangular if it is out of active area */
	if (bottom > MaskB) bottom = MaskB;	/* Clip bottom of rectangular if it is out of active area */
	if (left < MaskL) left = MaskL;		/* Clip left of rectangular if it is out of active area */
	if (right > MaskR) right = MaskR;	/* Clip right of rectangular if it is out of active area */

	CS_LOW();	/* Select display module */
	disp_setrect(left, right, top, bottom);
	n = (uint32_t)(right - left + 1) * (uint32_t)(bottom - top + 1);
	do { DATA_WPX(color); } while (--n);
	CS_HIGH();	/* Deselect display module */
}



/*-----------------------------------------------------*/
/* Draw a hollow rectangular                           */

void disp_box (
	int left,		/* Left end (-32768 to 32767) */
	int right,		/* Right end (-32768 to 32767, >=left) */
	int top,		/* Top end (-32768 to 32767) */
	int bottom,		/* Bottom end (-32768 to 32767, >=top) */
	uint16_t color	/* Box color */
)
{
	disp_fill(left, left, top, bottom, color);
	disp_fill(right, right, top, bottom, color);
	disp_fill(left, right, top, top, color);
	disp_fill(left, right, bottom, bottom, color);
}



/*-----------------------------------------------------*/
/* Draw a dot                                          */

void disp_pset (
	int x,		/* X position (-32768 to 32767) */
	int y,		/* Y position (-32768 to 32767) */
	uint16_t color	/* Pixel color */
)
{
	if (x >= MaskL && x <= MaskR && y >= MaskT && y <= MaskB) {
		CS_LOW();			/* Select display module */
		CMD_WR(0x15);		/* Set H position */
		DATA_WRB(x); DATA_WRB(x);
		CMD_WR(0x75);		/* Set V position */
		DATA_WRB(y); DATA_WRB(y); 
		CMD_WR(0x5C);		/* Put a pixel */
		DATA_WPX(color);
		CS_HIGH();			/* Deselect display module */
	}
}



/*-----------------------------------------------------*/
/* Set current dot position for disp_lineto            */

void disp_moveto (
	int x,		/* X position (-32768 to 32767) */
	int y		/* Y position (-32768 to 32767) */
)
{
	LocX = x;
	LocY = y;
}



/*-----------------------------------------------------*/
/* Draw a line from current position                   */

void disp_lineto (
	int x,		/* X position for the line to (-32768 to 32767) */
	int y,		/* Y position for the line to (-32768 to 32767) */
	uint16_t col	/* Line color */
)
{
	int32_t xr, yr, xd, yd;
	int ctr;


	xd = x - LocX; xr = LocX << 16; LocX = x;
	yd = y - LocY; yr = LocY << 16; LocY = y;

	if ((xd < 0 ? 0 - xd : xd) >= (yd < 0 ? 0 - yd : yd)) {
		ctr = (xd < 0 ? 0 - xd : xd) + 1;
		yd = (yd << 16) / (xd < 0 ? 0 - xd : xd);
		xd = (xd < 0 ? -1 : 1) << 16;
	} else {
		ctr = (yd < 0 ? 0 - yd : yd) + 1;
		xd = (xd << 16) / (yd < 0 ? 0 - yd : yd);
		yd = (yd < 0 ? -1 : 1) << 16;
	}
	xr += 1 << 15;
	yr += 1 << 15;
	do {
		disp_pset(xr >> 16, yr >> 16, col);
		xr += xd; yr += yd;
	} while (--ctr);

}



/*-----------------------------------------------------*/
/* Copy image data to the display                      */

void disp_blt (
	int left,		/* Left end (-32768 to 32767) */
	int right,		/* Right end (-32768 to 32767, >=left) */
	int top,		/* Top end (-32768 to 32767) */
	int bottom,		/* Bottom end (-32768 to 32767, >=right) */
	const uint16_t *pat	/* Pattern data */
)
{
	int yc, xc, xl, xs;
	uint16_t pd;


	if (left > right || top > bottom) return; 	/* Check varidity */
	if (left > MaskR || right < MaskL  || top > MaskB || bottom < MaskT) return;	/* Check if in active area */

	yc = bottom - top + 1;			/* Vertical size */
	xc = right - left + 1; xs = 0;	/* Horizontal size and skip */

	if (top < MaskT) {		/* Clip top of source image if it is out of active area */
		pat += xc * (MaskT - top);
		yc -= MaskT - top;
		top = MaskT;
	}
	if (bottom > MaskB) {	/* Clip bottom of source image if it is out of active area */
		yc -= bottom - MaskB;
		bottom = MaskB;
	}
	if (left < MaskL) {		/* Clip left of source image if it is out of active area */
		pat += MaskL - left;
		xc -= MaskL - left;
		xs += MaskL - left;
		left = MaskL;
	}
	if (right > MaskR) {	/* Clip right of source image it is out of active area */
		xc -= right - MaskR;
		xs += right - MaskR;
		right = MaskR;
	}

	CS_LOW();	/* Select display module */
	disp_setrect(left, right, top, bottom);	/* Set rectangular area to fill */
	do {	/* Send image data */
		xl = xc;
		do {
			pd = *pat++;
			DATA_WPX(pd);
		} while (--xl);
		pat += xs;
	} while (--yc);
	CS_HIGH();	/* Deselect display module */
}



/*-----------------------------------------------------*/
/* Set current character position for disp_putc        */

void disp_locate (
	int col,	/* Column position */
	int row		/* Row position */
)
{
	if (FontS) {	/* Pixel position is calcurated with size of single byte font */
		LocX = col * FontS[14];
		LocY = row * FontS[15];
#if _USE_DBCS
		Sjis1 = 0;
#endif
	}
}



/*-----------------------------------------------------*/
/* Register text font                                  */

void disp_font_face (
	const uint8_t *font	/* Pointer to the font structure in FONTX2 format */
)
{
	if (!memcmp(font, "FONTX2", 6)) {
#if _USE_DBCS
		if (font[16] != 0)
			FontD = font;
		else
#endif
			FontS = font;
	}
}



/*-----------------------------------------------------*/
/* Set current text color                              */

void disp_font_color (
	uint32_t color	/* (bg << 16) + fg */
)
{
	ChrColor = color;
}



/*-----------------------------------------------------*/
/* Put a text character                                */

void disp_putc (
	uint8_t chr		/* Character to be output (kanji chars are given in two disp_putc sequence) */
)
{
	const uint8_t *fnt;;
	uint8_t b, d;
	uint16_t dchr;
	uint32_t col;
	int h, wc, w, wb, i, fofs;


	if ((fnt = FontS) == 0) return;	/* Exit if no font registerd */

	if (chr < 0x20) {	/* Processes the control character */
#if _USE_DBCS
		Sjis1 = 0;
#endif
		switch (chr) {
		case '\n':	/* LF */
			LocY += fnt[15];
			/* follow next case */
		case '\r':	/* CR */
			LocX = 0;
			return;
		case '\b':	/* BS */
			LocX -= fnt[14];
			if (LocX < 0) LocX = 0;
			return;
		case '\f':	/* FF */
			disp_fill(0, DISP_XS - 1, 0, DISP_YS - 1, 0);
			LocX = LocY = 0;
			return;
		}
	}

	/* Exit if current position is out of screen */
	if ((unsigned int)LocX >= DISP_XS || (unsigned int)LocY >= DISP_YS) return;

#if _USE_DBCS
	if (Sjis1) {	/* This is sjis trailing byte */
		uint16_t bchr, rs, re;
		int ri;

		dchr = Sjis1 * 256 + chr; 
		Sjis1 = 0;
		fnt = FontD;	/* Switch to double byte font */
		i = fnt[17];	/* Number of code blocks */
		ri = 18;		/* Start of code block table */
		bchr = 0;		/* Number of chars in previous blocks */
		while (i) {		/* Find the code in the code blocks */
			rs = fnt[ri + 0] + fnt[ri + 1] * 256;	/* Start of a code block */
			re = fnt[ri + 2] + fnt[ri + 3] * 256;	/* End of a code block */
			if (dchr >= rs && dchr <= re) break;	/* Is the character in the block? */
			bchr += re - rs + 1; ri += 4; i--;		/* Next code block */
		}
		if (!i) {	/* Code not found */
			LocX += fnt[14];		/* Put a transparent character */
			return;
		}
		dchr = dchr - rs + bchr;	/* Character offset in the font area */
		fofs = 18 + fnt[17] * 4;	/* Font area start address */
	} else {
		/* Check if this is sjis leading byte */
		if (FontD && (((uint8_t)(chr - 0x81) <= 0x1E) || ((uint8_t)(chr - 0xE0) <= 0x1C))) {
			Sjis1 = chr;	/* Next is sjis trailing byte */
			return;
		}
#endif
		dchr = chr;
		fofs = 17;		/* Font area start address */
#if _USE_DBCS
	}
#endif

	h = fnt[15]; w = fnt[14]; wb = (w + 7) / 8;	/* Font size: height, dot width and byte width */
	fnt += fofs + dchr * wb * h;				/* Goto start of the bitmap */

	if (LocX + w > DISP_XS) w = DISP_XS - LocX;	/* Clip right of font face at right edge */
	if (LocY + h > DISP_YS) h = DISP_YS - LocY;	/* Clip bottom of font face at bottom edge */

	CS_LOW();	/* Select display module */
	disp_setrect(LocX, LocX + w - 1, LocY, LocY + h - 1);
	d = 0;
	do {
		wc = w; b = i = 0;
		do {
			if (!b) {		/* Get next 8 dots */
				b = 0x80;
				d = fnt[i++];
			}
			col = ChrColor;
			if (!(b & d)) col >>= 16;	/* Select color, BG or FG */
			b >>= 1;		/* Next bit */
			DATA_WPX(col);	/* Put the color */
		} while (--wc);
		fnt += wb;		/* Next raster */
	} while (--h);
	CS_HIGH();	/* Deselect display module */

	LocX += w;	/* Update current position */
}


