#ifndef _UART0
#define _UART0
#include "LPC1100.h"

void uart0_init (void);
int uart0_test (void);
void uart0_putc (uint8_t);
uint8_t uart0_getc (void);

#endif

