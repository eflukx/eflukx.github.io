/*------------------------------------------------------------------------/
/  Ball in the Liquid                                                     /
/-------------------------------------------------------------------------/
/
/  Copyright (C) 2011, ChaN, all right reserved.
/
/ * This software is a free software and there is NO WARRANTY.
/ * No restriction on use. You can use, modify and redistribute it for
/   personal, non-profit or commercial products UNDER YOUR RESPONSIBILITY.
/ * Redistributions of source code must retain the above copyright notice.
/
/-------------------------------------------------------------------------*/


#include "LPC1100.h"
#include "uart.h"
#include "iic.h"
#include "disp.h"
#include "xprintf.h"


extern const uint8_t ball_img[4][4][9 * 9];	/* 8x8 dot ball image in 4x resolution */

char Line[80];	/* Console input buffer */

volatile uint16_t Flag;	/* Discrete approximation timing flag (b0:calc, b1:disp) */

const int32_t LiqDen = 0x10000, MagGravity = 30;
int32_t BallDen = 0xA0000, BallCor = 0x8000, LiqDrag = 0x8000;	/* Physical properties */
int32_t LocBall[2], VelBall[2];	/* Current ball position and velocity {x, y} */
volatile int32_t Grav[2];		/* Captured gravity {x, y} */
const int32_t Wall[2][2] = {{(58 * 8 + 7) << 16, -59 * 8 << 16}, {(58 * 8 + 7) << 16, -59 * 8 << 16}};	/* Size of stage */

volatile I2CCTRL I2cCtrl;		/* Control structure for I2C transaction */
volatile uint8_t I2cBuff[6];	/* I2C read/write buffer */



/*--------------------------------------------------------------*/
/* 500Hz interval timer                                         */
/*--------------------------------------------------------------*/

void SysTick_Handler (void)
{
	static int div;


	Flag |= 1;			/* Discrete processing timing (500pps) */

	if (++div >= 5) {	/* Display update rate (100fps) */
		Flag |= 2;
	}
}



/*--------------------------------------------------------------*/
/* Notification of end of I2C transaction                       */
/*--------------------------------------------------------------*/

void i2c_eot (
	int stat	/* I2C transaction status */
)
{
	if (stat == I2C_SUCCEEDED) {
		Grav[0] = 0 - (int32_t)(int8_t)I2cBuff[2] * MagGravity;	/* Update gravity data */
		Grav[1] = (int32_t)(int8_t)I2cBuff[4] * MagGravity;
	}
}



/*--------------------------------------------------------------*/
/* MEMS data ready interrupt                                    */
/*--------------------------------------------------------------*/
/* Called on rising edge of MEMS INT signal                     */

void PIO_1_IRQHandler (void)
{
	GPIO1IC = _BV(9);	/* Clear P1.9 irq */

	if (I2cCtrl.stat) {
		I2cCtrl.ncmd = 1; I2cCtrl.cmd[0] = 0xA7;	/* Read register 0x27-0x2B into I2cBuff */
		I2cCtrl.dir = I2C_READ;
		I2cCtrl.ndata = 6; I2cCtrl.data = (uint8_t*)I2cBuff;	/* Read data into I2cBuff */
		I2cCtrl.eotfunc = i2c_eot;
		i2c0_start(&I2cCtrl);		/* Initiate to read acceleration data from MEMS */
	}
}



/*--------------------------------------------------------------*/
/* Input user command                                           */
/*--------------------------------------------------------------*/

static
int proc_input (void)
{
	static int i = -1;
	uint8_t c;


	if (i < 0) {
		xputc('>');
		i = 0;
	}
	if (uart0_test()) {
		c = uart0_getc();
		if (c == '\r') {
			Line[i] = 0;
			xputc('\n');
			i = -1;
			return 1;
		}
		if (c == '\b' && i) {
			xputc(c);
			i--;
		}
		if (c >= ' ' && i < (int)sizeof(Line) - 1) {
			xputc(c);
			Line[i++] = c;
		}
	}
	return 0;
}



/*--------------------------------------------------------------*/
/* Get value of a fixed point value from string                 */
/*--------------------------------------------------------------*/

static
int xatop (
	char** str,
	long* res
)
{
	long i, f, d;
	unsigned char c, s = 0;


	*res = 0;

	while ((c = **str) == ' ') (*str)++;	/* Skip leading spaces */
	if (c == '-') {		/* negative? */
		s = 1;
		c = *(++(*str));
	}
	i = 0;
	if (c != '.') {
		while (c >= '0' && c <= '9') {
			i = i * 10 + c - '0';
			c = *(++(*str));
		}
	}
	f = 0;
	if (c == '.') {
		d = 10000;
		for (;;) {
			c = *(++(*str));
			if (c < '0' || c > '9') break;
			f += d * (c - '0');
			d /= 10;
		}
		f = f * 2048;
		f = f / 3125 + ((f % 3125 >= 3125 / 2) ? 1 : 0);
	}
	if (c > ' ') return 0;
	if (i > 32767) i = 32767;
	i <<= 16;
	i |= f;
	if (s) i = 0 - i;
	*res = i;

	return 1;
}



/*--------------------------------------------------------------*/
/* Put ball on the screen                                       */
/*--------------------------------------------------------------*/

static
void put_ball (
	int x,	/* x position (0..119*4-1) */
	int y	/* y position (0..119*4-1) */
)
{
	static const uint16_t gs[17] = {	/* Occupation of lit pix in the 4x4 area -> pixel value */
		RGB16(  0,  0,  0), RGB16( 73, 73, 73), RGB16(100,100,100), RGB16(120,120,120),
		RGB16(136,136,136), RGB16(151,151,151), RGB16(164,164,164), RGB16(175,175,175),
		RGB16(186,186,186), RGB16(196,196,196), RGB16(206,206,206), RGB16(215,215,215),
		RGB16(224,224,224), RGB16(232,232,232), RGB16(240,240,240), RGB16(247,247,247),
		RGB16(255,255,255)
	};
	static int xv = -100, yv = -100;
	uint16_t dot[9 * 9], *dp = dot;
	const uint8_t *img = ball_img[y % 4][x % 4];
	int i;


	for (i = 0; i < 9 * 9; i++)	/* Create anti-aliased grayscale image */
		*dp++ = gs[*img++];

	x = x / 4 - 4; y = y / 4 - 4;		/* Adjust ball offset */

	disp_blt(x, x + 8, y, y + 8, dot);	/* Put ball */

	/* Erase garbage */
	if (x <= xv - 9 || x >= xv + 9 || y <= yv - 9 || y >= yv + 9) {
		disp_fill(xv, xv + 8, yv, yv + 8, RGB16(0,0,0));
	} else {
		if (x > xv) disp_fill(xv, x - 1, yv, yv + 8, RGB16(0,0,0));
		if (x < xv) disp_fill(x + 9, xv + 8, yv, yv + 8, RGB16(0,0,0));
		if (y > yv) disp_fill(xv, xv + 8, yv, y - 1, RGB16(0,0,0));
		if (y < yv) disp_fill(xv, xv + 8, y + 9, yv + 8, RGB16(0,0,0));
	}

	xv = x; yv = y;
}



/*--------------------------------------------------------------*/
/* Discrete approximation of behavior of ball                   */
/*--------------------------------------------------------------*/

void proc_ball (void)
{
	int i;
	int16_t f = Flag;
	int32_t p;
	int64_t v;


	if (f & 1) {
		__disable_irq();
		Flag &= ~1;
		__enable_irq();

		for (i = 0; i < 2; i++) {
			v = VelBall[i];
			v += (int64_t)(BallDen - LiqDen) * Grav[i] / BallDen;
			v -= (v * ((v < 0) ? 0 - v : v) >> 16) * (LiqDrag >> 8) / BallDen;

			p = LocBall[i] + v;
			if (p > Wall[i][0]) {
				p = Wall[i][0];
				v = ((0 - v) * (int64_t)BallCor) >> 16;
			}
			if (p < Wall[i][1]) {
				p = Wall[i][1];
				v = ((0 - v) * (int64_t)BallCor) >> 16;
			}
			VelBall[i] = v;
			LocBall[i] = p;
		}

		if (f & 2) {
			__disable_irq();
			Flag &= ~2;
			__enable_irq();
			put_ball(((LocBall[0] / 8) >> 14) + 64 * 4, ((LocBall[1] / 8) >> 14) + 64 * 4);
		}
	}
}



/*--------------------------------------------------------------*/
/* Show current pysical properties                              */
/*--------------------------------------------------------------*/

void disp_parms (void)
{
	xprintf("Density(d) = %u.%05u\n", BallDen >> 16, (BallDen & 0xFFFF) * 3125 / 2048);
	xprintf("COR(c) = %u.%05u\n", BallCor >> 16, (BallCor & 0xFFFF) * 3125 / 2048);
	xprintf("Drag(r) = %u.%05u\n", LiqDrag >> 16, (LiqDrag & 0xFFFF) * 3125 / 2048);
}



/*--------------------------------------------------------------*/
/* Initialization and main processing loop                      */
/*--------------------------------------------------------------*/

int main (void)
{
	long p1;
	char *ptr;
	const uint8_t lis33de_init[] = { 0x43, 0x00, 0x04 };


	/* Enable SysTick timer in interval of 2 ms */
	SYST_RVR = 36000000 / 500 - 1;
	SYST_CSR = 0x07;

	/* Initialize UART and attach it to xprintf module for console */
	uart0_init();
	xdev_out(uart0_putc);
	xdev_in(uart0_getc);
	xputs("MARY-MB test monitor\n");

	/* Initialize OLED module */
	disp_init();
	disp_font_face(Fnt6x8);
	disp_box(0, 127, 0, 127, C_LGRAY);

	/* Initialize acceleration sensor */
	i2c0_init();
	for (p1 = 0; p1 < 3; p1++) {
		I2cCtrl.sla = 0x1C;
		I2cCtrl.retry = 0;
		I2cCtrl.ncmd = 1; I2cCtrl.cmd[0] = 0xA0;	/* Start from reg. 0x20, auto increment */
		I2cCtrl.dir = I2C_WRITE;
		I2cCtrl.ndata = 3; I2cCtrl.data = (uint8_t*)lis33de_init;
		I2cCtrl.eotfunc = 0;
		i2c0_start(&I2cCtrl);
		while (!I2cCtrl.stat) ;
	}

	PIO_1_IRQHandler();	/* Start scanning sequense */
	GPIO1IEV = _BV(9);	/* Select interrupt source (rising edge of P1.9 pin) */
	GPIO1IE = _BV(9);	/* Unmask interrupt of P1.9 pin */
	__enable_irqn(PIO_1_IRQn);	/* Enable PIO1 interrupt */

	disp_parms();

	for (;;) {
		do {
			proc_ball();
		} while (!proc_input());

		ptr = Line;
		switch (*ptr++) {
		case 'd' :		/* d <val> - Set density of ball */
			if (xatop(&ptr, &p1)) {
				if (p1 <= 0x1000) p1 = 0x1000;
				BallDen = p1;
				disp_parms();
			}
			break;

		case 'r' :		/* r <val> - Set liquid drag */
			if (xatop(&ptr, &p1)) {
				if (p1 <= 0) p1 = 0;
				LiqDrag = p1;
				disp_parms();
			}
			break;

		case 'c' :		/* c <val> - Set COR of ball and wall */
			if (xatop(&ptr, &p1)) {
				if (p1 <= 0) p1 = 0;
				if (p1 > 0x10000) p1 = 0x10000;
				BallCor = p1;
				disp_parms();
			}

			break;

		}
	}
}
