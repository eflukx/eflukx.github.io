/*-----------------------------------------------------------------------*/
/* Simple LED blinker program for MARY-MB  (C)ChaN, 2011                 */
/*-----------------------------------------------------------------------*/

#include "LPC1100.h"		/* LPC11xx register definitions */

/* Section boundaries defined in linker script */
extern long _sidata[], _sdata[], _edata[], _sbss[], _ebss[], _endof_sram[];


/*--------------------------------------------------------------------/
/ Program Core                                                        /
/--------------------------------------------------------------------*/

int main (void)
{
	long *s, *d;

	/* Configure BOD control (Reset on Vcc dips below 2.7V) */
	BODCTRL = 0x13;

	/* Configure system clock generator (36MHz system clock with IRC) */
	MAINCLKSEL = 0;							/* Select IRC as main clock */
	MAINCLKUEN = 0; MAINCLKUEN = 1;
	FLASHCFG = (FLASHCFG & 0xFFFFFFFC) | 1;	/* Set wait state for flash memory (1WS) */
	SYSPLLCLKSEL = 0;						/* Select IRC for PLL-in */
	SYSPLLCLKUEN = 0; SYSPLLCLKUEN = 1;
	SYSPLLCTRL = (3 - 1) | (2 << 6);		/* Set PLL parameters (M=3, P=4) */
	PDRUNCFG &= ~0x80;						/* Enable PLL */
	while ((SYSPLLSTAT & 1) == 0) ;			/* Wait for PLL locked */
	SYSAHBCLKDIV = 1;						/* Set system clock divisor (1) */
	MAINCLKSEL = 3;							/* Select PLL-out as main clock */
	MAINCLKUEN = 0; MAINCLKUEN = 1;

	/* Enable clock for only SYS, ROM, RAM, FLASH, GPIO and IOCON */
	SYSAHBCLKCTRL = 0x1005F;

	/* Initialize .data/.bss section and static objects get ready to use after this process */
	for (s = _sidata, d = _sdata; d < _edata; *d++ = *s++) ;
	for (d = _sbss; d < _ebss; *d++ = 0) ;

	/*------- END OF SYSTEM INITIALIZATION -------*/

	/* Set LED port as output */
	GPIO0DIR |= _BV(7);	/* Green */
//	GPIO2DIR |= _BV(0);	/* Red */
//	GPIO1DIR |= _BV(5);	/* Blue */

	/* Enable SysTick timer in interval of 1ms */
	SYST_RVR = 36000000 / 1000 - 1;
	SYST_CSR = 0x07;

	for (;;) ;
}



/*--------------------------------------------------------------------/
/ Timer ISR                                                           /
/--------------------------------------------------------------------*/

void SysTick_Handler (void)		/* 1kHz Timer ISR */
{
	static int div;


	if (++div >= 500) {		/* Toggle LED in inverval of 500ms */
		div = 0;
		GPIO0DATA ^= _BV(7);	/* Toggle Green */
	//	GPIO2DATA ^= _BV(0);	/* Toggle Red */
	//	GPIO1DATA ^= _BV(5);	/* Toggle Blue */
	}
}



/*--------------------------------------------------------------------/
/ Exception Vector Table                                              /
/--------------------------------------------------------------------*/

void trap (void)
{
	for (;;) ;	/* Trap spurious interrupt */
}

void* const vector[] __attribute__ ((section(".VECTOR"))) =	/* Vector table to be allocated to address 0 */
{
	_endof_sram,	/* Reset value of MSP */
	main,			/* Reset entry */
	trap,//NMI_Handler,
	trap,//HardFault_Hander,
	0, 0, 0, 0, 0, 0, 0,//<Reserved>
	trap,//SVC_Handler,
	0, 0,//<Reserved>
	trap,//PendSV_Handler,
	SysTick_Handler,
	trap,//PIO0_0_IRQHandler,
	trap,//PIO0_1_IRQHandler,
	trap,//PIO0_2_IRQHandler,
	trap,//PIO0_3_IRQHandler,
	trap,//PIO0_4_IRQHandler,
	trap,//PIO0_5_IRQHandler,
	trap,//PIO0_6_IRQHandler,
	trap,//PIO0_7_IRQHandler,
	trap,//PIO0_8_IRQHandler,
	trap,//PIO0_9_IRQHandler,
	trap,//PIO0_10_IRQHandler,
	trap,//PIO0_11_IRQHandler,
	trap,//PIO1_0_IRQHandler,
	trap,//C_CAN_IRQHandler,
	trap,//SPI1_IRQHandler,
	trap,//I2C_IRQHandler,
	trap,//CT16B0_IRQHandler,
	trap,//CT16B1_IRQHandler,
	trap,//CT32B0_IRQHandler,
	trap,//CT32B1_IRQHandler,
	trap,//SPI0_IRQHandler,
	trap,//UART_IRQHandler,
	0, 0,//<Reserved>
	trap,//ADC_IRQHandler,
	trap,//WDT_IRQHandler,
	trap,//BOD_IRQHandler,
	0,//<Reserved>
	trap,//PIO_3_IRQHandler,
	trap,//PIO_2_IRQHandler,
	trap,//PIO_1_IRQHandler,
	trap //PIO_0_IRQHandler
};

