/*---------------------------------------------------------------------*/
/* LPC2388 test program: Audio Player                                  */

#include <string.h>
#include "comm.h"
#include "interrupt.h"
#include "monitor.h"
#include "ff.h"
#include "taskmgr.h"
#include "LPC2300.h"


#define FCC(c1,c2,c3,c4)	(((DWORD)c4<<24)+((DWORD)c3<<16)+((WORD)c2<<8)+(BYTE)c1)	/* FourCC */

#define MAX_ALBMS 50	/* Maximum number of albums */
#define MAX_TRKS 100	/* Maximum number of tracks per album */

/* Button command */
#define K_PREV	0x01	/* SW4: Previous track/album */
#define K_STOP	0x02	/* SW3: Stop */
#define K_PLAY	0x04	/* SW2: Play/Pause */
#define K_NEXT	0x08	/* SW1: Next track/album */

/* VS1011 control signals */
#define XRESET_LOW()	FIO2CLR1 = 0x02
#define XRESET_HIGH()	FIO2SET1 = 0x02
#define DREQ			(FIO2PIN1 & 1)
#define XDCS_LOW()		FIO0CLR0 = 0x20
#define XDCS_HIGH()		FIO0SET0 = 0x20
#define XCS_LOW()		FIO0CLR0 = 0x40
#define XCS_HIGH()		FIO0SET0 = 0x40

#define SSP1BSY			(SSP1SR & 0x10)
#define SSP1TNF			(SSP1SR & 0x02)
#define PUT_SSP1(val)	SSP1DR=(val); while (SSP1BSY)

#define	DSP_IRQ_EN()	IO2_INT_EN_R = 0x100
#define	DSP_IRQ_DIS()	IO2_INT_EN_R = 0x000


extern FATFS Fatfs[];


/* Transmission FIFO */
static BYTE Fifo[4096];			/* Buffer (must be multiple of 1024) */
static volatile UINT ofs_r, ofs_w, remain;

/* Name tables */
static char AlbumTbl[MAX_ALBMS][13];
static char TrackTbl[MAX_TRKS][13];

static
volatile BYTE CmdKey, Volume, TmrVol, VolChanged, Enabled;



/*--------------------------------------------------------------------------*/
/*  Interrupt service routine                                               */

static
void ISR_intDSP (void)
{
	UINT rptr, cnt;
	BYTE d;


	IO2_INT_CLR = 0xFFFFFFFF;

	if (VolChanged) {
		VolChanged = 0;
		d = Volume ? (127 - Volume / 2) : 254;
		XCS_LOW();
		PUT_SSP1(2);
		PUT_SSP1(11);
		PUT_SSP1(d);
		PUT_SSP1(d);
		XCS_HIGH();
	}

	cnt = remain;
	if (cnt > 0 && DREQ) {
		rptr = ofs_r;
		XDCS_LOW();
		do {
			d = Fifo[rptr];
			rptr = (rptr + 1) % sizeof(Fifo);
			while (!SSP1TNF);
			SSP1DR = d;
		} while (--cnt > 0 && DREQ);
		while (SSP1BSY);
		XDCS_HIGH();
		ofs_r = rptr;
		remain = cnt;
	}
}



void pb_timerproc (void)
{
	static BYTE pvkey, div5;
	BYTE k;
	INT ad, v;


	if (Enabled && ++div5 >= 5) {
		div5 = 0;
		/* Button scan */
		k = ((~FIO1PIN3 >> 2) & 0x03) | ((~FIO4PIN3 >> 2) & 0x0C);
		pvkey = (pvkey ^ k) & k;
		if (pvkey) CmdKey = pvkey;
		pvkey = k;

		/* Volume control */
		ad = (AD0GDR & 0xFFFF) / 256;
		AD0CR = 0x01201140;			/* 0000_0_001_00_1_0_000_0_00010010_01000000 */
		if (TmrVol) {
			TmrVol--;
		} else {
			v = Volume;
			if (v < ad - 1) {
				Volume = (BYTE)(ad - 1);
				VolChanged = 1;
			}
			if (v > ad + 1) {
				Volume = (BYTE)(ad + 1);
				VolChanged = 1;
			}
		}
	}
}



/*--------------------------------------------------------------------------*/
/*  VS1011 control                                                          */




static
UINT get_key (void)
{
	UINT rv;

	rv = CmdKey;
	if (rv) CmdKey = 0;
	return rv;
}



static
void vsreg_write (UINT reg, WORD val)
{
	while(!DREQ);
	XCS_LOW();
	PUT_SSP1(2);
	PUT_SSP1((BYTE)reg);
	PUT_SSP1((BYTE)(val >> 8));
	PUT_SSP1((BYTE)val);
	XCS_HIGH();
	while(!DREQ);
}



static
WORD vsreg_read (UINT reg)
{
	WORD dat;


	while(!DREQ);
	XCS_LOW();
	PUT_SSP1(3);
	PUT_SSP1((BYTE)reg);
	PUT_SSP1(0);
	dat = SSP1DR; dat <<= 8;
	PUT_SSP1(0);
	dat |= SSP1DR;
	XCS_HIGH();
	while(!DREQ);
	return dat;
}



/*--------------------------------------------------------------------------*/
/*  File control                                                            */

static
void sort_items (
	char tbl[][13],		/* Address of the name table */
	UINT items			/* Number of items stored in the table */
)
{
	UINT i, j, k;
	char s[13];
	BYTE a, b;

	/* Bubble sort */
	for (i = 0; i + 1 < items; i++) {
		for (j = i + 1; j < items; j++) {
			for (k = 0; k < 13; k++) {
				a = (BYTE)tbl[i][k];
				b = (BYTE)tbl[j][k];
				if (a < b) break;
				if (a > b) {
					memcpy(s, tbl[i], 13);
					memcpy(tbl[i], tbl[j], 13);
					memcpy(tbl[j], s, 13);
					break;
				}
			}
		}
	}
}



static
UINT get_tracks (		/* Number of tracks found */
	char* dirname		/* Directory to be scanned */
)
{
	UINT n;
	DIR dir;
	FILINFO fno;


	if (f_opendir(&dir, dirname) != FR_OK) return 0;
	xprintf("get_tracks: %s", dirname);

	n = 0;
#if _USE_LFN
	fno.lfname = NULL;
#endif
	do {
		if (f_readdir(&dir, &fno) != FR_OK || !fno.fname[0]) break;
		if (!(fno.fattrib & AM_DIR) &&
			(strstr(fno.fname, ".mp3") || strstr(fno.fname, ".MP3") || strstr(fno.fname, ".wav") || strstr(fno.fname, ".WAV")) )
		{
			strcpy(TrackTbl[n], fno.fname);
			n++;
		}
	} while (n < MAX_TRKS);

	xprintf(" : %u tracks\n", n);
	return n;
}



static
UINT get_albums(void)
{
	UINT ndirs = 0;
	DIR dir;
	FILINFO fno;


	if (f_opendir(&dir, "") == FR_OK) {
		do {
			if (f_readdir(&dir, &fno) != FR_OK || !fno.fname[0]) break;
			if ((fno.fattrib & AM_DIR) && get_tracks(fno.fname)) {
				strcpy(AlbumTbl[ndirs], fno.fname);
				ndirs++;
			}
		} while (ndirs < MAX_ALBMS);
	}
	return ndirs;
}



static
void get_tag (
	FIL* fp
)
{
	UINT n, ver, br;
	DWORD sz, eof, eof2;
	BYTE *pz;


	memset(&Fifo[512], 0, 256);

	if (f_read(fp, Fifo, 12, &br) || br != 12) return;

	if (LD_DWORD(&Fifo[0]) == FCC('R','I','F','F') && LD_DWORD(&Fifo[8]) == FCC('W','A','V','E'))
	{	/* RIFF/WAVE format */
		eof = LD_DWORD(&Fifo[4]) + 8;
		while (fp->fptr < eof) {
			if (f_read(fp, Fifo, 8, &br)) return;	/* Get chunk type and size */
			if (br != 8) break;
			sz = (LD_DWORD(&Fifo[4]) + 1) & ~1;			/* Chunk size */
			switch (LD_DWORD(&Fifo[0])) {
			case FCC('L','I','S','T'):					/* LIST chunk */
				eof2 = fp->fptr + ((sz + 1) & ~1);
				if (f_read(fp, Fifo, 4, &br) || br != 4) return;
				if (LD_DWORD(Fifo) == FCC('I','N','F','O')) {	/* LIST/INFO chunk */
					while (fp->fptr < eof2) {
						if (f_read(fp, Fifo, 8, &br) || br != 8) return;
						sz = (LD_DWORD(&Fifo[4]) + 1) & ~1;
						switch (LD_DWORD(Fifo)) {
						case FCC('I','N','A','M'):		/* Get title field */
							pz = &Fifo[512]; break;
						case FCC('I','A','R','T'):		/* Get artist field */
							pz = &Fifo[512+128]; break;
						default:						/* Skip other field */
							pz = 0;
						}
						if (pz && sz <= 128) {
							if (f_read(fp, Fifo, sz, &br) || br != sz) return;
							memcpy(pz, Fifo, sz);
						} else {
							if (f_lseek(fp, fp->fptr + sz)) return;
						}
					}
				} else {
					if (f_lseek(fp, eof2)) return;	/* Skip unknown LIST chunk type */
				}
				break;
			default:								/* Skip unknown chunk */
				if (f_lseek(fp, fp->fptr + sz)) return;
			}
		}
		return;
	}

	/* Get Title and Artist from ID3 v1 tag */
	if (f_lseek(fp, fp->fsize - 128)) return;
	if (f_read(fp, Fifo, 128, &br) || br != 128) return;
	if (!memcmp(&Fifo[0], "TAG", 3)) {
		memcpy(&Fifo[512+0], &Fifo[3], 30);
		for (n = 30; n && Fifo[512+n] <= 0x20; n--) Fifo[512+n] = 0;
		memcpy(&Fifo[512+128], &Fifo[33], 30);
		for (n = 30; n && Fifo[512+128+n] <= 0x20; n--) Fifo[512+128+n] = 0;
	}

	/* Get Title and Artist from ID3 v2 tag */
	if (f_lseek(fp, 0)) return;
	if (f_read(fp, &Fifo[0], 10, &br) || br != 10) return;
	if (!memcmp(&Fifo[0], "ID3", 3)) {
		ver = Fifo[3];
		for (;;) {
			if (ver == 2) {
				if (f_read(fp, &Fifo[0], 8, &br) || br != 8) return;
				n = ((DWORD)Fifo[3] << 16) + ((DWORD)Fifo[4] << 8)+ Fifo[5];
			} else {
				if (f_read(fp, &Fifo[0], 10, &br) || br != 10) return;
				n = ((DWORD)Fifo[4] << 24) + ((DWORD)Fifo[5] << 16) + ((DWORD)Fifo[6] << 8) + Fifo[7];
			}
			if (Fifo[0] < 0x41 || Fifo[0] > 0x5A || n > 512) break;
			if (f_read(fp, &Fifo[10], (WORD)n, &br) || br != n) return;
			if (n >= 63 || n <= 1) continue;
			if (Fifo[10] != 0) break;
			n--;
			if (!memcmp(Fifo, "TIT2", 4) || !memcmp(&Fifo[0], "TT2", 3)){
				memcpy(&Fifo[512+0], &Fifo[11], n);
				Fifo[512+0+n] = 0;
			}
			if (!memcmp(&Fifo[0], "TPE1", 4) || !memcmp(&Fifo[0], "TP1", 3)) {
				memcpy(&Fifo[512+128], &Fifo[11], n);
				Fifo[512+64+n] = 0;
			}
		
		}
	}
}



static
UINT play_file (	/* Terminated by: K_PREV, K_STOP, K_NEXT and eof(0) */
	char* fname		/* Audio file (mp3 or wav) to be played */
)
{
	UINT key, br;
	FIL fil;


	if (f_open(&fil, fname, FA_READ|FA_OPEN_EXISTING) != FR_OK) return K_STOP;
	get_tag(&fil);
	f_lseek(&fil, 0);
	xprintf("play_file: %s : %s - %s\n", fname, &Fifo[512+0], &Fifo[512+128]);
	vsreg_write(0, 0x0880);			/* Jump out PCM mode */
	vsreg_write(0, 0x0804);			/* Software reset */

	ofs_r = ofs_w = remain = 0;			/* Flush FIFO */
	key = 0;
	do {
		if (vsreg_read(8) != 0x7761) {	/* If starting in mp3(!PCM) mode? */
			ofs_r = 0;
			ofs_w = remain = 2048;		/* Flush FIFO and insert 2048 zeros */
			memset(&Fifo[0], 0, 2048);
			if (key) {					/* When resume in mp3 mode, */
				TmrVol = 7;				/* Mute (with 150ms delayed release to mask glitch) */
				Volume = 0; VolChanged = 1;
			}
		}
		key = 0;
		DSP_IRQ_EN();		/* Enable VS1011 interrupt */
		do {			/* Streaming loop */
			Sleep(0);
			/* Store audio data into FIFO when there is >=1024 byte space in the FIFO */
			if (remain <= sizeof(Fifo) - 1024) {
				if (f_read(&fil, &Fifo[ofs_w], 1024, &br) != FR_OK) break;
				ofs_w = (ofs_w + br) % sizeof(Fifo);
				DSP_IRQ_DIS();
				remain += br;
				if (DREQ) ISR_intDSP();
				DSP_IRQ_EN();
				if (br < 1024) break;	/* Break on EOF */
			}
			key = get_key();	/* Break on any button pressed */
		} while (!key);
		if (!key) {		/* When reached to EOF */
			do Sleep(0); while (remain);	/* Wait for FIFO empty */
		}
		DSP_IRQ_DIS();		/* Disable VS1011 interrupt */
		if (key == K_PLAY) {	/* Breaking with PLAY button means Pause */
			do {				/* Wait for any button pressed */
				Sleep(10);
				key = get_key();
			} while (!key);
		}
	} while (key == K_PLAY);

	f_close(&fil);
	return key;
}



/*--------------------------------------------------------------------------*/
/*  Main task of Audio Player                                               */

/* LPC2388 pin mappings
P2[9] - XRESET#
P2[8] - DREQ
P0[5] - XDCS#
P0[6] - XCS#
P0[7] - SCLK
P0[9] - SI
P0[8] - SO
P0[12] - Volume
P1[26] - SW4 Rev
P1[27] - SW3 Stop
P4[28] - SW2 Play
P4[29] - SW1 Fwd
*/

void player (void *arg)
{
	char fname[32];
	INT ndirs, ntrks, cdir, ctrk, strk;
	UINT key, key2;


	/* Initialize peripherals */

	PCLKSEL0 = (PCLKSEL0 & 0xFFCFFFFF) | 0x00200000;	/* Set PCLK_SSP1 CCLK/2 = 36MHz */
	SSP1CPSR = 0x02;		/* Set clock divisor (CPSR=2) */
	SSP1CR0 = 0x0507;		/* Set frame format (SCR=5, SPI0, 8bit) */
	SSP1CR1 = 0x02;			/* Enable SSP1 (SSE=1) */

	FIO2DIR1 |= 0x02;		/* P2[9] = Output */
	PINMODE4 = (PINMODE4 & 0xFFFCFFFF) | 0x00030000;	/* Set pull-down on P2[8] pin */
	FIO0PINL |= 0x0060;		/* P0[9:5]=[00011] */
	FIO0DIRL |= 0x01E0;		/* P0[9:5]=[ioooo] */
	PINSEL0 =  (PINSEL0  & 0xFFF03FFF) | 0x000A8000;	/* Attach SSP1 to P0[9:7] */

	PCONP |= (1 << 12);									/* ADC power on */
	PINMODE0 = (PINMODE0 & 0xFCFFFFFF) | 0x02000000;	/* Disable pull-up on P0[12] */
	PINSEL0 =  (PINSEL0  & 0xFCFFFFFF) | 0x03000000;	/* Attach AD0.6 to P0[12] */

	RegisterVector(EINT3_INT, ISR_intDSP, PRI_LOWEST, CLASS_IRQ);	/* Register ISR */

	Enabled = 1;

	for (;;) {
		XRESET_LOW();		/* Stop VS1011 */
		do {	/* In STOP state, wait for PLAY button */
			Sleep(10);
			key = get_key();
		} while (!key);
		if (key != K_PLAY) continue;

		/* Create directory (album) list */
		if (f_mount(0, &Fatfs[0]) != FR_OK) continue;
		ndirs = get_albums();
		if (!ndirs) continue;
		sort_items(AlbumTbl, ndirs);

		XRESET_HIGH();		/* Start VS1011 */
		vsreg_write(3, 24576000/2000);
		VolChanged = 1;

		cdir = ctrk = strk = 0;
		key = 0;
		for (;;) {
			ntrks = get_tracks(AlbumTbl[cdir]);	/* Get tracks of current album */
			if (!ntrks) break;
			sort_items(TrackTbl, ntrks);
			ctrk = strk ? ntrks - 1 : 0;	/* Start track: 1st or last */
			strk = 0;
			for (;;) {
				strcpy(fname, AlbumTbl[cdir]);	/* Play a track */
				strcat(fname, "/");
				strcat(fname, TrackTbl[ctrk]);
				key = play_file(fname);

				if (key == K_STOP) break;
				if (key) {
					Sleep(350);
					key2 = get_key();
					if (key == K_PREV && key2 == K_PREV) {	/* Double click of PREV, */
						if (--cdir < 0) cdir = ndirs - 1;	/* Goto top of previous album */
						break;
					}
					if (key == K_NEXT && key2 == K_NEXT) {	/* Double click of NEXT, */
						if (++cdir >= ndirs) cdir = 0;		/* Goto top of next album */
						break;
					}
				}
				if (key == K_PREV) {	/* Single click of PREV */
					if (--ctrk < 0) {
						if (--cdir < 0) cdir = ndirs - 1;
						strk = 1;
						break;
					}
				} else {				/* EOF or single click of NEXT */
					if (++ctrk >= ntrks) {
						if (++cdir >= ndirs) cdir = 0;
						break;
					}
				}
			}
			if (key == K_STOP) break;
		}
	}
}



