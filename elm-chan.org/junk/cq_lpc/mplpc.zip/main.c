/*----------------------------------------------------------------------*/
/* CQ_LPC2388: Test Program (Audio player)                              */
/*----------------------------------------------------------------------*/

#include <string.h>
#include "LPC2300.h"
#include "integer.h"
#include "interrupt.h"
#include "comm.h"
#include "ff.h"
#include "monitor.h"
#include "diskio.h"
#include "taskmgr.h"

void pb_timerproc (void);
void player (void);
void monitor (void);


FATFS Fatfs[_DRIVES];		/* File system object for each logical drive */
FIL File1, File2;			/* File objects */
DIR Dir;					/* Directory object */
BYTE Buff[16384] __attribute__ ((aligned (4))) ;		/* Working buffer */

volatile UINT Timer;		/* 1kHz increment timer */


#define SS0 256
#define SS1 256
DWORD TaskStk0[SS0], TaskStk1[SS1];
DWORD TaskContext[2][16];



/*---------------------------------------------------------*/
/* 1kHz Interval Timer                                     */
/*---------------------------------------------------------*/

void Isr_TIMER0 (void)
{
	static BYTE div;
	WORD w;
	int n;


	T0IR = 1;	/* Clear irq flag */

	Timer++;

	for (n = 0; n < 2; n++) {
		w = TaskContext[n][1];
		if (w != 0xFFFF && w-- != 0) TaskContext[n][1] = w;
	}

	switch (++div & 3) {
	case 0:
		disk_timerproc();
		break;
	case 1:
		pb_timerproc();
		break;
	case 2:
	case 3:
		break;
	}
}



/*---------------------------------------------------------*/
/* User Provided RTC Function for FatFs module             */
/*---------------------------------------------------------*/
/* This is a real time clock service to be called from     */
/* FatFs module. Any valid time must be returned even if   */
/* the system does not support an RTC.                     */
/* This function is not required in read-only cfg.         */

DWORD get_fattime ()
{
	/* Pack date and time into a DWORD variable (No RTC, use 2009.04.01 00:07:00) */
	return	  ((DWORD)(2009 - 1980) << 25)
			| ((DWORD)4 << 21)
			| ((DWORD)1 << 16)
			| ((DWORD)0 << 11)
			| ((DWORD)7 << 5)
			| ((DWORD)0 >> 1);
}


/*--------------------------------------------------------------------------*/
/* Monitor                                                                  */


static
void IoInit (void)
{
#define PLL_N		2UL
#define PLL_M		72UL
#define CCLK_DIV	4

	if ( PLLSTAT & (1 << 25) ) {
		PLLCON = 1;				/* Disconnect PLL output if PLL is in use */
		PLLFEED = 0xAA;
		PLLFEED = 0x55;
	}
	PLLCON = 0;				/* Disable PLL */
	PLLFEED = 0xAA;
	PLLFEED = 0x55;
	CLKSRCSEL = 0;			/* Select IRC (4MHz) as the PLL clock input */

	PLLCFG = ((PLL_N - 1) << 16) | (PLL_M - 1);	/* Re-configure PLL */
	PLLFEED = 0xAA;
	PLLFEED = 0x55;
	PLLCON = 1;				/* Enable PLL */
	PLLFEED = 0xAA;
	PLLFEED = 0x55;

	while ((PLLSTAT & (1 << 26)) == 0);	/* Wait for PLL locked */

	CCLKCFG = CCLK_DIV-1;	/* Select CCLK frequency (divide ratio of hclk) */
	PLLCON = 3;				/* Connect PLL output to the sysclk */
	PLLFEED = 0xAA;
	PLLFEED = 0x55;

	MAMCR = 0;				/* Configure MAM for 72MHz operation */
	MAMTIM = 3;
	MAMCR = 2;

	PCLKSEL0 = 0x00000000;	/* Select peripheral clock */
	PCLKSEL1 = 0x00000000;

	ClearVector();

	SCS |= 1;				/* Enable FIO0 and FIO1 */

	FIO1PIN2 = 0x04;		/* -|-|-|-|-|LED|-|- */
	FIO1DIR2 = 0x04;
	PINMODE3 = 0x00000020;

	/* Initialize Timer0 as 1kHz interval timer */
	RegisterVector(TIMER0_INT, Isr_TIMER0, PRI_LOWEST, CLASS_IRQ);
	T0CTCR = 0;
	T0MR0 = 18000 - 1;	/* 18M / 1k = 18000 */
	T0MCR = 0x3;		/* Clear TC and Interrupt on MR0 match */
	T0TCR = 1;

	IrqEnable();

	uart0_init();
}



int main (void)
{
	IoInit();

	/* Start threads */
	StartTask(TaskContext[0], player,  &TaskStk0[SS0]);
	StartTask(TaskContext[1], monitor, &TaskStk1[SS1]);

	/* Drive threads */
	for (;;) {
		DispatchTask(TaskContext[0]);
		DispatchTask(TaskContext[1]);
	}
}


