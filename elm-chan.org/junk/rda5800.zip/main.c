/*----------------------------------------------------------------------*/
/* RDA5800 test program    (C)ChaN, 2009                                */
/*                                                                      */
/* FM-radio control module                                              */
/*----------------------------------------------------------------------*/

#include "xitoa.h"
#include "suart.h"
#include <inttypes.h>
#include <avr/pgmspace.h>


/*-------------------------------------------------*/
/* I2C bus protocol                                */


#define SCL_LOW()	DDRB |=	_BV(2)				/* SCL = LOW */
#define SCL_HIGH()	DDRB &=	~_BV(2)				/* SCL = High-Z */
#define	SCL_VAL		((PINB & _BV(2)) ? 1 : 0)	/* SCL input level */
#define SDA_LOW()	DDRB |=	_BV(3)				/* SDA = LOW */
#define SDA_HIGH()	DDRB &=	~_BV(3)				/* SDA = High-Z */
#define	SDA_VAL		((PINB & _BV(3)) ? 1 : 0)	/* SDA input level */
#define	IIC_ACK		1
#define	IIC_NACK	0


static
void iic_delay (void)
{
	int n;

	for (n = 8; n; n--) PINB;
}


/* Generate start condition on the IIC bus */
static
void iic_start (void)
{
	SDA_HIGH();
	iic_delay();
	SCL_HIGH();
	iic_delay();
	SDA_LOW();
	iic_delay();
	SCL_LOW();
	iic_delay();
}


/* Generate stop condition on the IIC bus */
static
void iic_stop (void)
{
	SDA_LOW();
	iic_delay();
	SCL_HIGH();
	iic_delay();
	SDA_HIGH();
	iic_delay();
}


/* Send a byte to the IIC bus */
static
int iic_send (uint8_t dat)
{
	uint8_t b = 0x80;
	int ack;


	do {
		if (dat & b)	 {	/* SDA = Z/L */
			SDA_HIGH();
		} else {
			SDA_LOW();
		}
		iic_delay();
		SCL_HIGH();
		iic_delay();
		SCL_LOW();
		iic_delay();
	} while (b >>= 1);
	SDA_HIGH();
	iic_delay();
	SCL_HIGH();
	ack = SDA_VAL ? IIC_NACK : IIC_ACK;	/* Sample ACK bit */
	iic_delay();
	SCL_LOW();
	iic_delay();
	return ack;
}


/* Receive a byte from the IIC bus */
static
uint8_t iic_rcvr (int ack)
{
	uint16_t d = 1;


	do {
		d <<= 1;
		SCL_HIGH();
		if (SDA_VAL) d++;
		iic_delay();
		SCL_LOW();
		iic_delay();
	} while (d < 0x100);
	if (ack) {		/* SDA = ACK */
		SDA_LOW();
	} else {
		SDA_HIGH();
	}
	iic_delay();
	SCL_HIGH();
	iic_delay();
	SCL_LOW();
	SDA_HIGH();
	iic_delay();

	return (uint8_t)d;
}




/*-------------------------------------------------*/
/* RDA5800 controls                                */


#define RES_LOW()	PORTD &= ~_BV(0)
#define RES_HIGH()	PORTD |= _BV(0)
#define ADR5800_WR	0x20
#define ADR5800_RD	0x21


const prog_uint16_t RDA5800_regs[] = {
	0xC881,	/* R2: b15: Audio output (0:Hi-Z, 1:Enable),  */
			/*     b14: Mute (0:Mute, 1:Normal) */
			/*     b13: Mono (0:Stereo, 1:Force mono) */
			/*     b12: Bass boost (0:Disable, 1:Enable) */
			/*     b9: Seek direction (0:Down, 1:Up) */
			/*     b8: Seek (0:Disable, 1:Enable) */
			/*     b7: 1 */
			/*     b0: Power (0:Power off, 1:Power on) */
	0x6A00,	/* R3: b15-b8: Channel (f = Channel * Space + Band) */
			/*     b2: Space 50k (0:Space, 1:50k) */
			/*     b1: Band (0:87.5-108.0, 1:76.0-91.0) */
			/*     b0: Space (0:100k, 1:200k) */
	0x4C00,	/* R4: b14: Seek/Tune complete interrupt (0:Disable, 1:Enable interrupt on GPIO2) */
			/*     b11: Deemphasis (0:75us, 1:50us) */
			/*     b6: I2S output (0:Disable, 1:Enable)*/
			/*     b5-b4: GPIO3 state (00:Hi-Z, 01:Mo/St indicator, 10:Low, 11:High) */
			/*     b3-b2: GPIO2 state (00:Hi-Z, 01:Interrupt, 10:Low, 11:High) */
			/*     b1-b0: GPIO1 state (00:Hi-Z, 01:Reserved, 10:Low, 11:High) */
	0x08FF,	/* R5: b15: INT mode (0:5ms low pulse, 1:Hold low until write action) */
			/*     b13-b8: Seek threshold (0:Min RSSI, 63:Max RSSI) */
			/*     b7-b4: DSP volume (0:-15dB, 15:0dB) */
			/*     b3-b0: DAC volume (0:min, 15:max) */
	/* R6-R44: Undocumented registers */
	0x0000, 0x00CD, 0x0096, 0x0020, 0x4163, 0x0806, 0x5800, 0x5800,
	0x5800, 0x5800, 0x4C17, 0x20A2, 0x0000, 0x000F, 0x06DE, 0xECC0,
	0x0200, 0x5383, 0x95A4, 0xE848, 0x0500, 0x00A4, 0x889B, 0x0D84,
	0x4F04, 0x8832, 0x7F71, 0x0660, 0x4010, 0x6002, 0x1808, 0x6458,
	0x787F, 0x0100, 0xC040, 0xC020, 0x0024, 0x0400, 0x0020
};



void RDA5800_init (void)
{
	uint16_t r, d;


	/* Reset RDA5800 and put it IIC mode */
	RES_LOW();
	RES_HIGH();

	/* Send initialization data */
	iic_start();
	if (iic_send(ADR5800_WR) == IIC_ACK) {		/* IIC address */
		for (r = 0; r < 43; r++) {	/* Initialze reg#2 - #44 */
			d = pgm_read_word(&RDA5800_regs[r]);
			iic_send((uint8_t)(d >> 8));
			iic_send((uint8_t)(d >> 0));
		}
	}
	iic_stop();
}



void RDA5800_tune (
	uint16_t f		/* Frequency in unit of 100kHz */
)
{
	uint8_t ch, band;


	if (f < 760 || f > 1080) return;
	if (f >= 900) {
		ch = (uint8_t)(f - 875);
		band = 0;
	} else {
		ch = (uint8_t)(f - 760);
		band = 2;
	}

	iic_start();
	if (iic_send(ADR5800_WR) == IIC_ACK) {
		f = pgm_read_word(&RDA5800_regs[0]);
		iic_send((uint8_t)(f >> 8));
		iic_send((uint8_t)(f >> 0));
		iic_send(ch);
		iic_send(band);
	}
	iic_stop();
}



uint8_t RDA5800_status (void)
{
	uint8_t buf[4], n;


	iic_start();
	if (iic_send(ADR5800_RD) != IIC_ACK) {
		iic_stop();
		return 0;
	}
	buf[0] = iic_rcvr(IIC_ACK);
	buf[1] = iic_rcvr(IIC_ACK);
	buf[2] = iic_rcvr(IIC_ACK);
	buf[3] = iic_rcvr(IIC_NACK);
	iic_stop();

	n = (buf[2] & 63) | ((buf[0] & 1) << 7);	/* b5-b0: RSSI, b7: St/Mo */

	return n;
}



void RDA5800_off (void)
{
	iic_start();
	if (iic_send(ADR5800_WR) == IIC_ACK) {
		iic_send(0);
		iic_send(0);
	}
	iic_stop();
}




/*-------------------------------------------------*/
/* RDA5800 test program                            */

int main (void)
{
	uint16_t f;
	uint8_t k;


	/* Initialize ports */
	PORTB = 0b10110011;	/* u|L|u|u|u|z|H|u */
	DDRB  = 0b01000010;
	PORTD = 0b01111110;	/* -|u|u|u|u|u|u|L */
	DDRD  = 0b00000001;

	/* Software UART via ISP connector (N81,38.4kbps) */
	xfunc_out = (void(*)(char))xmit;
	xputs(PSTR("RDA5800 test monitor (+,-,s)\n"));

	RDA5800_init();		/* Initialize RDA5800 chip */
	f = 800;			/* 80MHz */
	RDA5800_tune(f);

	for (;;) {
		switch (rcvr()) {	/* Get test command */
		case '+':	/* Increase frequency */
			if (f < 1080)
				RDA5800_tune(++f);
			xprintf(PSTR("%u.%u\n"), f / 10, f % 10);
			break;
		case '-':	/* Decrease frequency */
			if (f > 760)
				RDA5800_tune(--f);
			xprintf(PSTR("%u.%u\n"), f / 10, f % 10);
			break;
		case 's':	/* Get status (RSSI, Stereo) */
			k = RDA5800_status();
			xprintf(PSTR("RSSI=%u, ST=%u\n"), k & 63, k >> 7);
			break;
		}
	}
}


