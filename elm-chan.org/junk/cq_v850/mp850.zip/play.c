/*---------------------------------------------------------------------*/
/* V850 test program: Audio Player                                     */

#include <string.h>
#include "comm.h"
#include "monitor.h"
#include "ff.h"
#include "taskmgr.h"

#define FCC(c1,c2,c3,c4)	(((DWORD)c4<<24)+((DWORD)c3<<16)+((WORD)c2<<8)+(BYTE)c1)	/* FourCC */

#define MAX_ALBMS 50	/* Maximum number of albums */
#define MAX_TRKS 100	/* Maximum number of tracks per album */

/* Button command */
#define K_PREV	0x02	/* SW4: Previous track/album */
#define K_STOP	0x04	/* SW3: Stop */
#define K_PLAY	0x08	/* SW2: Play/Pause */
#define K_NEXT	0x10	/* SW1: Next track/album */

/* VS1011 control signals */
#define DREQ	P9H.5	/* INTP4 */
#define XCS		P9L.5
#define XDCS	P9L.4
#define XRESET	P9L.3
#define LED1	PCT.6	/* On board LED (VS1011 activity) */
#define L		0
#define H		1


/* Transmission FIFO */
static BYTE Fifo[4096];			/* Buffer (must be multiple of 1024) */
static volatile UINT ofs_r, ofs_w, remain;

/* Name tables */
static char AlbumTbl[MAX_ALBMS][13];
static char TrackTbl[MAX_TRKS][13];


extern volatile BYTE CmdKey, Volume, TmrVol, VolChanged;
extern FATFS fatfs;



/*--------------------------------------------------------------------------*/
/*  VS1011 control                                                          */


#define PUT_CB3(val) CB3TXL=(val); do;while(CB3TSF)

static
UINT get_key (void)
{
	UINT rv;

	rv = CmdKey;
	if (rv) CmdKey = 0;
	return rv;
}



static
void vsreg_write (UINT reg, WORD val)
{
	do; while(!DREQ);
	XCS = L;
	PUT_CB3(2);
	PUT_CB3((BYTE)reg);
	PUT_CB3((BYTE)(val >> 8));
	PUT_CB3((BYTE)val);
	XCS = H;
	do; while(!DREQ);
}



static
WORD vsreg_read (UINT reg)
{
	WORD dat;


	do; while(!DREQ);
	XCS = L;
	PUT_CB3(3);
	PUT_CB3((BYTE)reg);
	PUT_CB3(0);
	dat = CB3RXL; dat <<= 8;
	PUT_CB3(0);
	dat |= CB3RXL;
	XCS = H;
	do; while(!DREQ);
	return dat;
}



/*--------------------------------------------------------------------------*/
/*  File control                                                            */

static
void sort_items (
	char tbl[][13],		/* Address of the name table */
	UINT items			/* Number of items stored in the table */
)
{
	UINT i, j, k;
	char s[13];
	BYTE a, b;

	/* Bubble sort */
	for (i = 0; i + 1 < items; i++) {
		for (j = i + 1; j < items; j++) {
			for (k = 0; k < 13; k++) {
				a = (BYTE)tbl[i][k];
				b = (BYTE)tbl[j][k];
				if (a < b) break;
				if (a > b) {
					memcpy(s, tbl[i], 13);
					memcpy(tbl[i], tbl[j], 13);
					memcpy(tbl[j], s, 13);
					break;
				}
			}
		}
	}
}



static
UINT get_tracks (		/* Number of tracks found */
	char* dirname		/* Directory to be scanned */
)
{
	UINT n;
	DIR dir;
	FILINFO fno;


	if (f_opendir(&dir, dirname) != FR_OK) return 0;
	xprintf("get_tracks: %s", dirname);

	n = 0;
	do {
		if (f_readdir(&dir, &fno) != FR_OK || !fno.fname[0]) break;
		if (!(fno.fattrib & AM_DIR) &&
			(strstr(fno.fname, ".mp3") || strstr(fno.fname, ".MP3") || strstr(fno.fname, ".wav") || strstr(fno.fname, ".WAV")) )
		{
			strcpy(TrackTbl[n], fno.fname);
			n++;
		}
	} while (n < MAX_TRKS);

	xprintf(" : %u tracks\n", n);
	return n;
}



static
UINT get_albums()
{
	UINT ndirs = 0;
	DIR dir;
	FILINFO fno;


	if (f_opendir(&dir, "") == FR_OK) {
		do {
			if (f_readdir(&dir, &fno) != FR_OK || !fno.fname[0]) break;
			if ((fno.fattrib & AM_DIR) && get_tracks(fno.fname)) {
				strcpy(AlbumTbl[ndirs], fno.fname);
				ndirs++;
			}
		} while (ndirs < MAX_ALBMS);
	}
	return ndirs;
}



static
void get_tag (
	FIL* fp
)
{
	UINT n, ver, br;
	DWORD sz, eof, eof2;
	BYTE *pz;


	memset(&Fifo[512], 0, 256);	/* Clear names */

	if (f_read(fp, Fifo, 12, &br) || br != 12) return;

	if (LD_DWORD(&Fifo[0]) == FCC('R','I','F','F') && LD_DWORD(&Fifo[8]) == FCC('W','A','V','E'))
	{	/* RIFF/WAVE format */

		eof = LD_DWORD(&Fifo[4]) + 8;
		while (fp->fptr < eof) {
			if (f_read(fp, Fifo, 8, &br)) return;	/* Get chunk type and size */
			if (br != 8) break;
			sz = (LD_DWORD(&Fifo[4]) + 1) & ~1;			/* Chunk size */
			switch (LD_DWORD(&Fifo[0])) {
			case FCC('L','I','S','T'):					/* LIST chunk */
				eof2 = fp->fptr + ((sz + 1) & ~1);
				if (f_read(fp, Fifo, 4, &br) || br != 4) return;
				if (LD_DWORD(Fifo) == FCC('I','N','F','O')) {	/* LIST/INFO chunk */
					while (fp->fptr < eof2) {
						if (f_read(fp, Fifo, 8, &br) || br != 8) return;
						sz = (LD_DWORD(&Fifo[4]) + 1) & ~1;
						switch (LD_DWORD(Fifo)) {
						case FCC('I','N','A','M'):		/* Get title field */
							pz = &Fifo[512]; break;
						case FCC('I','A','R','T'):		/* Get artist field */
							pz = &Fifo[512+128]; break;
						default:						/* Skip other field */
							pz = 0;
						}
						if (pz && sz <= 128) {
							if (f_read(fp, Fifo, sz, &br) || br != sz) return;
							memcpy(pz, Fifo, sz);
						} else {
							if (f_lseek(fp, fp->fptr + sz)) return;
						}
					}
				} else {
					if (f_lseek(fp, eof2)) return;	/* Skip unknown LIST chunk type */
				}
				break;
			default:								/* Skip unknown chunk */
				if (f_lseek(fp, fp->fptr + sz)) return;
			}
		}
		return;
	}

	/* Get Title and Artist from ID3 v1 tag */
	if (f_lseek(fp, fp->fsize - 128)) return;
	if (f_read(fp, Fifo, 128, &br) || br != 128) return;
	if (!memcmp(&Fifo[0], "TAG", 3)) {
		memcpy(&Fifo[512+0], &Fifo[3], 30);
		for (n = 30; n && Fifo[512+n] <= 0x20; n--) Fifo[512+n] = 0;
		memcpy(&Fifo[512+128], &Fifo[33], 30);
		for (n = 30; n && Fifo[512+128+n] <= 0x20; n--) Fifo[512+128+n] = 0;
	}

	/* Get Title and Artist from ID3 v2 tag */
	if (f_lseek(fp, 0)) return;
	if (f_read(fp, &Fifo[0], 10, &br) || br != 10) return;
	if (!memcmp(&Fifo[0], "ID3", 3)) {
		ver = Fifo[3];
		for (;;) {
			if (ver == 2) {
				if (f_read(fp, &Fifo[0], 8, &br) || br != 8) return;
				n = ((DWORD)Fifo[3] << 16) + ((DWORD)Fifo[4] << 8)+ Fifo[5];
			} else {
				if (f_read(fp, &Fifo[0], 10, &br) || br != 10) return;
				n = ((DWORD)Fifo[4] << 24) + ((DWORD)Fifo[5] << 16) + ((DWORD)Fifo[6] << 8) + Fifo[7];
			}
			if (Fifo[0] < 0x41 || Fifo[0] > 0x5A || n > 512) break;
			if (f_read(fp, &Fifo[10], (WORD)n, &br) || br != n) return;
			if (n >= 63 || n <= 1) continue;
			if (Fifo[10] != 0) break;
			n--;
			if (!memcmp(Fifo, "TIT2", 4) || !memcmp(&Fifo[0], "TT2", 3)){
				memcpy(&Fifo[512+0], &Fifo[11], n);
				Fifo[512+0+n] = 0;
			}
			if (!memcmp(&Fifo[0], "TPE1", 4) || !memcmp(&Fifo[0], "TP1", 3)) {
				memcpy(&Fifo[512+128], &Fifo[11], n);
				Fifo[512+64+n] = 0;
			}

		}
	}
}



static
UINT play_file (	/* Terminated by: K_PREV, K_STOP, K_NEXT and eof(0) */
	char* fname		/* Audio file (mp3 or wav) to be played */
)
{
	UINT key, n, br;
	FIL fil;


	if (f_open(&fil, fname, FA_READ|FA_OPEN_EXISTING) != FR_OK) return K_STOP;
	get_tag(&fil);
	f_lseek(&fil, 0);
	xprintf("play_file: %s : %s - %s\n", fname, &Fifo[512+0], &Fifo[512+128]);
	vsreg_write(0, 0x0880);			/* Jump out PCM mode */
	vsreg_write(0, 0x0804);			/* Software reset */

	ofs_r = ofs_w = remain = 0;			/* Flush FIFO */
	key = 0;
	do {
		if (vsreg_read(8) != 0x7761) {	/* If starting in mp3(!PCM) mode? */
			ofs_r = 0;
			ofs_w = remain = 2048;		/* Flush FIFO and insert 2048 zeros */
			memset(&Fifo[0], 0, 2048);
			if (key) {					/* When resume in mp3 mode, */
				TmrVol = 7;				/* Mute (with 150ms delayed release to mask glitch) */
				Volume = 0; VolChanged = 1;
			}
		}
		key = 0;
		PMK4 = 0;		/* Enable VS1011 interrupt */
		do {			/* Streaming loop */
			sleep(0);
			/* Store audio data into FIFO when there is >=1024 byte space in the FIFO */
			if (remain <= sizeof(Fifo) - 1024) {
				if (f_read(&fil, &Fifo[ofs_w], 1024, &br) != FR_OK) break;
				ofs_w = (ofs_w + br) % sizeof(Fifo);
				__DI();
				remain += br;
				if (DREQ == H) PIF4 = 1;	/* Re-trigger INTP4 */
				__EI();
				if (br < 1024) break;	/* Break on EOF */
			}
			key = get_key();	/* Break on any button pressed */
		} while (!key);
		if (!key) {		/* When reached to EOF */
			do sleep(0); while (remain);	/* Wait for FIFO empty */
		}
		PMK4 = 1;		/* Disable VS1011 interrupt */
		if (key == K_PLAY) {	/* Breaking with PLAY button means Pause */
			do {				/* Wait for any button pressed */
				sleep(10);
				key = get_key();
			} while (!key);
		}
	} while (key == K_PLAY);

	f_close(&fil);
	return key;
}



/*--------------------------------------------------------------------------*/
/*  Main task of Audio Player                                               */

void TASK player (void *arg)
{
	char fname[32];
	INT ndirs, ntrks, cdir, ctrk, strk;
	UINT key, key2;


	for (;;) {
		XRESET = L;		/* Stop VS1011 */
		do {	/* In STOP state, wait for PLAY button */
			sleep(10);
			key = get_key();
		} while (!key);
		if (key != K_PLAY) continue;

		/* Create directory (album) list */
		if (f_mount(0, &fatfs) != FR_OK) continue;
		ndirs = get_albums();
		if (!ndirs) continue;
		sort_items(AlbumTbl, ndirs);

		XRESET = H;		/* Start VS1011 */
		vsreg_write(3, 24576000/2000);
		VolChanged = 1;

		cdir = ctrk = strk = 0;
		key = 0;
		for (;;) {
			ntrks = get_tracks(AlbumTbl[cdir]);	/* Get tracks of current album */
			if (!ntrks) break;
			sort_items(TrackTbl, ntrks);
			ctrk = strk ? ntrks - 1 : 0;	/* Start track: 1st or last */
			strk = 0;
			for (;;) {
				strcpy(fname, AlbumTbl[cdir]);	/* Play a track */
				strcat(fname, "/");
				strcat(fname, TrackTbl[ctrk]);
				key = play_file(fname);

				if (key == K_STOP) break;
				if (key) {
					sleep(350);
					key2 = get_key();
					if (key == K_PREV && key2 == K_PREV) {	/* Double click of PREV, */
						if (--cdir < 0) cdir = ndirs - 1;	/* Goto top of previous album */
						break;
					}
					if (key == K_NEXT && key2 == K_NEXT) {	/* Double click of NEXT, */
						if (++cdir >= ndirs) cdir = 0;		/* Goto top of next album */
						break;
					}
				}
				if (key == K_PREV) {	/* Single click of PREV */
					if (--ctrk < 0) {
						if (--cdir < 0) cdir = ndirs - 1;
						strk = 1;
						break;
					}
				} else {				/* EOF or single click of NEXT */
					if (++ctrk >= ntrks) {
						if (++cdir >= ndirs) cdir = 0;
						break;
					}
				}
			}
			if (key == K_STOP) break;
		}
	}
}



/*--------------------------------------------------*/
/* INTP4 interrupt service routine triggerd by      */
/* rising edge of DREQ                              */
/*--------------------------------------------------*/

#pragma interrupt INTP4 ISR_intp4
__multi_interrupt
void ISR_intp4 (void)
{
	UINT rptr, cnt;
	BYTE d;


	LED1 = L;
	__EI();

	if (VolChanged) {
		VolChanged = 0;
		d = 127 - Volume / 2;
		XCS = L;
		PUT_CB3(2);
		PUT_CB3(11);
		PUT_CB3(d);
		PUT_CB3(d);
		XCS = H;
	}

	cnt = remain;
	if (cnt > 0 && DREQ == H) {
		rptr = ofs_r;
		XDCS = L;
		do {
			d = Fifo[rptr];
			rptr = (rptr + 1) % sizeof(Fifo);
			do; while (CB3TSF);
			CB3TXL = d;
		} while (--cnt > 0 && DREQ == H);
		do; while (CB3TSF);
		XDCS = H;
		ofs_r = rptr;
		remain = cnt;
	}

	__DI();
	LED1 = H;
}


