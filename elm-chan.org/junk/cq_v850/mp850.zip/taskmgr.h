#include "integer.h"

#define TASK

typedef unsigned long TSTAT;

TSTAT start_task (UINT, void(*)(void*), void*, void*);
TSTAT wakeup_task (UINT);
TSTAT get_task_stat (UINT);
void dispatch_task (UINT);
void sleep (SHORT);
void task_timerproc (void);

