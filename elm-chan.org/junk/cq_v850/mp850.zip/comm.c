#include <string.h>
#include "comm.h"
#include "taskmgr.h"


#define FIFO_SIZE 128


static volatile int TxRun;
static volatile struct
{
	int		rptr;
	int		wptr;
	int		count;
	BYTE	buff[FIFO_SIZE];
} TxFifo, RxFifo;




#pragma interrupt INTUA0R ISR_uart_rcvr
__interrupt
void ISR_uart_rcvr (void)
{
	BYTE d;
	int n;


	d = UA0RX;
	n = RxFifo.count;
	if (n < FIFO_SIZE) {
		n++;
		RxFifo.count = n;
		n = RxFifo.wptr;
		RxFifo.buff[n] = d;
		RxFifo.wptr = (n + 1) % FIFO_SIZE;
	}
}




#pragma interrupt INTUA0T ISR_uart_xmit
__interrupt
void ISR_uart_xmit (void)
{
	int n;


	n = TxFifo.count;
	if (n) {
		n--;
		TxFifo.count = n;
		n = TxFifo.rptr;
		UA0TX = TxFifo.buff[n];
		TxFifo.rptr = (n + 1) % FIFO_SIZE;
	} else {
		TxRun = 0;
	}
}




int uart_test (void)
{
	return RxFifo.count;
}




BYTE uart_get (void)
{
	BYTE d;
	int n;


	do; while (!RxFifo.count);

	n = RxFifo.rptr;
	d = RxFifo.buff[n];
	RxFifo.rptr = (n + 1) % FIFO_SIZE;
	__DI();
	RxFifo.count--;
	__EI();

	return d;
}




void uart_put (BYTE d)
{
	int n;


	while (TxFifo.count >= FIFO_SIZE) sleep(0);

	n = TxFifo.wptr;
	TxFifo.buff[n] = d;
	TxFifo.wptr = (n + 1) % FIFO_SIZE;
	__DI();
	TxFifo.count++;
	if (!TxRun) {
		TxRun = 1;
		UA0TIF = 1;
	}
	__EI();
}




void uart_init (void)
{
	UA0RMK = 1;		/* Disable Rx interrupt */
	UA0TMK = 1;		/* Disable Tx interrupt */

	/* Clear Tx/Rx FIFOs */
	TxFifo.rptr = TxFifo.wptr = TxFifo.count = 0;
	RxFifo.rptr = RxFifo.wptr = RxFifo.count = 0;
	TxRun = 0;

	/* Enable Tx/Rx interruptrs */
	UA0RIC = 0x05;	/* Enable Rx interrupt with priority level 5 */
	UA0TIC = 0x07;	/* Enable Tx interrupt with priority level 7 */
}
