/*---------------------------------------------------------------*/
/* FAT file system module test program R0.05      (C)ChaN, 2007  */
/*---------------------------------------------------------------*/


#include <string.h>
#include <stdio.h>
#include "monitor.h"
#include "diskio.h"
#include "ff.h"


/*---------------------------------------------------------*/
/* Constants                                               */
/*---------------------------------------------------------*/

const char *tacc[] = {
	"0", "0", "0", "0", "0", "0", "0", "0",
	"1ns", "10ns", "100ns", "1us", "10us", "100us", "1ms", "10ms",
	"1.2ns", "12ns", "120ns", "1.2us", "12us", "120us",  "1.2ms", "12ms",
	"1.3ns", "13ns", "130ns", "1.3us", "13us", "130us", "1.3ms", "13ms",
	"1.5ns", "15ns", "150ns", "1.5us", "15us", "150us", "1.5ms", "15ms",
	"2ns", "20ns", "200ns", "2us", "20us", "200us", "2ms", "20ms",
	"2.5ns", "25ns", "250ns", "2.5us", "25us", "250us", "2.5ms", "25ms",
	"3ns", "30ns", "300ns", "3us", "30us", "300us", "3ms", "30ms",
	"3.5ns", "35ns", "350ns", "3.5us", "35us", "350us", "3.5ms", "35ms",
	"4ns", "40ns", "400ns", "4us", "40us", "400us", "4ms", "40ms",
	"4.5ns", "45ns", "450ns", "4.5us", "45us", "450us", "4.5ms", "45ms",
	"5ns", "50ns", "500ns", "5us", "50us", "500us", "5ms", "50ms",
	"5.5ns", "55ns", "550ns", "5.5us", "55us", "550us", "5.5ms", "55ms",
	"6ns", "60ns", "600ns", "6us", "60us", "600us", "6ms", "60ms",
	"7ns", "70ns", "700ns", "7us", "70us", "700us", "7ms", "70ms",
	"8ns", "80ns", "800ns", "8us", "80us", "800us", "8ms", "80ms"
};

const char *tspd[] = {
	"0", "0", "0", "0", "0", "0", "0", "0",
	"100kbps", "1Mbps", "10Mbps", "100Mbps", "0", "0", "0", "0",
	"120kbps", "1.2Mbps", "12Mbps", "120Mbps", "0", "0", "0", "0",
	"130kbps", "1.3Mbps", "13Mbps", "130Mbps", "0", "0", "0", "0",
	"150kbps", "1.5Mbps", "15Mbps", "150Mbps", "0", "0", "0", "0",
	"200kbps", "2Mbps", "20Mbps", "200Mbps", "0", "0", "0", "0",
	"250kbps", "2.5Mbps", "25Mbps", "250Mbps", "0", "0", "0", "0",
	"300kbps", "3Mbps", "30Mbps", "300Mbps", "0", "0", "0", "0",
	"350kbps", "3.5Mbps", "35Mbps", "350Mbps", "0", "0", "0", "0",
	"400kbps", "4Mbps", "40Mbps", "400Mbps", "0", "0", "0", "0",
	"450kbps", "4.5Mbps", "45Mbps", "450Mbps", "0", "0", "0", "0",
	"500kbps", "5Mbps", "50Mbps", "500Mbps", "0", "0", "0", "0",
	"550kbps", "5.5Mbps", "55Mbps", "550Mbps", "0", "0", "0", "0",
	"600kbps", "6Mbps", "60Mbps", "600Mbps", "0", "0", "0", "0",
	"700kbps", "7Mbps", "70Mbps", "700Mbps", "0", "0", "0", "0",
	"800kbps", "8Mbps", "80Mbps", "800Mbps", "0", "0", "0", "0"
};

const char *tvddmin[] = {
	"0.5", "1", "5", "10", "25", "35", "60", "100"
};

const char *tvddmax[] = {
	"1", "5", "10", "25", "35", "45", "80", "200"
};



/*---------------------------------------------------------*/
/* Work Area                                               */
/*---------------------------------------------------------*/

DWORD Port = 1;				/* Port number */
DWORD Bps = 312500;			/* BPS */

DWORD acc_size;				/* Work register for fs command */
WORD acc_files, acc_dirs;
FILINFO finfo;

char linebuf[120];			/* Console input buffer */

FATFS fatfs;				/* File system object for logical drive */
BYTE Buff[4096];			/* Working buffer */



/*---------------------------------------------------------*/
/* User Provided Timer Function for FatFs module           */
/*---------------------------------------------------------*/
/* This is a real time clock service to be called from     */
/* FatFs module. Any valid time must be returned even if   */
/* the system does not support a real time clock.          */


DWORD get_fattime (void)
{
	DWORD tmr;
	SYSTEMTIME tm;


	GetLocalTime(&tm);

	tmr =	  ((DWORD)tm.wYear << 25)
			| ((DWORD)tm.wMonth << 21)
			| ((DWORD)tm.wDay << 16)
			| (WORD)(tm.wHour << 11)
			| (WORD)(tm.wMinute << 5)
			| (WORD)(tm.wSecond >> 1);

	return tmr;
}



/*--------------------------------------------------------------------------*/
/* Monitor                                                                  */


static
FRESULT scan_files (char* path)
{
	DIR dirs;
	FRESULT res;
	BYTE i;


	if ((res = f_opendir(&dirs, path)) == FR_OK) {
		i = strlen(path);
		while (((res = f_readdir(&dirs, &finfo)) == FR_OK) && finfo.fname[0]) {
			if (finfo.fattrib & AM_DIR) {
				acc_dirs++;
				*(path+i) = '/'; strcpy(path+i+1, &finfo.fname[0]);
				res = scan_files(path);
				*(path+i) = '\0';
				if (res != FR_OK) break;
			} else {
				acc_files++;
				acc_size += finfo.fsize;
			}
		}
	}

	return res;
}



static
void put_rc (FRESULT rc)
{
	const char *p;
	static const char str[] =
		"OK\0" "NOT_READY\0" "NO_FILE\0" "FR_NO_PATH\0" "INVALID_NAME\0" "INVALID_DRIVE\0"
		"DENIED\0" "EXIST\0" "RW_ERROR\0" "WRITE_PROTECTED\0" "NOT_ENABLED\0"
		"NO_FILESYSTEM\0" "INVALID_OBJECT\0" "MKFS_ABORTED\0";
	FRESULT i;

	for (p = str, i = 0; i != rc && *p; i++) {
		while(*p++);
	}
	printf("rc=%u FR_%s\n", (UINT)rc, p);
}


static
DWORD get_bits (const BYTE* ptr, int ofs, int len)
{
	BYTE m;
	DWORD n;


	m = 0x80 >> (ofs & 7);
	ptr += ofs / 8;
	n = 0;
	while (len) {
		n <<= 1;
		if (*ptr & m) n++;
		m >>= 1;
		if (!m) {
			m = 0x80;
			ptr++;
		}
		len--;
	}
	return n;
}



BOOL load_settings (int argc, char *argv[])
{
	char *cp, *cmdlst[20], cmdbuff[128];
	int cmd;


	cmd = 0; cp = cmdbuff;

	/* Get command line parameters */
	while(--argc && (cmd < (sizeof(cmdlst) / sizeof(cmdlst[0]) - 1)))
		cmdlst[cmd++] = *++argv;
	cmdlst[cmd] = NULL;

	/* Analyze command line parameters... */
	for(cmd = 0; cmdlst[cmd] != NULL; cmd++) {
		cp = cmdlst[cmd];
		if(*cp == '-') {
			cp++;
			if (tolower(*cp++) != 'p' || tolower(*cp++) != 'b') return FALSE;
			Port = strtoul(cp, &cp, 10);
			if(*cp == ':') Bps = strtoul(cp+1, &cp, 10);
			if(*cp >= ' ') return FALSE;
		} /* if */
		else {
			return FALSE;
		}

	} /* for */

	return TRUE;
}



/*-----------------------------------------------------------------------*/
/* Main                                                                  */


int main (int argc, char *argv[])
{
	char *ptr, *ptr2;
	long p1, p2, p3;
	BYTE res, b1;
	WORD w1;
	UINT s1, s2, cnt, blen = sizeof(Buff);
	DWORD ofs = 0, sect = 0;
	FATFS *fs;				/* Pointer to file system object */
	DIR dir;				/* Directory object */
	FIL file1, file2;		/* File objects */


	if (!load_settings(argc, argv)) {
		printf("Usage: spimmc -pb<n>:<bps>\n");
		return 2;
	}
	if (!init_spibridge(Port, Bps)) {
		printf("SPI bridge initialization failed. (COM%u:%ubps)\n", Port, Bps);
		return 1;
	}
	printf("FatFs module test monitor for Win32\n");

	for (;;) {
		printf(">");
		gets(ptr = linebuf);

		switch (*ptr++) {

		case 'd' :
			switch (*ptr++) {
			case 'd' :	/* dd [<sector>] - Dump secrtor */
				if (!xatoi(&ptr, &p2)) p2 = sect;
				res = disk_read(0, Buff, p2, 1);
				if (res) { printf("rc=%d\n", (WORD)res); break; }
				sect = p2 + 1;
				printf("Sector:%lu\n", p2);
				for (ptr=(char*)Buff, ofs = 0; ofs < 0x200; ptr+=16, ofs+=16)
					put_dump((BYTE*)ptr, ofs, 16);
				break;

			case 'i' :	/* di - Initialize disk */
				printf("rc=%d\n", disk_initialize(0));
				break;

			case 's' :	/* ds - Show disk status */
				if (disk_ioctl(0, GET_SECTOR_COUNT, &p2) == RES_OK)
					{ printf("Drive size: %lu sectors\n", p2); }
				if (disk_ioctl(0, GET_SECTOR_SIZE, &w1) == RES_OK)
					{ printf("Sector size: %u\n", w1); }
				if (disk_ioctl(0, GET_BLOCK_SIZE, &p2) == RES_OK)
					{ printf("Erase block size: %lu sectors\n", p2); }
				if (disk_ioctl(0, MMC_GET_TYPE, &b1) == RES_OK)
					{ printf("MMC/SDC type: %u\n", b1); }
				if (disk_ioctl(0, MMC_GET_CSD, Buff) == RES_OK) {
					printf("[CSD]     +0 +1 +2 +3 +4 +5 +6 +7 +8 +9 +A +B +C +D +E +F\n");
					put_dump(Buff, 0, 16);
					s1 = get_bits(Buff, 0, 2);
					printf("CSD_STRUCTURE = %d", s1);
					switch (s1) {
					case 0 :
						printf(" (Ver 1.0)");
					case 2:
						putchar('\n');
						s1 = get_bits(Buff, 8, 8);
						printf("TACC = 0x%X (%s)\n", s1, tacc[s1 & 127]);
						printf("NSAC = %uclock\n", get_bits(Buff, 16, 8) * 100);
						s1 = get_bits(Buff, 24, 8);
						printf("TRAN_SPEED = 0x%X (%s)\n", s1, tspd[s1 & 127]);
						_itoa(get_bits(Buff, 32, 12), linebuf, 2);
						printf("CCC = 0b%s\n", linebuf);
						printf("READ_BL_LEN = %u\n", 1L << get_bits(Buff, 44, 4));
						s1 = get_bits(Buff, 48, 4);
						printf("READ_BL_PARTIAL = %s\n", (s1 & 8) ? "Yes" : "No");
						printf("WRITE_BLK_MISALIGN = %s\n", (s1 & 4) ? "Yes" : "No");
						printf("READ_BLK_MISALIGN = %s\n", (s1 & 2) ? "Yes" : "No");
						printf("DSR_IMP = %s\n", (s1 & 1) ? "Yes" : "No");
						printf("C_SIZE = %u\n", get_bits(Buff, 54, 12));
						s1 = get_bits(Buff, 66, 3);
						printf("VDD_R_CURR_MIN = %u (%smA)\n", s1, tvddmin[s1]);
						s1 = get_bits(Buff, 69, 3);
						printf("VDD_R_CURR_MAX = %u (%smA)\n", s1, tvddmax[s1]);
						s1 = get_bits(Buff, 72, 3);
						printf("VDD_W_CURR_MIN = %u (%smA)\n", s1, tvddmin[s1]);
						s1 = get_bits(Buff, 75, 3);
						printf("VDD_W_CURR_MAX = %u (%smA)\n", s1, tvddmax[s1]);
						s1 = get_bits(Buff, 78, 3);
						printf("C_SIZE_MULT = %u (%u)\n", s1, 4L << s1);
						printf("ERASE_BLK_EN = %s\n", get_bits(Buff, 81, 1) ? "Yes" : "No");
						printf("SECTOR_SIZE = %ublock\n", get_bits(Buff, 82, 7) + 1);
						printf("WP_GRP_SIZE = %usector\n", get_bits(Buff, 89, 7) + 1);
						printf("WP_GRP_ENABLE = %s\n", get_bits(Buff, 96, 1) ? "Yes" : "No");
						printf("R2W_FACTOR = %u\n", 1L << get_bits(Buff, 99, 3));
						printf("WRITE_BL_LEN = %u\n", 1L << get_bits(Buff, 102, 4));
						printf("WP_BL_PARTIAL = %s\n", get_bits(Buff, 106, 1) ? "Yes" : "No");
						printf("FILE_FORMAT_GRP = %u\n", get_bits(Buff, 112, 1));
						printf("COPY = %u\n", get_bits(Buff, 113, 1));
						printf("PERM_WRITE_PROTECT = %u\n", get_bits(Buff, 114, 1));
						printf("TEMP_WRITE_PROTECT = %u\n", get_bits(Buff, 115, 1));
						printf("FILE_FORMAT = %u\n", get_bits(Buff, 116, 2));
						break;
					case 1:
						printf(" (Ver 2.0)\n");
						s1 = get_bits(Buff, 8, 8);
						printf("TACC = 0x%X (%s)\n", s1, tacc[s1 & 127]);
						printf("NSAC = %uclk\n", get_bits(Buff, 16, 8));
						s1 = get_bits(Buff, 24, 8);
						printf("TRAN_SPEED = 0x%X (%s)\n", s1, tspd[s1 & 127]);
						_itoa(get_bits(Buff, 32, 12), linebuf, 2);
						printf("CCC = 0b%s\n", linebuf);
						printf("READ_BL_LEN = %u\n", 1L << get_bits(Buff, 44, 4));
						s1 = get_bits(Buff, 48, 4);
						printf("READ_BL_PARTIAL = %s\n", (s1 & 8) ? "Yes" : "No");
						printf("WRITE_BLK_MISALIGN = %s\n", (s1 & 4) ? "Yes" : "No");
						printf("READ_BLK_MISALIGN = %s\n", (s1 & 2) ? "Yes" : "No");
						printf("DSR_IMP = %s\n", (s1 & 1) ? "Yes" : "No");
						printf("C_SIZE = %u\n", get_bits(Buff, 58, 22));
						s1 = get_bits(Buff, 78, 3);
						printf("ERASE_BLK_EN = %s\n", get_bits(Buff, 81, 1) ? "Yes" : "No");
						printf("SECTOR_SIZE = %ublk\n", get_bits(Buff, 82, 7) + 1);
						printf("WP_GRP_SIZE = %usect\n", get_bits(Buff, 89, 7) + 1);
						printf("WP_GRP_ENABLE = %s\n", get_bits(Buff, 96, 1) ? "Yes" : "No");
						printf("R2W_FACTOR = %u\n", 1L << get_bits(Buff, 99, 3));
						printf("WRITE_BL_LEN = %u\n", 1L << get_bits(Buff, 102, 4));
						printf("WP_BL_PARTIAL = %s\n", get_bits(Buff, 106, 1) ? "Yes" : "No");
						printf("FILE_FORMAT_GRP = %u\n", get_bits(Buff, 112, 1));
						printf("COPY = %u\n", get_bits(Buff, 113, 1));
						printf("PERM_WRITE_PROTECT = %u\n", get_bits(Buff, 114, 1));
						printf("TEMP_WRITE_PROTECT = %u\n", get_bits(Buff, 115, 1));
						printf("FILE_FORMAT = %u\n", get_bits(Buff, 116, 2));
						break;
					}
					putchar('\n');


				}
				if (disk_ioctl(0, MMC_GET_CID, Buff) == RES_OK) {
					printf("[CID]     +0 +1 +2 +3 +4 +5 +6 +7 +8 +9 +A +B +C +D +E +F\n");
					put_dump(Buff, 0, 16);
					printf("MID = 0x%02X\n", get_bits(Buff, 0, 8));
					memcpy(linebuf, &Buff[1], 2); linebuf[2] = 0;
					printf("OID = \"%s\"\n", linebuf);
					memcpy(linebuf, &Buff[3], 5); linebuf[5] = 0;
					printf("PNM = \"%s\"\n", linebuf);
					printf("PRV = 0x%02X\n", get_bits(Buff, 64, 8));
					printf("PSN = 0x%08X\n", get_bits(Buff, 72, 32));
					s1 = get_bits(Buff, 108, 12);
					printf("MDT = 0x%03X (%u-%u)\n", s1, s1 / 16 + 2000, s1 & 15);
					putchar('\n');
				}
				if (disk_ioctl(0, MMC_GET_OCR, Buff) == RES_OK) {
					printf("[OCR]     +0 +1 +2 +3\n");
					put_dump(Buff, 0, 4);

					putchar('\n');
				}
				if (disk_ioctl(0, MMC_GET_SDSTAT, Buff) == RES_OK) {
					printf("[SD Stat] +0 +1 +2 +3 +4 +5 +6 +7 +8 +9 +A +B +C +D +E +F\n");
					for (s1 = 0; s1 < 64; s1 += 16) put_dump(Buff+s1, s1, 16);
					printf("DATA_BUS_WIDTH = %u\n", 1L << get_bits(Buff, 0, 2));
					printf("SECURED_MODE = %s\n", get_bits(Buff, 3, 1) ? "Yes" : "No");
					printf("SD_CARD_TYPE = 0x%04X\n", get_bits(Buff, 16, 16));
					printf("SIZE_OF_PROTECTED_AREA = %u\n", get_bits(Buff, 32, 32));
					printf("SPEED_CLASS = %u\n", get_bits(Buff, 64, 8) * 2);
					s1 = get_bits(Buff, 72, 8);
					if (s1 < 255) printf("PERFORMANCE_MOVE = %uMB/s\n", s1);
					else printf("PERFORMANCE_MOVE = Infinite\n");
					s1 = get_bits(Buff, 80, 4);
					if (s1) printf("AU_SIZE = %uKB\n", 8L << s1); 
					else printf("AU_SIZE = 0\n");
					s1 = get_bits(Buff, 88, 16);
					if (s1) printf("ERASE_SIZE = %uAU\n", s1);
					else printf("ERASE_SIZE = Not Supported\n");
					s1 = get_bits(Buff, 104, 6);
					if (s1) printf("ERASE_TIMEOUT = %usec\n", s1);
					else printf("ERASE_TIMEOUT = Not Supported\n");
					printf("ERASE_OFFSET = %usec\n", get_bits(Buff, 110, 2));

					putchar('\n');
				}
				break;
			}
			break;

		case 'b' :
			switch (*ptr++) {
			case 'd' :	/* bd <addr> - Dump R/W buffer */
				if (!xatoi(&ptr, &p1)) break;
				for (ptr=(char*)&Buff[p1], ofs = p1, cnt = 32; cnt; cnt--, ptr+=16, ofs+=16)
					put_dump((BYTE*)ptr, ofs, 16);
				break;

			case 'e' :	/* be <addr> [<data>] ... - Edit R/W buffer */
				if (!xatoi(&ptr, &p1)) break;
				if (xatoi(&ptr, &p2)) {
					do {
						Buff[p1++] = (BYTE)p2;
					} while (xatoi(&ptr, &p2));
					break;
				}
				for (;;) {
					printf("%04X %02X-", (WORD)(p1), (WORD)Buff[p1]);
					gets(ptr = linebuf);
					if (*ptr == '.') break;
					if (*ptr < ' ') { p1++; continue; }
					if (xatoi(&ptr, &p2))
						Buff[p1++] = (BYTE)p2;
					else
						printf("???\n");
				}
				break;

			case 'r' :	/* br <sector> [<n>] - Read disk into R/W buffer */
				if (!xatoi(&ptr, &p2)) break;
				if (!xatoi(&ptr, &p3)) p3 = 1;
				printf("\nrc=%u", disk_read(0, Buff, p2, (BYTE)p3));
				break;

			case 'w' :	/* bw <sector> [<n>] - Write R/W buffer into disk */
				if (!xatoi(&ptr, &p2)) break;
				if (!xatoi(&ptr, &p3)) p3 = 1;
				printf("\nrc=%u", disk_write(0, Buff, p2, (BYTE)p3));
				break;

			case 'f' :	/* bf <n> - Fill working buffer */
				if (!xatoi(&ptr, &p1)) break;
				memset(Buff, (BYTE)p1, sizeof(Buff));
				break;

			}
			break;

		case 'f' :
			switch (*ptr++) {

			case 'i' :	/* fi - Force initialized the logical drive */
				put_rc(f_mount(0, &fatfs));
				break;

			case 's' :	/* fs [<path>] - Show logical drive status */
				res = f_getfree(ptr, (DWORD*)&p2, &fs);
				if (res) { put_rc(res); break; }
				printf("FAT type = %u\nBytes/Cluster = %lu\nNumber of FATs = %u\n"
						"Root DIR entries = %u\nSectors/FAT = %lu\nNumber of clusters = %lu\n"
						"FAT start (lba) = %lu\nDIR start (lba,clustor) = %lu\nData start (lba) = %lu\n\n",
						(WORD)fs->fs_type, (DWORD)fs->sects_clust * 512, (WORD)fs->n_fats,
						fs->n_rootdir, fs->sects_fat, (DWORD)fs->max_clust - 2,
						fs->fatbase, fs->dirbase, fs->database
				);
				acc_size = acc_files = acc_dirs = 0;
				res = scan_files(ptr);
				if (res) { put_rc(res); break; }
				printf("%u files, %lu bytes.\n%u folders.\n"
					   "%lu KB total disk space.\n%lu KB available.\n",
						acc_files, acc_size, acc_dirs,
						(fs->max_clust - 2) * (fs->sects_clust / 2), p2 * (fs->sects_clust / 2)
				);
				break;

			case 'l' :	/* fl [<path>] - Directory listing */
				res = f_opendir(&dir, ptr);
				if (res) { put_rc(res); break; }
				p1 = s1 = s2 = 0;
				for(;;) {
					res = f_readdir(&dir, &finfo);
					if ((res != FR_OK) || !finfo.fname[0]) break;
					if (finfo.fattrib & AM_DIR) {
						s2++;
					} else {
						s1++; p1 += finfo.fsize;
					}
					printf("%c%c%c%c%c %u/%02u/%02u %02u:%02u %9lu  %s\n", 
							(finfo.fattrib & AM_DIR) ? 'D' : '-',
							(finfo.fattrib & AM_RDO) ? 'R' : '-',
							(finfo.fattrib & AM_HID) ? 'H' : '-',
							(finfo.fattrib & AM_SYS) ? 'S' : '-',
							(finfo.fattrib & AM_ARC) ? 'A' : '-',
							(finfo.fdate >> 9) + 1980, (finfo.fdate >> 5) & 15, finfo.fdate & 31,
							(finfo.ftime >> 11), (finfo.ftime >> 5) & 63,
							finfo.fsize, &(finfo.fname[0]));
				}
				printf("%4u File(s),%10lu bytes total\n%4u Dir(s)", s1, p1, s2);
				if (f_getfree(ptr, (DWORD*)&p1, &fs) == FR_OK)
					printf(", %10lu bytes free\n", p1 * fs->sects_clust * 512);
				break;

			case 'o' :	/* fo <mode> <file> - Open a file */
				if (!xatoi(&ptr, &p1)) break;
				put_rc(f_open(&file1, ptr, (BYTE)p1));
				break;

			case 'c' :	/* fc - Close a file */
				put_rc(f_close(&file1));
				break;

			case 'e' :	/* fe - Seek file pointer */
				if (!xatoi(&ptr, &p1)) break;
				res = f_lseek(&file1, p1);
				put_rc(res);
				if (res == FR_OK)
					printf("\nfptr = %lu(0x%lX)", file1.fptr, file1.fptr);
				break;

			case 'r' :	/* fr <len> - read file */
				if (!xatoi(&ptr, &p1)) break;
				while (p1) {
					if ((UINT)p1 >= blen)	{ cnt = blen; p1 -= blen; }
					else 					{ cnt = p1; p1 = 0; }
					res = f_read(&file1, Buff, cnt, &s2);
					if (res != FR_OK) { put_rc(res); break; }
					if (cnt != s2) break;
				}
				break;

			case 'd' :	/* fd <len> - read and dump file from current fp */
				if (!xatoi(&ptr, &p1)) break;
				ofs = file1.fptr;
				while (p1) {
					if ((UINT)p1 >= 16) { cnt = 16; p1 -= 16; }
					else 				{ cnt = p1; p1 = 0; }
					res = f_read(&file1, Buff, cnt, &cnt);
					if (res != FR_OK) { put_rc(res); break; }
					if (!cnt) break;
					put_dump(Buff, ofs, cnt);
					ofs += 16;
				}
				break;

			case 'w' :	/* fw <len> <val> - write file */
				if (!xatoi(&ptr, &p1) || !xatoi(&ptr, &p2)) break;
				memset(Buff, (BYTE)p2, blen);
				while (p1) {
					if ((UINT)p1 >= blen) { cnt = blen; p1 -= blen; }
					else 				  { cnt = p1; p1 = 0; }
					res = f_write(&file1, Buff, cnt, &s2);
					if (res != FR_OK) { put_rc(res); break; }
					if (cnt != s2) break;
				}
				break;

			case 'n' :	/* fn <old_name> <new_name> - Change file/dir name */
				while (*ptr == ' ') ptr++;
				ptr2 = strchr(ptr, ' ');
				if (!ptr2) break;
				*ptr2++ = 0;
				while (*ptr2 == ' ') ptr2++;
				put_rc(f_rename(ptr, ptr2));
				break;

			case 'u' :	/* fu <name> - Unlink a file or dir */
				put_rc(f_unlink(ptr));
				break;

			case 'k' :	/* fk <name> - Create a directory */
				put_rc(f_mkdir(ptr));
				break;

			case 'a' :	/* fa <atrr> <mask> <name> - Change file/dir attribute */
				if (!xatoi(&ptr, &p1) || !xatoi(&ptr, &p2)) break;
				put_rc(f_chmod(ptr, (BYTE)p1, (BYTE)p2));
				break;

			case 'x' : /* fx <src_name> <dst_name> - Copy file */
				while (*ptr == ' ') ptr++;
				ptr2 = strchr(ptr, ' ');
				if (!ptr2) break;
				*ptr2++ = 0;
				while (*ptr2 == ' ') ptr2++;
				printf("\nOpening \"%s\"", ptr);
				res = f_open(&file1, ptr, FA_OPEN_EXISTING | FA_READ);
				if (res) {
					put_rc(res);
					break;
				}
				printf("\nCreating \"%s\"", ptr2);
				res = f_open(&file2, ptr2, FA_CREATE_ALWAYS | FA_WRITE);
				if (res) {
					put_rc(res);
					f_close(&file1);
					break;
				}
				printf("\nCopying...");
				p1 = 0;
				for (;;) {
					res = f_read(&file1, Buff, sizeof(Buff), &s1);
					if (res || s1 == 0) break;   /* error or eof */
					res = f_write(&file2, Buff, s1, &s2);
					p1 += s2;
					if (res || s2 < s1) break;   /* error or disk full */
				}
				printf("\n%lu bytes copied.", p1);
				f_close(&file1);
				f_close(&file2);
				break;
#if _USE_MKFS != 0
			case 'm' :	/* fm <partition rule> <cluster size> - Create file system */
				if (!xatoi(&ptr, &p1)) break;
				if (!xatoi(&ptr, &p2)) break;
				printf("\nThe card will be formatted. Are you sure? (Y/n)=");
				fgets(ptr, sizeof(linebuf), stdin);
				if (*ptr != 'Y') break;
				put_rc(f_mkfs(0, (BYTE)p1, (WORD)p2));
				break;
#endif
			}
			break;

		}
	}

}


