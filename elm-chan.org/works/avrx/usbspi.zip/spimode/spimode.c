/*-------------------------------------------------------------*/
/* SPI bridge mode setup tool R0.01 (C)ChaN,2007               */
/*-------------------------------------------------------------*/


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <process.h>
#include <windows.h>


/* Serial to SPI bridge escaped command */

#define	FLAG			0xFF
#define	SPI_NOP			0
#define	SPI_ENABLE		1
#define	SPI_DISABLE		2
#define	SPI_RCVR		3
#define	SPI_RCVZ		4
#define	SPI_WAIT		5
#define	SPI_RESET		6
#define	SPI_SCK			7
#define	SPI_SETDLY		8
#define	SPI_SETBIDIR	9
#define	SPI_WRPORT		10
#define	SPI_RDPORT		11
#define	SPI_WRDDR		12
#define	SPI_RDDDR		13
#define	SPI_RDPIN		14
#define	SPI_SETMODE		15



/*-----------------------------------------------------------------------
  Global variables (initialized by load_commands())
-----------------------------------------------------------------------*/

DWORD SpiMode = 9;
char PortNum[20] = "\\\\.\\COM1";


DCB dcb = { sizeof(DCB),
			115200, TRUE, FALSE, FALSE, FALSE,
			DTR_CONTROL_DISABLE, FALSE,
			TRUE, FALSE, FALSE, FALSE, FALSE,
			RTS_CONTROL_ENABLE, FALSE, 0, 0,
			10, 10,
			8, NOPARITY, ONESTOPBIT, '\x11', '\x13', '\xFF', '\xFF', 0 };

COMMTIMEOUTS commtimeouts1 = { 0, 1, 300, 1, 300};

HANDLE hComm = INVALID_HANDLE_VALUE;



/*-----------------------------------------------------------------------
  Messages
-----------------------------------------------------------------------*/


void output_usage ()
{
	const char *usage = {
		"SPI bridge driver mode setup tool R0.01 (C)ChaN,2007  http://elm-chan.org/\n\n"
		"Usage: spimode [-pb<n>[:<baud>]] <mode>\n"
		" <n>: port number\n"
		" <baud>: baud rate\n"
		" <mode>: SPI driver mode (0..2)\n"
	};


	printf(usage);
}



/*-----------------------------------------------------------------------
  Command line analysis
-----------------------------------------------------------------------*/


int load_commands (int argc, char **argv)
{
	char *cp, *cmdlst[20], cmdbuff[256];
	int cmd;


	cmd = 0; cp = cmdbuff;

	/* Get command line parameters */
	while(--argc && (cmd < (sizeof(cmdlst) / sizeof(cmdlst[0]) - 1)))
		cmdlst[cmd++] = *++argv;
	cmdlst[cmd] = NULL;

	/* Analyze command line parameters... */
	for(cmd = 0; cmdlst[cmd] != NULL; cmd++) {
		cp = cmdlst[cmd];

		if(*cp == '-') {	/* Command switches... */
			cp++;
			switch (tolower(*cp++)) {
				case 'p' :	/* -p{c|l|v|b}<num> */
					if (*cp++ != 'b') return 9;
					sprintf(PortNum, "\\\\.\\COM%u", strtoul(cp, &cp, 10));
					if(*cp == ':')
						dcb.BaudRate = strtoul(cp+1, &cp, 10);
					break;

				default :	/* invalid command */
					return 9;
			} /* switch */
			if(*cp >= ' ') return 9;	/* option trails garbage */
		} /* if */

		else {	/* Mode value */
			SpiMode = strtoul(cp, &cp, 10);
		} /* else */

	} /* for */

	if (SpiMode > 2) return 9;
	return 0;

}



int main (int argc, char **argv)
{
	int rc, n;
	BYTE cmd_enable[] = {0, FLAG, SPI_ENABLE};
	BYTE cmd_disable[] = {FLAG, SPI_DISABLE};
	BYTE cmd_setmode[] = {FLAG, SPI_SETMODE, 0};
	BYTE buff[2];


	if(rc = load_commands(argc, argv)) { 
		if(rc == 9) output_usage();
		return rc;
	}

	/* Open control port with an SPI bridge */
	hComm = CreateFile(PortNum, GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if(hComm == INVALID_HANDLE_VALUE) {
		fprintf(stderr, "%s could not be opened.\n", PortNum);
		return 5;
	}
	SetCommTimeouts(hComm, &commtimeouts1);
	SetCommState(hComm, &dcb);	/* Put the SPI bridge to Cooked Mode */
	Sleep(100);

	WriteFile(hComm, cmd_enable, sizeof(cmd_enable), &n, NULL);
	ReadFile(hComm, buff, 1, &n, NULL);
	if (n == 1 && buff[0] == SPI_ENABLE) {
		cmd_setmode[2] = (BYTE)SpiMode;
		WriteFile(hComm, cmd_setmode, sizeof(cmd_setmode), &n, NULL);
		WriteFile(hComm, cmd_disable, sizeof(cmd_disable), &n, NULL);
		ReadFile(hComm, buff, 2, &n, NULL);
		if (n == 2 && buff[0] == SPI_SETMODE) {
			fprintf(stderr, "SPI driver mode is set to %u.\n", SpiMode); 
			rc = 0;
		} else {
			fprintf(stderr, "Bridge command is rejected\n"); 
			rc = 1;
		}
	} else {
		fprintf(stderr, "No SPI bridge on the %s\n", PortNum); 
		rc = 2;
	}



	if (hComm != INVALID_HANDLE_VALUE) CloseHandle(hComm);

	return 0;
}

