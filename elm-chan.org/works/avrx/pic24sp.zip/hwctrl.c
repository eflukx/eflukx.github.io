/*-----------------------------------------------------------------------*/
/*  Platform dependent functions for PIC24SP  R0.02c                     */
/*-----------------------------------------------------------------------*/
/* R0.01  Nov 11, '07  First stable                                      */
/* R0.02  Dec  8, '07  Improved writing speed on SPI bridge              */
/* R0.02a Dec 10, '07  Fixed check_adapter() can fail                    */
/* R0.02b Dec 29, '07  Fixed to support auto-baud on SPI bridge          */
/* R0.02c Jan  8, '09  Fixed unintentional reset on AVRSP-LPT adapter    */
/*-----------------------------------------------------------------------*/

#include <stdio.h>
#include <string.h>
#include <conio.h>
#include <windows.h>
#include "pic24sp.h"
#include "hwctrl.h"


#define COM_DAT	((WORD)(PortBase + C_DAT))
#define COM_IMR	((WORD)(PortBase + C_IMR))
#define COM_ISR	((WORD)(PortBase + C_ISR))
#define COM_FCR	((WORD)(PortBase + C_FCR))
#define COM_LCR	((WORD)(PortBase + C_LCR))
#define COM_MCR	((WORD)(PortBase + C_MCR))
#define COM_LSR	((WORD)(PortBase + C_LSR))
#define COM_MSR	((WORD)(PortBase + C_MSR))
#define COM_SCR	((WORD)(PortBase + C_SCR))
#define LPT_DAT	((WORD)(PortBase + L_DAT))
#define LPT_STA	((WORD)(PortBase + L_STA))
#define LPT_CTL	((WORD)(PortBase + L_CTL))



/*----------------------------------------------------------------------
  Control Variables
----------------------------------------------------------------------*/

static WORD PortBase, PortType;
static HANDLE hComm = INVALID_HANDLE_VALUE;
static DWORD ModemStat;
static BOOL sig_break;
static BYTE sig_portb = 0x0F;
static char str_info[100];

static struct {
	DWORD	Rp;
	DWORD	Wp;
	DWORD	Ctr;
	BYTE	Buff[PIPE_WINDOW];
} RcvrFifo;




/*----------------------------------------------------------------------
  Module Private Functions
----------------------------------------------------------------------*/


/* Initialize GIVEIO */

static
int init_driver ()
{
	int ls = 0;
	HANDLE hdev;
	SC_HANDLE hsc, hsv;
	char filepath[_MAX_PATH], *cp;
	BOOL res;


	while (1) {
		ls++;

		if (ls >= 4)		/* Could not open, start or register giveio due to any reason. */
			return (-1);

		if (ls >= 3) {	/* Not registered. Register GIVEIO.SYS to the SCM database */
			if (SearchPath(NULL, "giveio.sys", NULL, sizeof(filepath), filepath, &cp) == 0) continue;
			if ((hsc = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS)) != NULL) {
				if ((hsv = CreateService(hsc,
										"giveio", "giveio", 
										SERVICE_ALL_ACCESS, SERVICE_KERNEL_DRIVER, SERVICE_DEMAND_START, SERVICE_ERROR_IGNORE,
										filepath,
										NULL, NULL, NULL, NULL, NULL)) != NULL) {
					CloseServiceHandle(hsv);
				} else {
					if ((hsv = OpenService(hsc, "giveio", SERVICE_ALL_ACCESS)) != NULL) {
						DeleteService(hsv);
						CloseServiceHandle(hsv);
						hsv = NULL;
					}
				}
				CloseServiceHandle(hsc);
			}
			if ((hsc == NULL) || (hsv == NULL)) continue;
		}

		if (ls >= 2) {	/* Not started. Start GIVEIO */
			if ((hsc = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS)) != NULL) {
				if ((hsv = OpenService(hsc, "giveio", SERVICE_ALL_ACCESS)) != NULL) {
					res = StartService(hsv, 0, NULL);
					CloseServiceHandle(hsv);
				}
				CloseServiceHandle(hsc);
			}
			if ((hsc == NULL) || (hsv == NULL) || (res == FALSE)) continue;
		}

		/* Open GIVEIO to clear IOPM of this process */
		hdev = CreateFile("\\\\.\\giveio", GENERIC_READ, 0, NULL,
							  OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
		if (hdev == INVALID_HANDLE_VALUE) continue;
		CloseHandle(hdev);
		break;
	} /* while */

	return (0);

}




/* Check if the COM/LPT port is present or not */

static
int check_comport (void)
{
	_outp(COM_LCR, 0x0C);
	if ((BYTE)_inp(COM_LCR) != 0x0C) return (-1);
	_outp(COM_LCR, 0x03);
	if ((BYTE)_inp(COM_LCR) != 0x03) return (-1);
	return (0);
}

static
int check_lptport (void)
{
	_outp(LPT_CTL, 0);
	_outp(LPT_DAT, 0x08);
	if ((BYTE)_inp(LPT_DAT) != 0x08) return (-1);
	_outp(LPT_DAT, 0x40);
	if ((BYTE)_inp(LPT_DAT) != 0x40) return (-1);
	return (0);
}



/* Check if the ISP cable is attached properly or not */

static
int check_adapter (void)
{
	set_mosi(1);
	delay_ms(1);
	if (!get_miso()) return 0;
	set_mosi(0);
	delay_ms(1);
	if (get_miso()) return 0;
	return 1;
}



/* Bufferred data transmission and reception for SPI bridge */

static
void send_bridge (const BYTE *buffer, DWORD count)
{
	static BYTE outbuff[256];
	static int wp = 0;
	DWORD cnt;


	if (count == 0) {	/* Zero means flush transmission buffer */
		if (wp) {
			WriteFile(hComm, outbuff, wp, &cnt, NULL);
			wp = 0;
		}
		return;
	}

	do {
		outbuff[wp++] = *buffer++;
		if (wp >= sizeof(outbuff)) {
			WriteFile(hComm, outbuff, wp, &cnt, NULL);
			wp = 0;
		}
	} while (--count);
}




static
BOOL read_bridge (BYTE *buffer, DWORD count)
{
	DWORD cnt = 0;


	send_bridge(NULL, 0);	/* flush left data in the transmission buffer */
	ReadFile(hComm, buffer, count, &cnt, NULL);
	return (cnt == count) ? TRUE : FALSE;
}



/* SPI delayed read FIFO */

static
void fifo_put (BYTE d)
{
	if (RcvrFifo.Ctr < sizeof(RcvrFifo.Buff)) {
		RcvrFifo.Buff[RcvrFifo.Wp++] = d;
		RcvrFifo.Ctr++;
		if (RcvrFifo.Wp >= sizeof(RcvrFifo.Buff))
			RcvrFifo.Wp = 0;
	}
}


static
BYTE fifo_get ()
{
	BYTE d = 0xFF;


	if (RcvrFifo.Ctr > 0) {
		d = RcvrFifo.Buff[RcvrFifo.Rp++];
		RcvrFifo.Ctr--;
		if (RcvrFifo.Rp >= sizeof(RcvrFifo.Buff))
			RcvrFifo.Rp = 0;
	}
	return d;
}



/*----------------------------------------------------------------------
  Public Functions
----------------------------------------------------------------------*/


/* Search and Open configuration file */

FILE *open_cfgfile(char *filename)
{
	FILE *fp;
	char filepath[256], *dmy;


	if ((fp = fopen(filename, "rt")) != NULL) 
		return fp;
	if (SearchPath(NULL, filename, NULL, sizeof(filepath), filepath, &dmy)) {
		if ((fp = fopen(filepath, "rt")) != NULL) 
			return fp;
	}
	return NULL;
}




/* Wait for dly msec */

void delay_ms (WORD dly)
{
	LARGE_INTEGER val1, val2;
	BYTE spicmd[3] = { PIC_WAIT, 0, 0 };


	if (PortType == TY_BRIDGE) {		/* Issue wait commadnd to SPI bridge */
		spicmd[1] = (BYTE)dly;
		spicmd[2] = (BYTE)(dly >> 8);
		send_bridge(spicmd, 3);
	}
	else {							/* Make wait using Win32 API */
		QueryPerformanceCounter(&val1);
		QueryPerformanceFrequency(&val2);
		val1.QuadPart += val2.QuadPart / 1000 * dly + val2.QuadPart / 10000 ;
		do
			QueryPerformanceCounter(&val2);
		while (val2.QuadPart < val1.QuadPart);
	}
}




/* Set reset pin level */

void set_reset (int val)	/* When val == 0, RESET is set Low. */
{
	BYTE spicmd[2] = { PIC_WRPORT, 0 };


	switch (PortType) {
	case TY_COMM :
		_outp(COM_MCR, val ? C_RES : 0);
		break;

	case TY_VCOM :
		if (val) {
			EscapeCommFunction(hComm, CLRRTS);	/* SCK = L */
			EscapeCommFunction(hComm, SETDTR);	/* RESET = H */
		} else {
			EscapeCommFunction(hComm, CLRDTR);	/* RESET = L */
		}
		break;

	case TY_BRIDGE :
		if (val) sig_portb |= 0x10;
		else	 sig_portb &= 0xEF;
		spicmd[1] = sig_portb;
		send_bridge(spicmd, 2);
		break;

	case TY_AVRSP :
		_outp(LPT_DAT, val ? B_ENA|B_RES : B_ENA);
		break;

	case TY_STK200 :
		_outp(LPT_DAT, val ? BS_RES : 0);
		break;

	case TY_XILINX :
		_outp(LPT_DAT, val ? BX_DIS2|BX_RES : BX_DIS2);
		break;

	case TY_LATTICE :
		_outp(LPT_DAT, val ? BL_RES : 0);
		break;

	case TY_ALTERA :
		_outp(LPT_DAT, val ? BA_RES : 0);
		break;
	}
}



/* Get MISO pin level */

int get_miso (void)	/* When MISO is high, return 1. */
{
	BYTE spicmd = PIC_RDPIN;
	int rv = 0;


	switch (PortType) {
	case TY_COMM :
		rv = (_inp(COM_MSR) & C_MISO) ? 1 : 0;	/* Sample MISO(DR) */
		break;

	case TY_VCOM :
		GetCommModemStatus(hComm, &ModemStat);
		rv = (ModemStat & MS_DSR_ON) ? 1 : 0;	/* Sample MISO(DR) */
		break;

	case TY_BRIDGE :
		send_bridge(&spicmd, 1);
		read_bridge(&spicmd, 1);
		rv = (spicmd & 0x20) ? 1 : 0;
		break;

	case TY_AVRSP :
		rv = ((_inp(LPT_STA) & S_BUSY) == 0) ? 1 : 0;	/* Sample MISO */
		break;

	case TY_STK200 :
		rv = (_inp(LPT_STA) & S_ACK) ? 1 : 0;	/* Sample MISO */
		break;

	case TY_XILINX :
		rv = (_inp(LPT_STA) & S_SEL) ? 1 : 0;	/* Sample MISO */
		break;

	case TY_LATTICE :
		rv = (_inp(LPT_STA) & S_ACK) ? 1 : 0;	/* Sample MISO */
		break;

	case TY_ALTERA :
		rv = ((_inp(LPT_STA) & S_BUSY) == 0) ? 1 : 0;	/* Sample MISO */
		break;
	}

	return rv;
}



/* Set MOSI pin level */

void set_mosi (int val)
{
	BYTE d, spicmd[2] = { PIC_WRPORT, 0 };


	switch (PortType) {
	case TY_COMM :
		if (val) {								/* Set MOSI(TD) */
			if (!sig_break) {
				_outp(COM_LCR, C_MOSI);
				sig_break = TRUE;
			}
		} else {
			if (sig_break) {
				_outp(COM_LCR, 0);
				sig_break = FALSE;
			}
		}
		break;

	case TY_VCOM :
		if (val) {								/* Set MOSI(TD) */
			if (!sig_break) {
				EscapeCommFunction(hComm, SETBREAK);
				sig_break = TRUE;
			}
		} else {
			if (sig_break) {
				EscapeCommFunction(hComm, CLRBREAK);
				sig_break = FALSE;
			}
		}
		break;

	case TY_BRIDGE :
		if (val) sig_portb |= 0x40;
		else	 sig_portb &= 0xBF;
		spicmd[1] = sig_portb;
		send_bridge(spicmd, 2);					/* Set MOSI */
		break;

	case TY_AVRSP :
		d = _inp(LPT_DAT);
		d = val ? d | B_MOSI : d & ~B_MOSI;
		_outp(LPT_DAT,d);						/* Set MOSI(D1) */
		break;

	case TY_STK200 :
		d = _inp(LPT_DAT);
		d = val ? d | BS_MOSI : d & ~BS_MOSI;
		_outp(LPT_DAT, d);						/* Set MOSI(D5) */
		break;

	case TY_XILINX :
		d = _inp(LPT_DAT);
		d = val ? d | BX_MOSI : d & ~BX_MOSI;
		_outp(LPT_DAT, d);						/* Set MOSI(D0) */
		break;

	case TY_LATTICE :
		d = _inp(LPT_DAT);
		d = val ? d | BL_MOSI : d & ~BL_MOSI;
		_outp(LPT_DAT, d);						/* Set MOSI(D0) */
		break;

	case TY_ALTERA :
		d = _inp(LPT_DAT);
		d = val ? d | BA_MOSI : d & ~BA_MOSI;
		_outp(LPT_DAT, d);						/* Set MOSI(D6) */
		break;
	}
}



/* Apply an SCK pulse */

void apply_sck (void)
{
	BYTE d, spicmd = PIC_SCK;


	switch (PortType) {
	case TY_COMM :
		_outp(COM_MCR, C_SCK|C_RES);	/* SCK = H */
		_outp(COM_MCR,       C_RES);	/* SCK = L */
		break;

	case TY_VCOM :
		EscapeCommFunction(hComm, SETRTS);	/* SCK = H */
		EscapeCommFunction(hComm, CLRRTS);	/* SCK = L */
		break;

	case TY_BRIDGE :
		send_bridge(&spicmd, 1);		/* SCK = H->L */
		break;

	case TY_AVRSP :
		d = _inp(LPT_DAT);
		_outp(LPT_DAT, d | B_SCK);	/* SCK = H */
		_outp(LPT_DAT, d);			/* SCK = L */
		break;

	case TY_STK200 :
		d = _inp(LPT_DAT);
		_outp(LPT_DAT, d | BS_SCK);	/* SCK = H */
		_outp(LPT_DAT, d);			/* SCK = L */
		break;

	case TY_XILINX :
		d = _inp(LPT_DAT);
		_outp(LPT_DAT, d | BX_SCK);	/* SCK = H */
		_outp(LPT_DAT, d);			/* SCK = L */
		break;

	case TY_LATTICE :
		d = _inp(LPT_DAT);
		_outp(LPT_DAT, d | BL_SCK);	/* SCK = H */
		_outp(LPT_DAT, d);			/* SCK = L */
		break;

	case TY_ALTERA :
		d = _inp(LPT_DAT);
		_outp(LPT_DAT, d | BA_SCK);	/* SCK = H */
		_outp(LPT_DAT, d);			/* SCK = L */
		break;
	}
}



/* Send a byte to the device */

void send_byte (BYTE td)
{
	BYTE d, spicmd[] = { PIC_SEND, 1, 0 };
	int n = 8;


	switch (PortType) {
	case TY_COMM :
		d = _inp(COM_MCR);
		do {
			if (td & 0x80) {							/* Set MOSI(TD) */
				if (!sig_break) {
					_outp(COM_LCR, C_MOSI);
					sig_break = TRUE;
				}
			} else {
				if (sig_break) {
					_outp(COM_LCR, 0);
					sig_break = FALSE;
				}
			}
			_outp(COM_MCR, d | C_SCK);					/* SCK(RS) = H */
			_outp(COM_MCR, d);							/* SCK(RS) = L */
			td <<= 1;
		} while (--n);
		break;

	case TY_VCOM :
		do {
			if (td & 0x80) {					/* MOSI(TD) = data */
				if (!sig_break) {
					EscapeCommFunction(hComm, SETBREAK);
					sig_break = TRUE;
				}
			} else {
				if (sig_break) {
					EscapeCommFunction(hComm, CLRBREAK);
					sig_break = FALSE;
				}
			}
			EscapeCommFunction(hComm, SETRTS);	/* SCK(RS) = H */
			EscapeCommFunction(hComm, CLRRTS);	/* SCK(RS) = L */
			td <<= 1;
		} while (--n);
		break;

	case TY_BRIDGE :
		spicmd[2] = td;
		send_bridge(spicmd, 3);					/* Send a byte */
		break;

	case TY_AVRSP :
		d = _inp(LPT_DAT);
		do {
			if (td & 0x80) d |= B_MOSI;
			else 		   d &= ~B_MOSI;
			_outp(LPT_DAT, d);					/* MOSI(D1) = data, SCK(D0) = L */
			_outp(LPT_DAT, d | B_SCK);			/* SCK(D0) = H */
			td <<= 1;
		} while (--n);
		_outp(LPT_DAT, d);						/* SCK(D0) = L */
		break;

	case TY_STK200 :
		d = _inp(LPT_DAT);
		do {
			if (td & 0x80) d |= BS_MOSI;
			else 		   d &= ~BS_MOSI;
			_outp(LPT_DAT, d);					/* MOSI(D5) = data, SCK(D4) = L */
			_outp(LPT_DAT, d | BS_SCK);			/* SCK(D4) = H */
			td <<= 1;
		} while (--n);
		_outp(LPT_DAT, d);						/* SCK(D4) = L */
		break;

	case TY_XILINX :
		d = _inp(LPT_DAT);
		do {
			if (td & 0x80) d |= BX_MOSI;
			else 		   d &= ~BX_MOSI;
			_outp(LPT_DAT, d);							/* MOSI(D0) = data, SCK(D1) = L */
			_outp(LPT_DAT, d | BX_SCK);					/* SCK(D1) = H */
			td <<= 1;
		} while (--n);
		_outp(LPT_DAT, d);								/* SCK(D1) = L */
		break;

	case TY_LATTICE :
		d = _inp(LPT_DAT);
		do {
			if (td & 0x80) d |= BL_MOSI;
			else 		   d &= ~BL_MOSI;
			_outp(LPT_DAT, d);					/* MOSI(D0) = data, SCK(D1) = L */
			_outp(LPT_DAT, d | BL_SCK);			/* SCK(D1) = H */
			td <<= 1;
		} while (--n);
		_outp(LPT_DAT, d);						/* SCK(D1) = L */
		break;

	case TY_ALTERA :
		d = _inp(LPT_DAT);
		do {
			if (td & 0x80) d |= BA_MOSI;
			else 		   d &= ~BA_MOSI;
			_outp(LPT_DAT, d);					/* MOSI(D6) = data, SCK(D0) = L */
			_outp(LPT_DAT, d | BA_SCK);			/* SCK(D0) = H */
			td <<= 1;
		} while (--n);
		_outp(LPT_DAT, d);						/* SCK(D0) = L */
		break;
	}

}


/* Receive a byte from device */

BYTE read_byte (int sync)
{
	BYTE rd = 0;
	BYTE spicmd[] = { PIC_RECV, 1 };
	int n = 8;


	switch (PortType) {
	case TY_COMM :
		if (sig_break) {					/* MOSI(TD) = L */
			_outp(COM_LCR, 0);
			sig_break = FALSE;
		}
		do {
			rd <<= 1;						/* Read MISO(DR) */
			_outp(COM_MCR, C_SCK|C_RES);	/* SCK = H */
			if (_inp(COM_MSR) & C_MISO) rd++;	/* Sample MISO(DR) */
			_outp(COM_MCR,       C_RES);	/* SCK = L */
		} while (--n);
		if (sync == RM_ASYNC)
			fifo_put(rd);
		break;

	case TY_VCOM :
		if (sig_break) {					/* MOSI(TD) = L */
			EscapeCommFunction(hComm, CLRBREAK);
			sig_break = TRUE;
		}
		do {
			rd <<= 1;						/* Read MISO(DR) */
			EscapeCommFunction(hComm, SETRTS);	/* SCK(RS) = H */
			GetCommModemStatus(hComm, &ModemStat);
			if (ModemStat & MS_DSR_ON) rd++;	/* Sample MISO(DR) */
			EscapeCommFunction(hComm, CLRRTS);	/* SCK(RS) = L */
		} while (--n);
		if (sync == RM_ASYNC)
			fifo_put(rd);
		break;

	case TY_BRIDGE :
		send_bridge(spicmd, 2);				/* Send PIC_RECV command */
		if (sync == RM_SYNC) {
			if (!read_bridge(&rd, 1))		/* Get a read data from pipeline */
				rd = 0xFF;
		}
		break;

	case TY_AVRSP :
		_outp(LPT_DAT, B_ENA|B_RES);		/* MOSI(D0) = L */
		do {
			rd <<= 1;						/* Read MISO(BUSY) */
			_outp(LPT_DAT, B_ENA|B_SCK|B_RES);	/* SCK(D1) = H */
			if ((_inp(LPT_STA) & S_BUSY) == 0) rd++;	/* Sample MISO */
			_outp(LPT_DAT, B_ENA|B_RES);		/* SCK(D1) = L */
		} while (--n);
		if (sync == RM_ASYNC)
			fifo_put(rd);
		break;

	case TY_STK200 :
		_outp(LPT_DAT, BS_RES);				/* MOSI(D5) = L */
		do {
			rd <<= 1;						/* Read MISO(ACK) */
			_outp(LPT_DAT, BS_RES|BS_SCK);	/* SCK(D4) = H */
			if (_inp(LPT_STA) & S_ACK) rd++;	/* Sample MISO */
			_outp(LPT_DAT, BS_RES);			/* SCK(D4) = L */
		} while (--n);
		if (sync == RM_ASYNC)
			fifo_put(rd);
		break;

	case TY_XILINX :
		_outp(LPT_DAT, BX_DIS2|BX_RES);		/* MOSI(D0) = L */
		do {
			rd <<= 1;						/* Read MISO(SEL) */
			_outp(LPT_DAT, BX_DIS2|BX_RES|BX_SCK);	/* SCK(D1) = H */
			if (_inp(LPT_STA) & S_SEL) rd++;	/* Sample MISO */
			_outp(LPT_DAT, BX_DIS2|BX_RES);	/* SCK(D1) = L */
		} while (--n);
		if (sync == RM_ASYNC)
			fifo_put(rd);
		break;

	case TY_LATTICE :
		_outp(LPT_DAT, BL_RES);				/* MOSI(D0) = L */
		do {
			rd <<= 1;						/* Read MISO(ACK) */
			_outp(LPT_DAT, BL_RES|BL_SCK);	/* SCK(D1) = H */
			if (_inp(LPT_STA) & S_ACK) rd++;	/* Sample MISO */
			_outp(LPT_DAT, BL_RES);			/* SCK(D1) = L */
		} while (--n);
		if (sync == RM_ASYNC)
			fifo_put(rd);
		break;

	case TY_ALTERA :
		_outp(LPT_DAT, BA_RES);				/* MOSI(D6) = L */
		do {
			rd <<= 1;						/* Read MISO(BUSY) */
			_outp(LPT_DAT, BA_RES|BA_SCK);	/* SCK(D0) = H */
			if ((_inp(LPT_STA) & S_BUSY) == 0) rd++;	/* Sample MISO */
			_outp(LPT_DAT, BA_RES);			/* SCK(D0) = L */
		} while (--n);
		if (sync == RM_ASYNC)
			fifo_put(rd);
		break;
	}

	return rd;
}



/* Send a 24bit instruction word to the device */

void send_inst (DWORD inst, int nops)
{
	DWORD val = 0, n;
	BYTE buff[4];


	/* Convert bit order */
	for (n = 24; n; n--) {
		val <<= 1;
		if (inst & 1) val++;
		inst >>= 1;
	}
	nops &= 7;

	if (PortType == TY_BRIDGE) {
		buff[0] = PIC_SEND24 | (BYTE)nops;
		buff[1] = (BYTE)(val >> 16);
		buff[2] = (BYTE)(val >> 8);
		buff[3] = (BYTE)(val >> 0);
		send_bridge(buff, 4);
	} else {
		/* Send SIX command (0b0000) */
		set_mosi(0);
		apply_sck();
		apply_sck();
		apply_sck();
		apply_sck();
		/* Send a 24bit instruction word */
		send_byte((BYTE)(val >> 16));
		send_byte((BYTE)(val >> 8));
		send_byte((BYTE)(val >> 0));
		while (nops--)
			send_inst(0, 0);
	}
}




/* Read VLSI register from the device */

WORD read_vlsi (
	int sync		/* SYNC or ASYNC receive mode */
)
{
	WORD rd;
	BYTE buff[2];


	if (PortType == TY_BRIDGE) {
		buff[0] = PIC_READ24;
		send_bridge(buff, 1);
		if (sync == RM_SYNC) {
			read_bridge(buff, 2);
			rd = (WORD)buff[0] * 256 + buff[1];
		} else {
			rd = 0;
		}
	} else {
		/* Send REGOUT command (0b0001) */
		set_mosi(1);
		apply_sck();
		set_mosi(0);
		apply_sck();
		apply_sck();
		apply_sck();

		/* Purge leading 8 bits */
		send_byte(0);

		/* Read following 16 bits */
		rd = (WORD)read_byte(sync) * 256 + read_byte(sync);

		send_inst(0, 0);
	}

	return rd;	/* The bit order of read data is opposited */
}




void spi_delayedget (
	void *ptr,		/* Pointer to the data receive buffer */
	DWORD cnt		/* Number of bytes to receive */
)
{
	BYTE *p = ptr;

	
	if (PortType == TY_BRIDGE) {
		if (!read_bridge(p, cnt))		/* Get data from pipeline */
			memset(p, 0xFF, cnt);
	}
	else {
		while (cnt--)
			*p++ = fifo_get();			/* Get data form receiving fifo */
	}
}




/* Close control port */

void close_ifport ()
{
	BYTE spicmd[] = {PIC_EXIT, FLAG, SPI_DISABLE};


	set_reset(0);

	switch (PortType) {
	case TY_COMM :
		_outp(COM_MCR, 0);
		_outp(COM_LCR, 3);
		break;

	case TY_VCOM :
		break;

	case TY_BRIDGE :
		send_bridge(spicmd, 3);
		read_bridge(spicmd, 1);
		break;

	case TY_AVRSP :
		_outp(LPT_DAT, 0);
		break;

	case TY_STK200 :
		_outp(LPT_DAT, BS_DIS);
		break;

	case TY_XILINX :
		_outp(LPT_DAT, BX_DIS1|BX_DIS2);
		break;

	case TY_LATTICE :
		_outp(LPT_DAT, BL_DIS);
		break;

	case TY_ALTERA :
		_outp(LPT_CTL, 0);
		break;
	}

	if (hComm != INVALID_HANDLE_VALUE)
		CloseHandle(hComm);

	PortType = 0;
}




/* Initialize control port and return port status */

int open_ifport (PORTPROP *pc)
{
	OSVERSIONINFO vinfo = { sizeof(OSVERSIONINFO) };
	LARGE_INTEGER val1;
	BYTE cmdspi[] = { FLAG-1, FLAG, SPI_ENABLE, FLAG, SPI_PICMODE };
	static const WORD PortsCom[] = { COM1ADR, COM2ADR, COM3ADR, COM4ADR };
	static const WORD PortsLpt[] = { LPT1ADR, LPT2ADR, LPT3ADR };
	char sComm[16];
	DCB dcb = { sizeof(DCB),
				9600, TRUE, FALSE, TRUE, FALSE,
				DTR_CONTROL_DISABLE, FALSE,
				TRUE, FALSE, FALSE, FALSE, FALSE,
				RTS_CONTROL_DISABLE, FALSE, 0, 0,
				10, 10,
				8, NOPARITY, ONESTOPBIT, '\x11', '\x13', '\xFF', '\xFF', 0 };
	COMMTIMEOUTS commtimeouts = { 0, 1, 100, 1, 300};


	/* Check if high resolution timer is supported */
	QueryPerformanceFrequency(&val1);
	if (val1.QuadPart == 0) {
		pc->Info1 = "Incompatible envilonment.\n";
		return 1;
	}

	dcb.BaudRate = pc->Baud;	/* Bit rate for SPI bridge */

	/* Open direct I/O driver if needed */
	if (GetVersionEx(&vinfo) == FALSE) {
		pc->Info1 = "Incompatible envilonment.\n";
		return 1;
	}
	if ((vinfo.dwPlatformId == VER_PLATFORM_WIN32_NT)
	    && ((pc->PortClass == TY_COMM)||(pc->PortClass == TY_LPT))) {
		if (init_driver()) {
			pc->Info1 = "I/O driver, giveio.sys, is not available due to any reason.\nTo install giveio, type \"move giveio.sys %%windir%%\\system32\" and retry any function.\n";
			return 1;
		}
	}

	/* Use COM port in direct I/O */
	if (pc->PortClass == TY_COMM) {
		if ((pc->PortNum < 1)||(pc->PortNum > 4)) {
			pc->Info1 = "Invalid Port#.\n";
			return 1;
		}
		PortBase = PortsCom[pc->PortNum - 1];
		sprintf(str_info, "No COM%u(0x%X) port.\n", pc->PortNum, PortBase);
		pc->Info1 = str_info;
		if (check_comport()) {
			if (vinfo.dwPlatformId != VER_PLATFORM_WIN32_NT) return 1;
			sprintf(sComm, "\\\\.\\COM%u", pc->PortNum);
			hComm = CreateFile(sComm, GENERIC_READ, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
			if (hComm == INVALID_HANDLE_VALUE) return 1;
			if (check_comport()) return 1;
		}

		_outp(COM_IMR, 0x00);		/* Mask interrupts */
		pc->Info1 = NULL;
		PortType = TY_COMM;
		if (!check_adapter()) {
			pc->Info1 = "Not attached to the target.\n";
			return 1;
		}
		return 0;
	}

	/* Use COM port via API */
	if (pc->PortClass == TY_VCOM) {
		sprintf(sComm, "\\\\.\\COM%u", pc->PortNum);
		hComm = CreateFile(sComm, GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
		if (hComm == INVALID_HANDLE_VALUE) {
			sprintf(str_info, "%s could not be opened.\n", sComm);
			pc->Info1 = str_info;
			return 1;
		}
		SetCommState(hComm, &dcb);
		EscapeCommFunction(hComm, CLRRTS);
		EscapeCommFunction(hComm, CLRDTR);
		PortType = TY_VCOM;
		if (!check_adapter()) {
			pc->Info1 = "Not attached to the target.\n";
			return 1;
		}
		return 0;
	}

	/* Use SPI bridge attached on COM port */
	if (pc->PortClass == TY_BRIDGE) {
		sprintf(sComm, "\\\\.\\COM%u", pc->PortNum);
		hComm = CreateFile(sComm, GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
		if (hComm == INVALID_HANDLE_VALUE) {
			sprintf(str_info, "%s could not be opened.\n", sComm);
			pc->Info1 = str_info;
			return 1;
		}
		dcb.fOutxCtsFlow = TRUE;
		dcb.fRtsControl = RTS_CONTROL_HANDSHAKE;
		SetCommState(hComm, &dcb);
		SetCommTimeouts(hComm, &commtimeouts);
		EscapeCommFunction(hComm, SETDTR);
		EscapeCommFunction(hComm, CLRDTR);
		delay_ms(10);
		while (read_bridge(cmdspi, sizeof(cmdspi)));
		send_bridge(cmdspi, 5);		/* Send bridge initialization commands */
		read_bridge(cmdspi, 1);		/* Check if the SPI command is accepted */
		if (cmdspi[0] != SPI_ENABLE) {
			sprintf(str_info, "No SPI bridge on the %s.\n", sComm);
			pc->Info1 = str_info;
			return 1;
		}
		read_bridge(cmdspi, 1);		/* Check if the bridge supports PIC extension */
		if (cmdspi[0] != SPI_PICMODE) {
			sprintf(str_info, "SPI bridge is not supporting PIC extension.\n");
			pc->Info1 = str_info;
			return 1;
		}
		PortType = TY_BRIDGE;
		if (!check_adapter()) {
			pc->Info1 = "Not attached to the target.\n";
			return 1;
		}

		return 0;
	}

	/* Use LPT port in direct I/O */
	if (pc->PortClass == TY_LPT) {
		if ((pc->PortNum < 1)||(pc->PortNum > 3)) {
			pc->Info1 = "Invalid Port#.\n";
			return 1;
		}
		PortBase = PortsLpt[pc->PortNum - 1];
		if (check_lptport()) {
			sprintf(str_info, "No LPT%u(0x%X) port.\n", pc->PortNum, PortBase);
			pc->Info1 = str_info;
			return 1;
		}

		_outp(LPT_DAT, 0x20);	/* Check if the adapter is ByteBlasterMV (D5-ACK) */
		if (_inp(LPT_STA) & S_ACK) {
			_outp(LPT_DAT, 0);
			if ((_inp(LPT_STA) & S_ACK) == 0) {
				_outp(LPT_CTL, BA_ENA);
				pc->Info1 = "Altera ByteBlasterMV was found.\n";
				PortType = TY_ALTERA;
				if (!check_adapter()) {
					pc->Info2 = "Not attached to the target.\n";
					return 1;
				}
				if (_inp(LPT_STA) & S_ERR) return 0;	/* Check target power */
				pc->Info2 = "But target power is OFF.\n";
				return 1;
			}
		}
		_outp(LPT_DAT, 0x80);	/* Check if the adapter is AVRSP (D7-PE) */
		if (_inp(LPT_STA) & S_PE) {
			_outp(LPT_DAT, 0);
			if ((_inp(LPT_STA) & S_PE) == 0) {
				_outp(LPT_DAT, B_ENA);
				pc->Info1 = "AVRSP adapter was found.\n";
				PortType = TY_AVRSP;
				if (!check_adapter()) {
					pc->Info2 = "Not attached to the target.\n";
					return 1;
				}
				if (_inp(LPT_STA) & S_ERR) return 0;	/* Check target power */
				pc->Info2 = "But target power is OFF.\n";
				return 1;
			}
		}
		_outp(LPT_DAT, 0x40);	/* Check if the adapter is Xilinx JTAG (D6-BUSY-PE) */
		if ((_inp(LPT_STA) & (S_PE | S_BUSY)) == S_PE) {
			_outp(LPT_DAT, 0);
			if ((_inp(LPT_STA) & (S_PE | S_BUSY)) == S_BUSY) {
				pc->Info1 = "Xilinx JTAG adapter was found.\n";
				PortType = TY_XILINX;
				if (!check_adapter()) {
					pc->Info2 = "Not attached to the target.\n";
					return 1;
				}
				if (_inp(LPT_STA) & S_ERR) return 0;	/* Check target power */
				pc->Info2 = "But target power is OFF.\n";
				return 1;
			}
		}
		_outp(LPT_DAT, 0x40);	/* Check if the adapter is Lattice ISP (D6-PE) */
		if (_inp(LPT_STA) & S_PE) {
			_outp(LPT_DAT, 0);
			if ((_inp(LPT_STA) & S_PE) == 0) {
				pc->Info1 = "Lattice ISP adapter was found.\n";
				PortType = TY_LATTICE;
				if (!check_adapter()) {
					pc->Info2 = "Not attached to the target.\n";
					return 1;
				}
				if (_inp(LPT_STA) & S_ERR) return 0;	/* Check target power */
				pc->Info2 = "But target power is OFF.\n";
				return 1;
			}
		}
		_outp(LPT_DAT, 0x01);	/* Check if the adapter is STK200 dongle (D0-PE) */
		if (_inp(LPT_STA) & S_PE) {
			_outp(LPT_DAT, 0);
			if ((_inp(LPT_STA) & S_PE) == 0) {
				pc->Info1 = "STK200 ISP dongle was found.\n";
				PortType = TY_STK200;
				if (!check_adapter()) {
					pc->Info2 = "Not attached to the target.\n";
					return 1;
				}
				if (_inp(LPT_STA) & S_ERR) return 0;	/* Check target power */
				pc->Info2 = "But target power is OFF.\n";
				return 1;
			}
		}
		sprintf(str_info, "No ISP adapter on the LPT%u.\n", pc->PortNum);
		pc->Info1 = str_info;
		return 1;
	}

	pc->Info1 = "Invalid port class.\n";
	return 1;
}
