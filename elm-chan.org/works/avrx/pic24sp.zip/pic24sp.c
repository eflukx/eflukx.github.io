/*---------------------------------------------------------------------------*/
/* PIC24SP - ICSP Programmer for PIC24F/24H/33F microcontrollers             */
/*                                                                           */
/* R0.02c (C)ChaN, 2009                                                      */
/*---------------------------------------------------------------------------*/
/* R0.01  Nov 11, '07  First stable                                          */
/* R0.02  Dec  8, '07  Improved writing speed on SPI bridge                  */
/* R0.02b Dec 29, '07  Fixed to support auto-baud on SPI bridge              */
/* R0.02c Jan  8, '09  Fixed unintentional reset on AVRSP-LPT adapter    */
/*---------------------------------------------------------------------------*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include "pic24sp.h"


/*-----------------------------------------------------------------------
  Device properties
-----------------------------------------------------------------------*/

const DEVPROP DevLst[] =	/* Device property table */
{
	/* Name,           CLASS,   DEVID,   Flash,    Row, EEP, Row,  Exe */
	{ "24FJ16GA002",   DEV24F,  0x0444,  0x05800,  256,  0,   0,  0x1000 },
	{ "24FJ32GA002",   DEV24F,  0x0445,  0x0B000,  256,  0,   0,  0x1000 },
	{ "24FJ48GA002",   DEV24F,  0x0446,  0x10800,  256,  0,   0,  0x1000 },
	{ "24FJ64GA002",   DEV24F,  0x0447,  0x15800,  256,  0,   0,  0x1000 },
	{ "24FJ16GA004",   DEV24F,  0x044C,  0x05800,  256,  0,   0,  0x1000 },
	{ "24FJ32GA004",   DEV24F,  0x044D,  0x0B000,  256,  0,   0,  0x1000 },
	{ "24FJ48GA004",   DEV24F,  0x044E,  0x10800,  256,  0,   0,  0x1000 },
	{ "24FJ64GA004",   DEV24F,  0x044F,  0x15800,  256,  0,   0,  0x1000 },
	{ "24FJ64GA006",   DEV24F,  0x0405,  0x15800,  256,  0,   0,  0x1000 },
	{ "24FJ96GA006",   DEV24F,  0x0406,  0x20000,  256,  0,   0,  0x1000 },
	{ "24FJ128GA006",  DEV24F,  0x0407,  0x2B000,  256,  0,   0,  0x1000 },
	{ "24FJ64GA008",   DEV24F,  0x0408,  0x15800,  256,  0,   0,  0x1000 },
	{ "24FJ96GA008",   DEV24F,  0x0409,  0x20000,  256,  0,   0,  0x1000 },
	{ "24FJ128GA008",  DEV24F,  0x040A,  0x2B000,  256,  0,   0,  0x1000 },
	{ "24FJ64GA010",   DEV24F,  0x040B,  0x15800,  256,  0,   0,  0x1000 },
	{ "24FJ96GA010",   DEV24F,  0x040C,  0x20000,  256,  0,   0,  0x1000 },
	{ "24FJ128GA010",  DEV24F,  0x040D,  0x2B000,  256,  0,   0,  0x1000 },

	{ "24HJ12GP201",   DEV33F,  0x080A,  0x04000,  256,  0,   0,  0x2000 },
	{ "24HJ12GP202",   DEV33F,  0x080B,  0x04000,  256,  0,   0,  0x2000 },
	{ "24HJ16GP304",   DEV33F,  0x0F17,  0x05800,  256,  0,   0,  0x2000 },
	{ "24HJ32GP202",   DEV33F,  0x0F1D,  0x0B000,  256,  0,   0,  0x2000 },
	{ "24HJ32GP204",   DEV33F,  0x0F1F,  0x0B000,  256,  0,   0,  0x2000 },
	{ "24HJ64GP206",   DEV33F,  0x0041,  0x15800,  256,  0,   0,  0x2000 },
	{ "24HJ64GP210",   DEV33F,  0x0047,  0x15800,  256,  0,   0,  0x2000 },
	{ "24HJ64GP506",   DEV33F,  0x0049,  0x15800,  256,  0,   0,  0x2000 },
	{ "24HJ64GP510",   DEV33F,  0x004B,  0x15800,  256,  0,   0,  0x2000 },

	{ "33FJ12GP201",   DEV33F,  0x0802,  0x04000,  256,  0,   0,  0x2000 },
	{ "33FJ12GP202",   DEV33F,  0x0803,  0x04000,  256,  0,   0,  0x2000 },
	{ "33FJ12MC201",   DEV33F,  0x0800,  0x04000,  256,  0,   0,  0x2000 },
	{ "33FJ12MC202",   DEV33F,  0x0801,  0x04000,  256,  0,   0,  0x2000 },
	{ "33FJ16GP304",   DEV33F,  0x0FD7,  0x05800,  256,  0,   0,  0x2000 },
	{ "33FJ16MC304",   DEV33F,  0x0FD3,  0x05800,  256,  0,   0,  0x2000 },
	{ "33FJ32GP202",   DEV33F,  0x0F0D,  0x0B000,  256,  0,   0,  0x2000 },
	{ "33FJ32GP204",   DEV33F,  0x0F0F,  0x0B000,  256,  0,   0,  0x2000 },
	{ "33FJ32MC202",   DEV33F,  0x0F09,  0x0B000,  256,  0,   0,  0x2000 },
	{ "33FJ32MC204",   DEV33F,  0x0F0B,  0x0B000,  256,  0,   0,  0x2000 },
	{ "33FJ64GP206",   DEV33F,  0x00C1,  0x15800,  256,  0,   0,  0x2000 },
	{ "33FJ64GP306",   DEV33F,  0x00CD,  0x15800,  256,  0,   0,  0x2000 },
	{ "33FJ64GP310",   DEV33F,  0x00CF,  0x15800,  256,  0,   0,  0x2000 },
	{ "33FJ64GP706",   DEV33F,  0x00D5,  0x15800,  256,  0,   0,  0x2000 },
	{ "33FJ64GP708",   DEV33F,  0x00D6,  0x15800,  256,  0,   0,  0x2000 },
	{ "33FJ64GP710",   DEV33F,  0x00D7,  0x15800,  256,  0,   0,  0x2000 },
	{ "33FJ64MC506",   DEV33F,  0x0089,  0x15800,  256,  0,   0,  0x2000 },
	{ "33FJ64MC508",   DEV33F,  0x008A,  0x15800,  256,  0,   0,  0x2000 },
	{ "33FJ64MC510",   DEV33F,  0x008B,  0x15800,  256,  0,   0,  0x2000 },
	{ "33FJ64MC706",   DEV33F,  0x0091,  0x15800,  256,  0,   0,  0x2000 },
	{ "33FJ64MC710",   DEV33F,  0x0097,  0x15800,  256,  0,   0,  0x2000 },
	{ "33FJ128GP206",  DEV33F,  0x00D9,  0x2B000,  256,  0,   0,  0x2000 },
	{ "33FJ128GP306",  DEV33F,  0x00E5,  0x2B000,  256,  0,   0,  0x2000 },
	{ "33FJ128GP310",  DEV33F,  0x00E7,  0x2B000,  256,  0,   0,  0x2000 },
	{ "33FJ128GP706",  DEV33F,  0x00ED,  0x2B000,  256,  0,   0,  0x2000 },

	{ NULL,            DEVNUL }		/* Unknown */
};

const DEVPROP *Device = NULL;		/* Pointer to the current device property */


/* Usage */
const char MesUsage[] = {
		"PIC24SP - Serial programming tool for PIC24F/PIC24H/dsPIC33F, R0.02c, (C)ChaN,2009  http://elm-chan.org/\n\n"
		"Write code/config      : <hex file> [<hex file>] ...\n"
		"Verify code/config     : -V <hex file> [<hex file>] ...\n"
		"Query device           : -R\n"
		"Read code/config       : -RP\n"
		"Perform bulk erase     : -E\n"
		"Show supported devices : -U\n"
		"Control port [-pc1]    : -P{C|L|V|B}<n>[:<baud>]\n"
		"Supported Adapter:\n"
		" AVRSP adapter (COM/LPT(buffered))\n"
		" SPI Bridge (COM)\n"
		" STK200 ISP dongle (LPT(buffered))\n"
		" Xilinx JTAG (LPT), Lattice isp (LPT)\n"
		" Altera ByteBlasterMV (LPT)\n"
		};



/*-----------------------------------------------------------------------
  Global variables (initialized by load_commands())
-----------------------------------------------------------------------*/

BYTE CodeBuff[MAX_FLASH];	/* Program code R/W buffer */
BYTE DataBuff[MAX_EEPROM];	/* Data EEPROM R/W buffer (not used) */
BYTE ExeBuff[8192];			/* Proramming executive buffer (not used) */
BYTE CfgBuff[64];			/* Configuration data R/W buffer */
WORD DevId[2];				/* Read DEVID and DEVREV */

DWORD CodeSize;				/* Loaded program code size */
DWORD DataSize;				/* Loaded EEPROM data size (not used) */
DWORD ExeSize;				/* Loaded programming executive size (not used) */
DWORD CfgSize;				/* Loaded configuration size */


/*---------- Command Parameters ------------*/

int Command;				/* -r -q -z -u Read/Query/Test/DevList command */
int Verify;					/* -v Verify only */
int Pause;					/* -w Pause before exiting program */
char ForcedName[20];		/* -t Forced device type (compared to Device->Name)*/



/*---------- Hardware Control ------------*/

PORTPROP CtrlPort = {	TY_COMM, 1,	115200, /* -p .PortClass .PortNum .Baud */
						NULL, NULL };




/*-----------------------------------------------------------------------
  Messages
-----------------------------------------------------------------------*/



/*-----------------------------------------------------------------------
  Hex format manupilations
-----------------------------------------------------------------------*/


/* Pick a hexdecimal value from hex record */

static
DWORD get_valh (
	char **lp,	/* pointer to line read pointer */
	int count, 	/* number of digits to get (2,4,6,8) */
	BYTE *sum	/* byte check sum */
) {
	DWORD val = 0;
	BYTE n;


	do {
		n = *(*lp)++;
		if (n >= 'a') n -= 0x20;
		if ((n -= '0') >= 10) {
			if ((n -= 7) < 10 || n > 15) return 0xFFFFFFFF;
		}
		val = (val << 4) + n;
		if (count & 1) *sum += (BYTE)val;
	} while(--count);
	return val;
}


static
void store_data (DWORD addr, BYTE dat)
{
	/* Configuration data area */
	if (addr >= 0xF80000 * 2) {
		addr -= 0xF80000 * 2;
		if (addr < sizeof(CfgBuff)) {
			CfgBuff[addr++] = dat;
			if (addr > CfgSize) CfgSize = addr;
		}
		return;
	}

	/* Programming executive area */
	if (addr >= 0x800000 * 2) {
		addr -= 0x800000 * 2;
		if (addr < sizeof(ExeBuff)) {
			ExeBuff[addr++] = dat;
			if (addr > ExeSize) ExeSize = addr;
		}
		return;
	}

	/* EEPROM data area */
	if (addr >= 0x800000 * 2 - MAX_EEPROM) {
		addr -= 0x800000 * 2 - MAX_EEPROM;
		if (addr < sizeof(DataBuff)) {
			DataBuff[addr++] = dat;
			if (addr > DataSize) DataSize = addr;
		}
		return;
	}

	/* Program code area */
	if (addr < sizeof(CodeBuff)) {
		CodeBuff[addr++] = dat;
		if (addr > CodeSize) CodeSize = addr;
	}
}



/* Load Intel/Motorola hex file into data buffer */ 

long input_hexfile (
	FILE *fp			/* input stream */
) {
	char line[600];			/* line input buffer */
	char *lp;				/* line read pointer */
	long lnum = 0;			/* input line number */
	WORD seg = 0, hadr = 0;	/* address expantion values for intel hex */
	DWORD addr, count, n;
	BYTE sum;


	while(fgets(line, sizeof(line), fp) != NULL) {
		lnum++;
		lp = &line[1]; sum = 0;

		if(line[0] == ':') {	/* Intel Hex format */
			if((count = get_valh(&lp, 2, &sum)) > 0xFF) return lnum;	/* byte count */
			if((addr = get_valh(&lp, 4, &sum)) > 0xFFFF) return lnum;	/* offset */

			switch (get_valh(&lp, 2, &sum)) {	/* block type? */
				case 0x00 :	/* data */
					addr += (seg << 4) + (hadr << 16);
					while(count--) {
						n = get_valh(&lp, 2, &sum);		/* pick a byte */
						if(n > 0xFF) return lnum;
						store_data(addr++, (BYTE)n);
					}
					break;

				case 0x01 :	/* end */
					if(count != 0) return lnum;
					break;

				case 0x02 :	/* segment base [19:4] */
					if(count != 2) return lnum;
					seg = (WORD)get_valh(&lp, 4, &sum);
					if(seg == 0xFFFF) return lnum;
					break;

				case 0x03 :	/* program start address (segment:offset) */
					if(count != 4) return lnum;
					get_valh(&lp, 8, &sum);
					break;

				case 0x04 :	/* high address base [31:16] */
					if(count != 2) return lnum;
					hadr = (WORD)get_valh(&lp, 4, &sum);
					if(hadr == 0xFFFF) return lnum;
					break;

				case 0x05 :	/* program start address (linear) */
					if(count != 4) return lnum;
					get_valh(&lp, 8, &sum);
					break;

				default:	/* invalid block */
					return lnum;
			} /* switch */
			if(get_valh(&lp, 2, &sum) > 0xFF) return lnum;	/* get check sum */
			if(sum) return lnum;							/* test check sum */
			continue;
		} /* if */

		if(line[0] == 'S') {	/* Motorola S format */
			if((*lp >= '1')&&(*lp <= '3')) {

				switch (*lp++) {	/* record type? (S1/S2/S3) */
					case '1' :
						count = get_valh(&lp, 2, &sum) - 3;
						if(count > 0xFF) return lnum;
						addr = get_valh(&lp, 4, &sum);
						if(addr > 0xFFFF) return lnum;
						break;
					case '2' :
						count = get_valh(&lp, 2, &sum) - 4;
						if(count > 0xFF) return lnum;
						addr = get_valh(&lp, 6, &sum);
						if(addr > 0xFFFFFF) return lnum;
						break;
					default :
						count = get_valh(&lp, 2, &sum) - 5;
						if(count > 0xFF) return lnum;
						addr = get_valh(&lp, 8, &sum);
						if(addr == 0xFFFFFFFF) return lnum;
				}
				while(count--) {
					n = get_valh(&lp, 2, &sum);
					if(n > 0xFF) return lnum;
					store_data(addr++, (BYTE)n);
				}
				if(get_valh(&lp, 2, &sum) > 0xFF) return lnum;	/* get check sum */
				if(sum != 0xFF) return lnum;					/* test check sum */
			} /* switch */
			continue;
		} /* if */

		if(line[0] >= ' ') return lnum;
	} /* while */

	return feof(fp) ? 0 : -1;
}




/* Put an Intel Hex data block */

void put_hexline (
	FILE *fp,			/* Output stream */
	const BYTE *buffer,	/* Pointer to data buffer */
	WORD addr,			/* Block offset address */
	BYTE count,			/* Data byte count */
	BYTE type			/* Block type */
) {
	BYTE sum;

	/* Byte count, Offset address and Record type */
	fprintf(fp, ":%02X%04X%02X", count, addr, type);
	sum = count + (addr >> 8) + addr + type;

	/* Data bytes */
	while(count--) {
		fprintf(fp, "%02X", *buffer);
		sum += *buffer++;
	}

	/* Check sum */
	fprintf(fp, "%02X\n", (BYTE)-sum);
}




/* Output data in Intel Hex format */


void output_hexfile (
	FILE *fp,			/* Output stream */
	const BYTE *buffer,	/* Pointer to data buffer */
	DWORD addr,			/* Start address */
	DWORD bc,			/* Number of bytes to be output */
	BYTE blksize		/* Hex block size */
) {
	BYTE segbuff[2], d, n;


	if (!buffer) {
		put_hexline(fp, NULL, 0, 0, 1);	/* End block */
		return;
	}

	while (bc) {
		segbuff[0] = (BYTE)(addr >> 24); segbuff[1] = (BYTE)(addr >> 16);
		put_hexline(fp, segbuff, 0, 2, 4);
		do {
			if(bc >= blksize) {	/* full data block */
				for (d = 0xFF, n = 0; n < blksize; n++) d &= ((n & 3) == 3) ? 0xFF : buffer[n];
				if (d != 0xFF) put_hexline(fp, buffer, (WORD)addr, blksize, 0);
				addr += blksize;
				buffer += blksize;
				bc -= blksize;
			} else {				/* fractional data block */
				for (d = 0xFF, n = 0; n < bc; n++) d &= ((n & 3) == 3) ? 0xFF : buffer[n];
				if (d != 0xFF) put_hexline(fp, buffer, (WORD)addr, (BYTE)bc, 0);
				bc = 0;
			}
		} while (bc && (addr & 0xFFFF));
	}

}



/*-----------------------------------------------------------------------
  Command line analysis
-----------------------------------------------------------------------*/


static
int load_commands (int argc, char **argv)
{
	char *cp, *cmdlst[20], cmdbuff[256];
	int cmd;
	FILE *fp;
	DWORD ln;


	/* Clear data buffers */
	memset(CodeBuff, 0xFF, sizeof(CodeBuff));
	memset(DataBuff, 0xFF, sizeof(DataBuff));
	memset(ExeBuff, 0xFF, sizeof(ExeBuff));
	memset(CfgBuff, 0xFF, sizeof(CfgBuff));

	cmd = 0; cp = cmdbuff;

	/* Import ini file as command line parameters */
	fp = open_cfgfile(INIFILE);
	if (fp != NULL) {
		while (fgets(cp, cmdbuff + sizeof(cmdbuff) - cp, fp) != NULL) {
			if (cmd >= (sizeof(cmdlst) / sizeof(cmdlst[0]) - 1)) break;
			if (*cp <= ' ') break;
			cmdlst[cmd++] = cp; cp += strlen(cp) + 1;
		}
		fclose(fp);
	}

	/* Get command line parameters */
	while (--argc && (cmd < (sizeof(cmdlst) / sizeof(cmdlst[0]) - 1)))
		cmdlst[cmd++] = *++argv;
	cmdlst[cmd] = NULL;

	/* Analyze command line parameters... */
	for (cmd = 0; cmdlst[cmd] != NULL; cmd++) {
		cp = cmdlst[cmd];

		if (*cp == '-') {	/* Command switches... */
			cp++;
			switch (tolower(*cp++)) {
				case 'v' :	/* -v */
					Verify = 1;
					break;
				case 'z' :	/* -z */
					Command = 'z';
					break;
				case 'e' :	/* -e */
					Command = 'e';
					break;
				case 'u' :	/* -u */
					Command = 'u';
					break;
				case 'r' :	/* -r */
					if (tolower(*cp) == 'p') {
						Command = 'r';
						cp++;
					} else {
						Command = 'q';
					}
					break;
				case 'p' :	/* -p{c|l|v|b}<num> */
					switch (tolower(*cp++)) {
						case 'c' :
							CtrlPort.PortClass = TY_COMM;
							break;
						case 'l' :
							CtrlPort.PortClass = TY_LPT;
							break;
						case 'v' :
							CtrlPort.PortClass = TY_VCOM;
							break;
						case 'b' :
							CtrlPort.PortClass = TY_BRIDGE;
							break;
						default :
							return RC_SYNTAX;
					}
					CtrlPort.PortNum = (WORD)strtoul(cp, &cp, 10);
					if (*cp == ':')
						CtrlPort.Baud = strtoul(cp+1, &cp, 10);
					break;
				case 'w' :	/* -w<num> (pause before exit) */
					Pause = strtoul(cp, &cp, 2) + 1;
					break;
				case 't' :	/* -t<device> (force device type) */
					for (ln = 0; ln < sizeof(ForcedName); ln++, cp++) {
						if((ForcedName[ln] = *cp) == '\0') break;
					}
					break;

				default :	/* invalid command */
					return RC_SYNTAX;
			} /* switch */
			if (*cp >= ' ') return RC_SYNTAX;	/* option trails garbage */
		} /* if */

		else {	/* HEX Files (Write command) */
			if ((fp = fopen(cp, "rt")) == NULL) {
				fprintf(stderr, "%s : Unable to open.\n", cp);
				return RC_FILE;
			}
			ln = input_hexfile(fp);
			fclose(fp);
			if (ln) {
				if(ln < 0) {
					fprintf(stderr, "%s : File access failure.\n", cp);
				} else {
					fprintf(stderr, "%s (%ld) : Hex format error.\n", cp, ln);
				}
				return RC_FILE;
			}
		} /* else */

	} /* for */

	return 0;
}



/*-----------------------------------------------------------------------
  Device controls
-----------------------------------------------------------------------*/



static
WORD brev (WORD src, int n)		/* Bit reverse */
{
	WORD ret = 0;


	do {
		ret <<= 1;
		if (src & 1) ret++;
		src >>= 1;
	} while (--n);
	return ret;
}



static
void enter_icspmode (void)
{
	DWORD entry_code;
	int n;


	entry_code = ICSP;

	/* Enter ICSP mode */
	set_mosi(0); set_reset(0);	/* MCLR = L */
	set_reset(1);				/* MCLR = H */
	set_reset(0);				/* MCLR = L */
	send_byte((BYTE)(entry_code >> 24));	/* Send entry code */
	send_byte((BYTE)(entry_code >> 16));
	send_byte((BYTE)(entry_code >> 8));
	send_byte((BYTE)(entry_code >> 0));
	set_mosi(0);
	set_reset(1);				/* MCLR = H */
	delay_ms(30);				/* 30ms */

	/* Send first NOP instruction (a SIX cmd, 5 zeros and a NOP inst.) */
	for (n = 4 + 5 + 24; n; n--) apply_sck();
}



static
void icsp_initpc (int mode)
{
	switch (Device->Class) {
	case DEV24F:
		if (mode) send_inst(0, 0);		/* NOP */
		send_inst(0x040200, 1);			/* GOTO 0x200 + NOP*/
		break;
	case DEV33F:
		if (mode) send_inst(0x040200, 0);	/* GOTO 0x200 */
		send_inst(0x040200, 1);				/* GOTO 0x200 + NOP */
		break;
	}
}



static
void icsp_setwr (void)
{
	send_inst(0, 1);										/* 2NOP */
	send_inst(0xA8E761, Device->Class == DEV33F ? 4 : 2);	/* BSET NVMCON, #WR + 2(4)NOP */
}



static
void icsp_pollwr (void)
{
	WORD rd;


	do {
		icsp_initpc(0);
		send_inst(0x803B00, 0);			/* MOV NVMCON, W0 */
		send_inst(0x883C20, 1);			/* MOV W0, VLSI + NOP */
		rd = brev(read_vlsi(RM_SYNC), 16);/* Read VLSI reg */
	} while (rd & 0x8000);
}



static
int check_connection (void)
{
	WORD w;


	send_inst(0x040200, 1);			/* GOTO 0x200 + NOP */
	send_inst(0x255AA2, 0);			/* MOV #0x55AA, W2*/
	send_inst(0x883C22, 1);			/* MOV W2, VLSI + NOP */
	w = brev(read_vlsi(RM_SYNC), 16);/* Read VLSI reg */

	return (w == 0x55AA) ? 1 : 0;
}




/* Read DEVID and DEVREV register */

static
void get_devid (
	WORD *devid		/* Pointer to device id table to return */
)
{
	WORD w;


	send_inst(0, 0);			/* NOP */
	send_inst(0x040200, 1);		/* GOTO 0x200 + NOP */
	send_inst(0x200FF0, 0);		/* MOV #0x00FF, W0*/
	send_inst(0x880190, 0);		/* MOV W0, TBLPAG */
	send_inst(0x207841, 0);		/* MOV #VLSI, W1 */
	send_inst(0x200000, 1);		/* MOV #0x0000, W0 + NOP */
	send_inst(0xBA0890, 2);		/* TBLRDL [W0], [W1] + NOP */
	w = brev(read_vlsi(RM_SYNC), 16);	/* Read VLSI reg */
	devid[0] = w;
	send_inst(0x200020, 1);		/* MOV #0x0002, W0 + NOP */
	send_inst(0xBA0890, 2);		/* TBLRDL [W0], [W1] +  2NOP */
	w = brev(read_vlsi(RM_SYNC), 16);	/* Read VLSI reg */
	devid[1] = w;
}




/* Read program, data or any register */

static
int read_memory (
	DWORD adr,		/* Device address in hex file form [byte] */
	DWORD btr,		/* Byte to read (must be multiple of 4 (data) or 8 (program)) */
	BYTE *buff,		/* Data buffer to store read data */
	int mode24		/* Read mode 0:16bit data, 1:24bit program */
)
{
	DWORD si, di;
	WORD w;


	adr >>= 1;	/* Buffer address -> Device address */

	icsp_initpc(1);
	send_inst(0x200000 | (adr >> 12 & 0xFF0), 0);	/* MOV #adr(23:16), W0 */
	send_inst(0x880190, 0);						/* MOV W0, TBLPAG */
	send_inst(0x200006 | (adr << 4 & 0xFFFF0), 0);	/* MOV #adr(15:0), W6 */
	send_inst(0x207847, 1);						/* MOV #VLSI, W7 + NOP */
	if (mode24) {
		for (si = 0; si < btr; si += 8) {
			send_inst(0xBA0B96, 2);				/* TBLRDL [W6], [W7] + 2NOP */
			read_vlsi(RM_ASYNC);				/* Read out VLSI reg */
			send_inst(0xBADBB6, 2);				/* TBLRDH.B [W6++], [W7++] + 2NOP */
			send_inst(0xBAD3D6, 2);				/* TBLRDH.B [++W6], [W7--] + 2NOP */
			read_vlsi(RM_ASYNC);				/* Read out VLSI reg */
			send_inst(0xBA0BB6, 2);				/* TBLRDL [W6++], [W7] + 2NOP*/
			read_vlsi(RM_ASYNC);				/* Read out VLSI reg */
		}
		icsp_initpc(0);
		/* Convert packed form to unpacked form */
		spi_delayedget(buff, btr * 3 / 4);
		di = btr; si = btr * 3 / 4;
		do {
			buff[di-1] = 0;
			buff[di-2] = (BYTE)brev(buff[si-3], 8);
			buff[di-3] = (BYTE)brev(buff[si-1], 8);
			buff[di-4] = (BYTE)brev(buff[si-2], 8);
			buff[di-5] = 0;
			buff[di-6] = (BYTE)brev(buff[si-4], 8);
			buff[di-7] = (BYTE)brev(buff[si-5], 8);
			buff[di-8] = (BYTE)brev(buff[si-6], 8);
			di -= 8; si -= 6;
		} while (di);
	} else {
		for (si = 0; si < btr; si += 4) {
			send_inst(0xBA0BB6, 2);				/* TBLRDL [W6++], [W7] + 2NOP */
			w = brev(read_vlsi(RM_SYNC), 16);	/* Read out VLSI reg */
			icsp_initpc(0);
			*buff++ = (BYTE)w;
			*buff++ = (BYTE)(w >> 8);
			*buff++ = 0;
			*buff++ = 0;
		}
	}

	return 1;
}



/* Write a row of program memory or data EEPROM */

static
int write_memory (
	DWORD adr,			/* Device address in hex file form [byte] */
	DWORD btw,			/* Bytes to write (must be 32 (data) or size of row (program)) */
	const BYTE *buff,	/* Data to be written */
	int mode24
)
{
	DWORD si;


	adr >>= 1;	/* Buffer address -> Device address */

	icsp_initpc(1);
	send_inst(0x24001A, 0);							/* MOV #0x4001, W10 */
	send_inst(0x883B0A, 0);							/* MOV W10, NVMCON */
	send_inst(0x200000 | (adr >> 12 & 0xFF0), 0);	/* MOV #adr(23:16), W0 */
	send_inst(0x880190, 0);							/* MOV W0, TBLPAG */
	send_inst(0x200007 | (adr << 4 & 0xFFFF0), 0);	/* MOV #adr(15:0), W7 */
	for (si = 0; si < btw; si += 8) {				/* Load two inst. words * row/8 times */
		send_inst(0xEB0300, 0);						/* CLR W6 */
		send_inst(0x200000 | (DWORD)buff[si+0] << 4 | (DWORD)buff[si+1] << 12, 0);/* MOV #lsw0, W0 */
		send_inst(0x200001 | (DWORD)buff[si+2] << 4 | (DWORD)buff[si+6] << 12, 0);/* MOV #msb1:msb0, W1 */
		send_inst(0x200002 | (DWORD)buff[si+4] << 4 | (DWORD)buff[si+5] << 12, 0);/* MOV #lsw1, W2 */
		send_inst(0xBB0BB6, 2);						/* TBLWTL [W6++], [W7] + 2NOP */
		send_inst(0xBBDBB6, 2);						/* TBLWTH.B [W6++], [W7++] + 2NOP */
		send_inst(0xBBEBB6, 2);						/* TBLWTH.B [W6++], [++W7] + 2NOP */
		send_inst(0xBB1BB6, 2);						/* TBLWTL [W6++], [W7++] + 2NOP */
	}
	icsp_setwr();									/* BSET NVMCON, #WR */
	if (Device->Class != DEV24F) delay_ms(2);		/* 2ms */
	icsp_pollwr();
	icsp_initpc(0);

	return 1;
}



/* Read configuration words */
static
int read_cfgreg (
	BYTE *buff	/* Pointer to the read buffer */
)
{
	switch (Device->Class) {
	case DEV24F:
		read_memory(Device->FlashSize - 8, 8, buff, 0);
		break;
	case DEV33F:
		read_memory(0xF80000 * 2, 48, buff, 0);
		break;
	}
	return 1;
}




/* Write configuration words */
static
int write_cfgreg (
	const BYTE *buff	/* Pointer to the configuration values in the input buffer */
)
{
	DWORD adr, i;


	icsp_initpc(1);
	switch (Device->Class) {
	case DEV24F:
		adr = (Device->FlashSize - 8) / 2;				/* Location of cfg words */
		send_inst(0x24003A, 0);							/* MOV #0x4003, W10 */
		send_inst(0x883B0A, 0);							/* MOV W10, NVMCON */
		send_inst(0x200000 | (adr >> 12 & 0xFF0), 0);	/* MOV #adr(23:16), W0 */
		send_inst(0x880190, 0);							/* MOV W0, TBLPAG */
		send_inst(0x200007 | (adr << 4 & 0xFFFF0), 0);	/* MOV #adr(15:0), W7 */
		for (i = 0; i < 8; i += 4) {					/* ---- Repeat for two cfg words ---- */
			send_inst(0x200006 | (DWORD)buff[i+0] << 4 | (DWORD)buff[i+1] << 12, 1);/* MOV #cfgdata, W6 + NOP */
			send_inst(0xBB1B86, 0);					/* TBLWTL W6, [W7++] */
			icsp_setwr();							/* BSET NVMCON, #WR */
			icsp_pollwr();
		}
		break;
	case DEV33F:
		send_inst(0x24000A, 0);					/* MOV #0x4000, W10 */
		send_inst(0x883B0A, 0);					/* MOV W10, NVMCON */
		send_inst(0x200F80, 0);					/* MOV #0xF8, W0 */
		send_inst(0x880190, 0);					/* MOV W0, TBLPAG */
		send_inst(0x200007, 0);					/* MOV #0, W7 */
		for (i = 0; i < 48; i += 4) {			/* ---- Repeat for 12 cfg bytes ---- */
			send_inst(0x2FF000 | (DWORD)buff[i+0] << 4, 1);/* MOV #cfgdata, W0 + NOP*/
			send_inst(0xBB1B80, 0);				/* TBLWTL W0, [W7++] */
			icsp_setwr();						/* BSET NVMCON, #WR */
			delay_ms(25);						/* 25ms */
			icsp_pollwr();
		}
		break;
	}
	icsp_initpc(0);

	return 1;
}




/* Erase memory */
static
int erase_memory (
	int mode	/* 0:User area, 1:Executive, 2:Bulk */
)
{
	DWORD adr;


	icsp_initpc(1);
	switch (Device->Class) {
	case DEV24F:
		/* Save calibration word if needed */
		if (mode) {
			send_inst(0x200800, 0);			/* MOV #0x80, W0 */
			send_inst(0x880190, 0);			/* MOV W0, TBLPAG */
			send_inst(0x207FE1, 0);			/* MOV #0x7FE, W1 */
			send_inst(0x2000C2, 1);			/* MOV #12, W2 + NOP */
			send_inst(0xBA1931, 2);			/* TBLRDL [W1++], [W2++] + 2NOP */
		}
		/* Perform erase command */
		send_inst(0x2404F0, 0);				/* MOV #0x404F, W0 */
		send_inst(0x883B00, 0);				/* MOV W0, NVMCON */
		send_inst(0x200000, 0);				/* MOV #0, W0 */
		send_inst(mode ? 0x200801 : 0x200001, 0);/* MOV #0x80 or #0, W1 */
		send_inst(0x880191, 0);				/* MOV W1, TBLPAG */
		send_inst(0xBB0800, 0);				/* TBLWTL W0, [W0] */
		icsp_setwr();						/* BSET NVMCON, #WR */
		icsp_pollwr();
		/* Restore calibration word if needed */
		if (mode) {
			send_inst(0x240031, 0);			/* MOV #0x4003, W1 */
			send_inst(0x883B01, 0);			/* MOV W1, NVMCON */
			send_inst(0x200800, 0);			/* MOV #0x80, W0 */
			send_inst(0x880190, 0);			/* MOV W0, TBLPAG */
			send_inst(0x207FE1, 0);			/* MOV #0x7FE, W1 */
			send_inst(0x2000C2, 1);			/* MOV #12, W2 + NOP */
			send_inst(0xBB18B2, 0);			/* TBLWTL [W2++], [W1++] */
			icsp_setwr();					/* BSET NVMCON, #WR */
			icsp_pollwr();
		}
		break;
	case DEV33F:
		if (mode) {		/* Perform bulk erase */
			send_inst(0x2404F0, 0);			/* MOV #0x404F, W0 */
			send_inst(0x883B00, 0);			/* MOV W0, NVMCON */
			icsp_setwr();					/* BSET NVMCON, #WR */
			delay_ms(270);					/* 270ms */
			icsp_pollwr();
		} else {		/* Erase user memory only */
			send_inst(0x240420, 0);			/* MOV #0x4042, W0 */
			send_inst(0x883B00, 0);			/* MOV W0, NVMCON */
			for (adr = 0; adr < Device->FlashSize / 2; adr += 0x400) {
				send_inst(0x200000 | adr >> 12 & 0xFF0, 0);/* MOV #adr(23:16), W0 */
				send_inst(0x880190, 0);		/* MOV W0, TBLPAG */
				send_inst(0x200000 | adr << 4 & 0xFFFF0, 2);/* MOV #adr(15:0), W0 + 2NOP */
				send_inst(0xBB0800, 0);		/* TBLWTL W0, [W0] */
				icsp_setwr();				/* BSET NVMCON, #WR */
				delay_ms(20);				/* 20ms */
				icsp_pollwr();
			}
		}
		break;
	default:
		return 0;
	}
	icsp_initpc(0);

	return 1;
}




/* Initialize control port and device if needed */

static
int init_device (void)
{
	int res;


	res = open_ifport(&CtrlPort);		/* Open interface port and show port information */
	if (CtrlPort.Info1)
		MESS(CtrlPort.Info1);
	if (CtrlPort.Info2)
		MESS(CtrlPort.Info2);
	if (res) return RC_INIT;			/* return if open_ifport() failed */


	MESS("Entering ICSP mode...");
	enter_icspmode();
	if (!check_connection()) {
		MESS("Failed.\n");
		return RC_DEV;
	}

	/* search device */
	get_devid(DevId);
	for (Device = DevLst; Device->Name != NULL; Device++) {
		if (ForcedName[0]) {
			if (strcmp(ForcedName, Device->Name) == 0) break;
		} else {
			if (DevId[0] == Device->Devid) break;
		}
	}

	/* Show found device type */
	if (Device->Name) {
		fprintf(stderr, "\nDetected device is %s.\n", Device->Name);
	} else {
		fprintf(stderr, "\nUnknown device (DEVID:0x%04X).\n", DevId[0]);
		return RC_DEV;
	}

	return 0;
}





/*-----------------------------------------------------------------------
  Programming functions
-----------------------------------------------------------------------*/



/* -z command */

int test_ctrlport ()
{
	int n;


	n = open_ifport(&CtrlPort);		/* Open interface port and show port information */
	if (CtrlPort.Info1)
		MESS(CtrlPort.Info1);
	if (CtrlPort.Info2)
		MESS(CtrlPort.Info2);
	if (n) return RC_INIT;			/* return if failed open_ifport() */

	MESS("1000Hz test pulse on SCK. This takes a time...");
	for (n = 0; n < 10000; n++) {
		delay_ms(1);
		apply_sck();
	}

	return 0;
}



/* -q command */

int query_device (void)
{
	int rc;


	rc = init_device();
	if (rc) return rc;

	printf("Device ID  = 0x%04X\n", DevId[0]);
	printf("Device Rev = 0x%04X\n", DevId[1]);
	printf("Flash Size = %d bytes\n", Device->FlashSize * 3 / 4);
	if (Device->EepromSize)
		printf("EEPROM Size = %d bytes\n", Device->EepromSize);

	return 0;
}



/* -u command */

void show_devices (void)
{
	const DEVPROP *dev;
	char name[16];
	int n;

	printf("Device         DEVID     Program   Data\n");
	for (dev = DevLst; dev->Name; dev++) {
		strcpy(name, "               ");
		for (n = 0; dev->Name[n]; n++) name[n] = dev->Name[n];
		printf("%s0x%04X  %9u  %5u\n", name, dev->Devid, dev->FlashSize * 3 / 4, dev->EepromSize / 2);
	}
}




/* -e command */

int erase_bulk (void)
{
	int rc;


	rc = init_device();
	if (rc) return rc;

	MESS("Bulk Erasing...");
	erase_memory(2);
	MESS("Passed.\n");
	return 0;
}




/* -r command */

int read_device (void)
{
	DWORD adr;
	int rc;


	rc = init_device();
	if (rc) return rc;

	/* Read program memory */
	MESS("Reading program code...");
	for (adr = 0; adr < Device->FlashSize; adr += 256) {
		if (!read_memory(adr, 256, &CodeBuff[adr], 1)) {
			MESS("Failed.\n");
			return RC_FAIL;
		}
		if (Device->Class == DEV24F)
			memset(&CodeBuff[Device->FlashSize - 8], 0xFF, 8);
	}
	MESS("Passed.\n");

	/* Read configuration words */
	MESS("Reading configration bits...");
	if (!read_cfgreg(CfgBuff)) {
		MESS("Failed.\n");
		return RC_FAIL;
	}
	MESS("Passed.\n");

	/* Print program memory */
	output_hexfile(stdout, CodeBuff, 0, Device->FlashSize, 32);

	/* Print configuration words */
	switch (Device->Class) {
	case DEV24F:
		output_hexfile(stdout, CfgBuff, Device->FlashSize - 8, 8, 8);
		break;
	case DEV33F:
		output_hexfile(stdout, CfgBuff, 0xF80000 * 2, 48, 48);
		break;
	}

	/* Print an end block */
	output_hexfile(stdout, NULL, 0, 0, 0);

	return 0;
}




/* Write/Verify program code */

int write_program (void)
{
	DWORD adr, i;
	BYTE buff[256];
	int rc;


	rc = init_device();
	if (rc) return rc;

	adr = Device->FlashSize;
	if (CodeSize > adr) {
		MESS("Loaded code size > memory size.\n");
		return RC_FAIL;
	}
	if (Device->Class == DEV24F) {
		if (CodeSize < adr - 2) {
			MESS("Configuration words are not given.\n");
			return RC_FAIL;
		}
		/* Move configuration words to separated buffer */
		memcpy(CfgBuff, &CodeBuff[adr - 8], 8);
		memset(&CodeBuff[adr - 8], 0xFF, 8);
	}

	if (!Verify) {
		/* Erase user program memory before code programming */
		MESS("Erasing user memory...");
		erase_memory(0);
		MESS("\n");
	}

	MESS("Program: ");
	/* -v : Skip programming process for verify only mode */
	if (!Verify) 	{
		/* Write program code */
		MESS("Writing...");
		for (adr = 0; adr < CodeSize; adr += Device->FlashRow) {
			for (i = 0; i < Device->FlashRow && ((i & 3) == 3 || CodeBuff[adr+i] == 0xFF); i++);
			if (i < Device->FlashRow && !write_memory(adr, Device->FlashRow, &CodeBuff[adr], 1)) {
				MESS("Failed.\n");
				return RC_FAIL;
			}
		}

	}

	/* Verify program code */
	MESS("Verifying...");
	for (adr = 0; adr < CodeSize; adr += Device->FlashRow) {
		for (i = 0; i < Device->FlashRow && CodeBuff[adr+i] == 0xFF; i++);
		if (i < Device->FlashRow) {	/* Skip if all data in the row is 0xFF */
			if (!read_memory(adr, Device->FlashRow, buff, 1)) {
				MESS("Failed.\n");
				return RC_FAIL;
			}
			for (i = 0; i < Device->FlashRow && ((i & 3) == 3 || CodeBuff[adr+(i|3)] == 0xFF || CodeBuff[adr+i] == buff[i]); i++);
			if (i < Device->FlashRow) {
				fprintf(stderr, "Error at %06X:%02X-%02X.\n", adr+i, CodeBuff[adr+i], buff[i]);
				return RC_FAIL;
			}
		}
	}
	
	MESS("Passed.\n");

	return 0;
}



/* Write/Verify configuration register */
int write_config (void)
{
	DWORD i;
	BYTE buff[64];
	int err;


	MESS("Configurations: ");
	if (!Verify) {	/* -v : Skip programming process for verify only mode */
		MESS("Writing...");
		if (!write_cfgreg(CfgBuff)) {
			MESS("Failed.\n");
			return RC_FAIL;
		}
	}

	MESS("Verifying...");
	if (!read_cfgreg(buff)) {
		MESS("Failed.\n");
		return RC_FAIL;
	}
	err = 0;
	switch (Device->Class) {
	case DEV24F:
		for (i = 0; i < 8; i++) {
			if (!(i & 2) && CfgBuff[i] != buff[i]) err = 1;
		}
		break;
	case DEV33F:
		for (i = 0; i < 48; i++) {
			if (!(i & 3) && CfgBuff[i] != buff[i]) err = 1;
		}
		break;
	}
	if (err) {
		MESS("Error.\n");
		return RC_FAIL;
	}
	

	MESS("Passed.\n");


	return 0;
}




/* Terminate process */

void terminate (int rc)
{
	close_ifport();
	Device = NULL;

	if ((Pause == 1) || ((Pause == 2)&&(rc != 0))) {
		MESS("\nType Enter to exit...");
		getchar();
	}
}



/*-----------------------------------------------------------------------
  Main
-----------------------------------------------------------------------*/


int main (int argc, char **argv)
{
	int rc;


	if (rc = load_commands(argc, argv)) { 
		if(rc == RC_SYNTAX) MESS(MesUsage);
		terminate(rc);
		return rc;
	}

	/* Read device and terminate if -RP command is specified */
	if (Command == 'r') {
		rc = read_device();
		terminate(rc);
		return rc;
	}

	/* Check device and terminate if -R command is specified */
	if (Command == 'q') {
		rc = query_device();
		terminate(rc);
		return rc;
	}

	/* Perform bulk erase if -E command is specified */
	if (Command == 'e') {
		rc = erase_bulk();
		terminate(rc);
		return rc;
	}

	/* Show suported device list if -U command is specifiled */
	if (Command == 'u') {
		show_devices();
		rc = 0;
		terminate(0);
		return 0;
	}

	/* Perform timing test if -Z command is specified */
	if(Command == 'z') {
		rc = test_ctrlport();
		terminate(rc);
		return rc;
	}

	/* Write program code if program code is loaded */
	if (CodeSize) {
		if ((rc = write_program()) == 0) {
			rc = write_config();
		}
		terminate(rc);
		return rc;
	}

	MESS(MesUsage);
	rc = RC_SYNTAX;
	terminate(rc);
	return rc;
}

