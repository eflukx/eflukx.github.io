
#ifndef _WINDEF_
typedef unsigned char   BYTE;
typedef unsigned short	WORD;
typedef unsigned long	DWORD;
#endif /* _WINDEF_ */



#define MESS(str)	fputs(str, stderr)
#define INIFILE "pic24sp.ini"


/* Program error codes */

#define	RC_FAIL		1
#define	RC_FILE		2
#define	RC_INIT		3
#define RC_DEV		4
#define	RC_SYNTAX	5


/* Device property structure */

enum _devclass {	/* Device Class */
	DEVNUL, DEV24F, DEV24H, DEV33F
};

typedef struct _DEVPROP {
	const char *Name;		/* Device name */
	int		Class;			/* Device Class */
	WORD	Devid;			/* DEVID word */
							/* These memory sizes are in byte address in hex file */
	DWORD	FlashSize;		/* Size of total program memory */
	DWORD	FlashRow;		/* Size of a program memory row */
	DWORD	EepromSize;		/* Size of total data memory */
	DWORD	EepromRow;		/* Size of a data memory row */
	DWORD	ExeSize;		/* Size of total executable memory */
} DEVPROP;

/* Buffer size for flash and eeprom */

#define	MAX_FLASH	(512*1024)	/* Max Flash size */
#define	MAX_EEPROM	(  8*1024)	/* Max EEPROM size */
#define	PIPE_WINDOW	256			/* Pipe window for SPI bridge */




/* ICSP mode entry code */

#define	ICSP	0x4D434851


/* spi_rcvr() argument */

#define	RM_SYNC		0
#define	RM_ASYNC	1



/* Physical port properties */

typedef struct {
	WORD	PortClass;		/* Port class */
	WORD	PortNum;		/* Port number (1..)  */
	DWORD	Baud;			/* Baud rate (for SPI bridge) */
	char	*Info1, *Info2;	/* Information strings, returned by open_ifport() */
} PORTPROP;

enum _portclass {	/* Port class */
	TY_LPT, TY_COMM, TY_VCOM, TY_BRIDGE, TY_AVRSP, TY_STK200, TY_XILINX, TY_LATTICE, TY_ALTERA
};



/* Prototypes for platform dependent functions */

int open_ifport (PORTPROP *);
void close_ifport (void);
void set_reset (int val);
int get_miso (void);
void set_mosi (int val);
void apply_sck (void);
void send_byte (BYTE td);
BYTE read_byte (int mode);
void send_inst (DWORD inst, int n);
WORD read_vlsi (int mode);
void delay_ms (WORD dly);
void spi_delayedget (void *ptr, DWORD cnt);
FILE *open_cfgfile(char *filename);


