/*----------------------------------------------------------------------------*/
/* V850ES Flash Programmer for Hx2,Jx2,Kx2,Ix2,Jx3 devices R0.03 (C)ChaN,2009 */
/*----------------------------------------------------------------------------*/


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <conio.h>
#include <windows.h>


#define	INIFILE		"sp850es.ini"
#define MAX_FLASH	(1024*1024)
#define	SOH			1
#define	STX			2
#define	ETX			3
#define ETB			0x17
#define	ACK			6
#define NAK			0x15
#define CMD_STATUS		0x70
#define CMD_RESET		0x00
#define CMD_FREQ_SET	0x90
#define CMD_BAUD_SET	0x9A
#define CMD_CHIP_ERASE	0x20
#define CMD_BLOCK_ERASE	0x22
#define CMD_PROGRAM		0x40
#define CMD_VERIFY		0x13
#define CMD_BLK_BLANK	0x32
#define CMD_CHECKSUM	0xB0
#define CMD_SECUR_SET	0xA0



/*-----------------------------------------------------------------------
  Device Parameters
-----------------------------------------------------------------------*/

/* Block table for Hx2 devices */
DWORD Blk_Hx2[] = {
	0x00000, 0x0E000, 0x10000, 0x1E000, 0x20000, 0x2E000, 0x3C000, 0x3E000,
	0x40000, 0x4F000, 0x5E000, 0x6D000, 0x7C000, 0x7D000, 0x7E000, 0x7F000,
	0x80000
};

/* Block table for Ix2 devices */
DWORD Blk_Ix2[] = {
	0x00000, 0x02000, 0x10000, 0x12000, 0x20000
};

/* Block table for Jx2 devices */
DWORD Blk_Jx2[] = {
	0x00000, 0x07000, 0x0E000, 0x15000, 0x1C000, 0x1D000, 0x1E000, 0x1F000,
	0x20000, 0x30000, 0x40000, 0x50000, 0x60000, 0x70000, 0x80000, 0x90000,
	0xA0000
};

/* Block table for Kx2 devices */
DWORD Blk_Kx2[] = {
	0x00000, 0x00800, 0x01000, 0x01800, 0x02000, 0x02800, 0x03000, 0x03800,
	0x04000, 0x04800, 0x05000, 0x05800, 0x06000, 0x06800, 0x07000, 0x07800,
	0x08000, 0x08800, 0x09000, 0x09800, 0x0A000, 0x0A800, 0x0B000, 0x0B800,
	0x0C000, 0x0C800, 0x0D000, 0x0D800, 0x0E000, 0x0E800, 0x0F000, 0x0F800,
	0x10000, 0x10800, 0x11000, 0x11800, 0x12000, 0x12800, 0x13000, 0x13800,
	0x14000, 0x14800, 0x15000, 0x15800, 0x16000, 0x16800, 0x17000, 0x17800,
	0x18000, 0x18800, 0x19000, 0x19800, 0x1A000, 0x1A800, 0x1B000, 0x1B800,
	0x1C000, 0x1C800, 0x1D000, 0x1D800, 0x1E000, 0x1E800, 0x1F000, 0x1F800,
	0x20000, 0x20800, 0x21000, 0x21800, 0x22000, 0x22800, 0x23000, 0x23800,
	0x24000, 0x24800, 0x25000, 0x25800, 0x26000, 0x26800, 0x27000, 0x27800,
	0x28000, 0x28800, 0x29000, 0x29800, 0x2A000, 0x2A800, 0x2B000, 0x2B800,
	0x2C000, 0x2C800, 0x2D000, 0x2D800, 0x2E000, 0x2E800, 0x2F000, 0x2F800,
	0x30000, 0x30800, 0x31000, 0x31800, 0x32000, 0x32800, 0x33000, 0x33800,
	0x34000, 0x34800, 0x35000, 0x35800, 0x36000, 0x36800, 0x37000, 0x37800,
	0x38000, 0x38800, 0x39000, 0x39800, 0x3A000, 0x3A800, 0x3B000, 0x3B800,
	0x3C000, 0x3C800, 0x3D000, 0x3D800, 0x3E000, 0x3E800, 0x3F000, 0x3F800,
	0x40000
};

/* Block table for Jx3 devices */
DWORD Blk_Jx3[] = {
	0x00000, 0x01000, 0x02000, 0x03000, 0x04000, 0x05000, 0x06000, 0x07000,
	0x08000, 0x09000, 0x0A000, 0x0B000, 0x0C000, 0x0D000, 0x0E000, 0x0F000,
	0x10000, 0x11000, 0x12000, 0x13000, 0x14000, 0x15000, 0x16000, 0x17000,
	0x18000, 0x19000, 0x1A000, 0x1B000, 0x1C000, 0x1D000, 0x1E000, 0x1F000,
	0x20000, 0x21000, 0x22000, 0x23000, 0x24000, 0x25000, 0x26000, 0x27000,
	0x28000, 0x29000, 0x2A000, 0x2B000, 0x2C000, 0x2D000, 0x2E000, 0x2F000,
	0x30000, 0x31000, 0x32000, 0x33000, 0x34000, 0x35000, 0x36000, 0x37000,
	0x38000, 0x39000, 0x3A000, 0x3B000, 0x3C000, 0x3D000, 0x3E000, 0x3F000,
	0x40000, 0x41000, 0x42000, 0x43000, 0x44000, 0x45000, 0x46000, 0x47000,
	0x48000, 0x49000, 0x4A000, 0x4B000, 0x4C000, 0x4D000, 0x4E000, 0x4F000,
	0x50000, 0x51000, 0x52000, 0x53000, 0x54000, 0x55000, 0x56000, 0x57000,
	0x58000, 0x59000, 0x5A000, 0x5B000, 0x5C000, 0x5D000, 0x5E000, 0x5F000,
	0x60000, 0x61000, 0x62000, 0x63000, 0x64000, 0x65000, 0x66000, 0x67000,
	0x68000, 0x69000, 0x6A000, 0x6B000, 0x6C000, 0x6D000, 0x6E000, 0x6F000,
	0x70000, 0x71000, 0x72000, 0x73000, 0x74000, 0x75000, 0x76000, 0x77000,
	0x78000, 0x79000, 0x7A000, 0x7B000, 0x7C000, 0x7D000, 0x7E000, 0x7F000,
	0x80000, 0x81000, 0x82000, 0x83000, 0x84000, 0x85000, 0x86000, 0x87000,
	0x88000, 0x89000, 0x8A000, 0x8B000, 0x8C000, 0x8D000, 0x8E000, 0x8F000,
	0x90000, 0x91000, 0x92000, 0x93000, 0x94000, 0x95000, 0x96000, 0x97000,
	0x98000, 0x99000, 0x9A000, 0x9B000, 0x9C000, 0x9D000, 0x9E000, 0x9F000,
	0xA0000, 0xA1000, 0xA2000, 0xA3000, 0xA4000, 0xA5000, 0xA6000, 0xA7000,
	0xA8000, 0xA9000, 0xAA000, 0xAB000, 0xAC000, 0xAD000, 0xAE000, 0xAF000,
	0xB0000, 0xB1000, 0xB2000, 0xB3000, 0xB4000, 0xB5000, 0xB6000, 0xB7000,
	0xB8000, 0xB9000, 0xBA000, 0xBB000, 0xBC000, 0xBD000, 0xBE000, 0xBF000,
	0xC0000, 0xC1000, 0xC2000, 0xC3000, 0xC4000, 0xC5000, 0xC6000, 0xC7000,
	0xC8000, 0xC9000, 0xCA000, 0xCB000, 0xCC000, 0xCD000, 0xCE000, 0xCF000,
	0xD0000, 0xD1000, 0xD2000, 0xD3000, 0xD4000, 0xD5000, 0xD6000, 0xD7000,
	0xD8000, 0xD9000, 0xDA000, 0xDB000, 0xDC000, 0xDD000, 0xDE000, 0xDF000,
	0xE0000, 0xE1000, 0xE2000, 0xE3000, 0xE4000, 0xE5000, 0xE6000, 0xE7000,
	0xE8000, 0xE9000, 0xEA000, 0xEB000, 0xEC000, 0xED000, 0xEE000, 0xEF000,
	0xF0000, 0xF1000, 0xF2000, 0xF3000, 0xF4000, 0xF5000, 0xF6000, 0xF7000,
	0xF8000, 0xF9000, 0xFA000, 0xFB000, 0xFC000, 0xFD000, 0xFE000, 0xFF000
};


typedef struct _DEVLST {
	DWORD model;
	DWORD flashsize;
	DWORD *blocktbl;
} DEVLST;

DEVLST devices[] = {
	{ 3700, 0x10000, Blk_Hx2 },
	{ 3701, 0x20000, Blk_Hx2 },
	{ 3702, 0x10000, Blk_Hx2 },
	{ 3703, 0x20000, Blk_Hx2 },
	{ 3704, 0x40000, Blk_Hx2 },
	{ 3706, 0x20000, Blk_Hx2 },
	{ 3707, 0x40000, Blk_Hx2 },
	{ 3709, 0x20000, Blk_Hx2 },
	{ 3710, 0x40000, Blk_Hx2 },
	{ 3711, 0x5E000, Blk_Hx2 },
	{ 3712, 0x80000, Blk_Hx2 },
	{ 3713, 0x10000, Blk_Ix2 },
	{ 3714, 0x20000, Blk_Ix2 },
	{ 3715, 0x20000, Blk_Jx2 },
	{ 3716, 0x40000, Blk_Jx2 },
	{ 3717, 0x60000, Blk_Jx2 },
	{ 3718, 0x80000, Blk_Jx2 },
	{ 3719, 0xA0000, Blk_Jx2 },
	{ 3720, 0x20000, Blk_Jx2 },
	{ 3721, 0x40000, Blk_Jx2 },
	{ 3722, 0x60000, Blk_Jx2 },
	{ 3723, 0x80000, Blk_Jx2 },
	{ 3724, 0xA0000, Blk_Jx2 },
	{ 3726, 0x20000, Blk_Kx2 },
	{ 3728, 0x20000, Blk_Kx2 },
	{ 3729, 0x40000, Blk_Kx2 },
	{ 3731, 0x20000, Blk_Kx2 },
	{ 3732, 0x40000, Blk_Kx2 },
	{ 3733, 0x20000, Blk_Kx2 },
	{ 3734, 0x40000, Blk_Kx2 },
	{ 3739, 0x60000, Blk_Jx3 },
	{ 3740, 0x80000, Blk_Jx3 },
	{ 3741, 0xC0000, Blk_Jx3 },
	{ 3742, 0x100000, Blk_Jx3 },
	{ 3743, 0x60000, Blk_Jx3 },
	{ 3744, 0x80000, Blk_Jx3 },
	{ 3745, 0xC0000, Blk_Jx3 },
	{ 3746, 0x100000, Blk_Jx3 },
	{ 0   , 0,       NULL }
};



/*-----------------------------------------------------------------------
  Global variables (initialized by load_commands())
-----------------------------------------------------------------------*/

DWORD FlashSize, *BlockTbl;
DWORD Bps, iBps;			/* 3:9600, 4:19200, 5:31250, 6:38400, 7:76800, 8:153600 */
DWORD Freq;					/* Input clock frequency [kHz] */

BOOL Verify;				/* Verify */
DWORD CodeSize;				/* Loaded program code size */
BYTE CodeBuff[MAX_FLASH];	/* Program code buffer */


char PortNum[20] = "COM1";


DCB dcb = { sizeof(DCB),
			9600, TRUE, FALSE, FALSE, FALSE,
			DTR_CONTROL_DISABLE, FALSE,
			TRUE, FALSE, FALSE, FALSE, FALSE,
			RTS_CONTROL_DISABLE, FALSE, 0, 0,
			10, 10,
			8, NOPARITY, ONESTOPBIT, '\x11', '\x13', '\xFF', '\xFF', 0 };

COMMTIMEOUTS commtimeouts1 = { 0, 1, 200, 1, 200};

HANDLE hComm = INVALID_HANDLE_VALUE;



/*-----------------------------------------------------------------------
  Messages
-----------------------------------------------------------------------*/


void output_usage ()
{
	int n;
	const char *const MesUsage[] = {
		"V850ES flash programming tool R0.03 (C)ChaN,2007  http://elm-chan.org/\n\n",
		"Usage: sp850es <sw..> <hex file> ...\n\n",
		"Device name UPD70F(XXXX)   : -dev=<XXXX>\n",
		"Oscillator frequecy (kHz)  : -freq=<freq> (2000-10000)\n",
		"Communication speed [9600] : -bps=<bps> (9600,19200,38400,76800,153600)\n",
		"Control port [COM1]        : -port=<port>\n",
		"Supprted Device:\n",
		"UPD70F37(00|01|02|03|04|06|07|09|10|11|12|13|14|15|16|17|18|19|20|21|22|23|24|26|28|29|31|32|33|34|39|40|41|42|43|44|45|46)",
		NULL
	};


	for(n = 0; MesUsage[n] != NULL; n++)
		printf(MesUsage[n]);
}



/*-----------------------------------------------------------------------
  Hex format manupilations
-----------------------------------------------------------------------*/


/* Pick a hexdecimal value from hex record */

DWORD get_valh (char **lp,	/* pointer to line read pointer */
			   int count, 	/* number of digits to get (2,4,6,8) */
			   BYTE *sum)	/* byte check sum */
{
	DWORD val = 0;
	BYTE n;


	do {
		n = *(*lp)++;
		if((n -= '0') >= 10) {
			if((n -= 7) < 10) return(0xFFFFFFFF);
			if(n > 0xF) return(0xFFFFFFFF);
		}
		val = (val << 4) + n;
		if(count & 1) *sum += (BYTE)val;
	} while(--count);
	return(val);
}




/* Load Intel/Motorola hex file into data buffer */ 

long input_hexfile (FILE *fp,			/* input stream */
				   BYTE *buffer,		/* data input buffer */
				   DWORD buffsize,		/* size of data buffer */
				   DWORD *datasize)		/* effective data size in the input buffer */
{
	char line[600];			/* line input buffer */
	char *lp;				/* line read pointer */
	long lnum = 0;			/* input line number */
	WORD seg = 0, hadr = 0;	/* address expantion values for intel hex */
	DWORD addr, count, n;
	BYTE sum;


	while(fgets(line, sizeof(line), fp) != NULL) {
		lnum++;
		lp = &line[1]; sum = 0;

		if(line[0] == ':') {	/* Intel Hex format */
			if((count = get_valh(&lp, 2, &sum)) > 0xFF) return(lnum);	/* byte count */
			if((addr = get_valh(&lp, 4, &sum)) > 0xFFFF) return(lnum);	/* offset */

			switch (get_valh(&lp, 2, &sum)) {	/* block type? */
				case 0x00 :	/* data block */
					addr += (seg << 4) + (hadr << 16);
					while(count--) {
						if((n = get_valh(&lp, 2, &sum)) > 0xFF) return(lnum);
						if(addr >= buffsize) continue;	/* clip by buffer size */
						buffer[addr++] = (BYTE)n;		/* store the data */
						if(addr > *datasize)			/* update data size information */
							*datasize = addr;
					}
					break;

				case 0x01 :	/* end block */
					if(count) return(lnum);
					break;

				case 0x02 :	/* segment block */
					if(count != 2) return(lnum);
					if((seg = (WORD)get_valh(&lp, 4, &sum)) == 0xFFFF) return(lnum);
					break;

				case 0x03 :	/* program start address (segment:offset) */
					if(count != 4) return lnum;
					get_valh(&lp, 8, &sum);
					break;

				case 0x04 :	/* high address block */
					if(count != 2) return(lnum);
					if((hadr = (WORD)get_valh(&lp, 4, &sum)) == 0xFFFF) return(lnum);
					break;

				case 0x05 :	/* program start address (linear) */
					if(count != 4) return lnum;
					get_valh(&lp, 8, &sum);
					break;

				default:	/* invalid block */
					return(lnum);
			} /* switch */
			if(get_valh(&lp, 2, &sum) > 0xFF) return(lnum);	/* get check sum */
			if(sum) return(lnum);							/* test check sum */
		} /* if */

		if(line[0] == 'S') {	/* Motorola S format */
			if((*lp >= '1')&&(*lp <= '3')) {

				switch (*lp++) {	/* record type? (S1/S2/S3) */
					case '1' :
						if((count = get_valh(&lp, 2, &sum) - 3) > 0xFF) return(lnum);
						if((addr = get_valh(&lp, 4, &sum)) == 0xFFFFFFFF) return(lnum);
						break;
					case '2' :
						if((count = get_valh(&lp, 2, &sum) - 4) > 0xFF) return(lnum);
						if((addr = get_valh(&lp, 6, &sum)) == 0xFFFFFFFF) return(lnum);
						break;
					default :
						if((count = get_valh(&lp, 2, &sum) - 5) > 0xFF) return(lnum);
						if((addr = get_valh(&lp, 8, &sum)) == 0xFFFFFFFF) return(lnum);
				}
				while(count--) {
					if((n = get_valh(&lp, 2, &sum)) > 0xFF) return(lnum);
					if(addr >= buffsize) continue;	/* clip by buffer size */
					buffer[addr++] = (BYTE)n;		/* store the data */
					if(addr > *datasize)			/* update data size information */
						*datasize = addr;
				}
				if(get_valh(&lp, 2, &sum) > 0xFF) return(lnum);	/* get check sum */
				if(sum != 0xFF) return(lnum);					/* test check sum */
			} /* switch */
		} /* if */

	} /* while */

	return( feof(fp) ? 0 : -1 );
}





/*-----------------------------------------------------------------------
  Command line analysis
-----------------------------------------------------------------------*/


int load_commands (int argc, char **argv)
{
	char *cp, *sp, *cmdlst[20], cmdbuff[256], filename[256], *dmy;
	int cmd;
	DWORD n;
	long ln;
	FILE *fp;
	DEVLST *dev;
	DWORD BpsTbl[] = { 9600, 19200, 31250, 38400, 76800, 153600 };


	memset(CodeBuff, 0xFF, sizeof(CodeBuff));
	cmd = 0; cp = cmdbuff;

	/* Import ini file as command line parameters */
	if((fp = fopen(INIFILE, "rt")) == NULL) {
		if(SearchPath(NULL, INIFILE, NULL, sizeof(filename), filename, &dmy))
			fp = fopen(filename, "rt");
	}
	if(fp != NULL) {
		while(fgets(cp, cmdbuff + sizeof(cmdbuff) - cp, fp) != NULL) {
			if(cmd >= (sizeof(cmdlst) / sizeof(cmdlst[0]) - 1)) break;
			if(*cp <= ' ') break;
			cmdlst[cmd++] = cp;
			for(sp = cp; *sp > ' '; sp++);
			*sp = '\0'; cp = sp + 1;
		}
		fclose(fp);
	}

	/* Get command line parameters */
	while(--argc && (cmd < (sizeof(cmdlst) / sizeof(cmdlst[0]) - 1)))
		cmdlst[cmd++] = *++argv;
	cmdlst[cmd] = NULL;

	/* Analyze command line parameters... */
	for(cmd = 0; cmdlst[cmd] != NULL; cmd++) {
		cp = cmdlst[cmd];

		if(strstr(cp, "-port=") == cp) {	/* COM port */
			strcpy(PortNum, cp+6);
			continue;
		}
		if(strstr(cp, "-verify") == cp) {	/* Verify */
			Verify = TRUE;
			continue;
		}
		if(strstr(cp, "-bps=") == cp) {	/* Speed */
			Bps = atoi(cp+5);
			for (iBps = 3; iBps < 9 && BpsTbl[iBps-3] != Bps; iBps++) ;
			if (iBps >= 9) {
				printf("Invalid bit rate.\n");
				return 8;
			}
			continue;
		}
		if(strstr(cp, "-freq=") == cp) {	/* Frequency */
			Freq = atoi(cp+6);
			if (Freq > 10000 || Freq < 2000) {
				printf("Oscillator frequency %d kHz is out of range.\n", Freq);
				return 8;
			}
			continue;
		}
		if(strstr(cp, "-dev=") == cp) {	/* Device number */
			n = atoi(cp+5);
			for (dev = devices; dev->model && dev->model != n; dev++) ;
			if (!dev->model) {
				printf("The specified device UPD70F%04u is not supported.\n", n);
				return 8;
			}
			FlashSize = dev->flashsize;
			BlockTbl = dev->blocktbl;
			continue;
		}
		if(strstr(cp, "-") == cp) {	/* Invalid command */
			printf("\"%s\" is an invalid command.\n", cp);
			return 5;
		} else {						/* Program code */
			if((fp = fopen(cp, "rt")) == NULL) {
				printf("Unable to open \"%s\".\n", cp);
				return 7;
			}
			printf("\nLoading \"%s\"...", cp);
			ln = input_hexfile(fp, CodeBuff, sizeof(CodeBuff), &CodeSize);
			fclose(fp);
			if(ln) {
				if(ln < 0)
					printf(" file access failure.\n");
				else
					printf(" format error (%ld).\n", ln);
				return 7;
			}
			printf(" code size is 0x%lX.", CodeSize);
			continue;
		}

	} /* for */

	if (!FlashSize || !CodeSize) return 9;
	if (CodeSize > FlashSize) {
		printf("\nCode size > Flash size.");
		return 7;
	}
	return 0;
}




/*-----------------------------------------------------------------------
  Programming Code
-----------------------------------------------------------------------*/


void send_frame (BYTE header, BYTE footer, const BYTE* buffer, DWORD count)
{
	BYTE n, s[2];
	DWORD wc;


	/* Flush receiving buffer */
	commtimeouts1.ReadTotalTimeoutConstant = 0;
	SetCommTimeouts(hComm, &commtimeouts1);
	do
		ReadFile(hComm, s, 2, &wc, NULL);
	while (wc == 2);

	s[0] = header; s[1] = (BYTE)count;			/* STX|ETX and data count */
	WriteFile(hComm, s, 2, &wc, NULL);

	WriteFile(hComm, buffer, count, &wc, NULL);	/* data */

	n = 0 - (BYTE)count;						/* Sum */
	do
		n -= *buffer++;
	while (--count);

	s[0] = n; s[1] = footer;				/* Sum and ETB|ETX */
	WriteFile(hComm, s, 2, &wc, NULL);
}



BOOL rcvr_frame (BYTE *buff, DWORD lbuff, DWORD tmr)
{
	BYTE d[2], sum;
	DWORD rd, len, n;


	commtimeouts1.ReadTotalTimeoutConstant = tmr;	/* Set timeout value */
	SetCommTimeouts(hComm, &commtimeouts1);

	ReadFile(hComm, d, 2, &rd, NULL);				/* Get Heder and Length */
	if (rd != 2 || d[0] != STX || !d[1]) return FALSE;
	len = d[1];
	if (len != lbuff) return FALSE;

	ReadFile(hComm, buff, len, &rd, NULL);			/* Get Data */
	if (rd != len) return FALSE;

	ReadFile(hComm, d, 2, &rd, NULL);				/* Get Sum and Footer */
	if (rd != 2 || d[1] != ETX) return FALSE;

	sum = 0 - (BYTE)len;							/* Check sum error */
	for (n = 0; n < len; n++) sum -= buff[n];
	if (sum != d[0]) return FALSE;

	return TRUE;
}




int boot (void)
{
	DWORD msr;
	BYTE buf[6];
	int n;


	/* Release RESET */
	dcb.fDtrControl = DTR_CONTROL_ENABLE;	/* ER = ON */
	dcb.fRtsControl = RTS_CONTROL_ENABLE;	/* RS = ON */
	SetCommState(hComm, &dcb);
	printf("\nBoot...");
	n = 0;
	do {		/* Make sure that reset is released */
		Sleep(20);
		if(!GetCommModemStatus(hComm, &msr)) goto boot_exit;
		n = ((msr & (MS_DSR_ON | MS_CTS_ON)) == (MS_DSR_ON | MS_CTS_ON)) ? n + 1 : 0;
	} while (n < 10);

	/* Bit rate synchronization */
	printf("Sync...");
	buf[0] = 0;
	WriteFile(hComm, buf, 1, &n, NULL);		/* \0 */
	Sleep(50);								/* 50ms */
	WriteFile(hComm, buf, 1, &n, NULL);		/* \0 */

	/* RESET command */
	for (n = 16; n; n--) {
		Sleep(50);							/* 50ms */
		buf[0] = CMD_RESET;
		send_frame(SOH, ETX, buf, 1);
		if (rcvr_frame(buf, 1, 100) && buf[0] == ACK) break;
	}
	if (!n) goto boot_exit;

	/* Set frequency if specified */
	if (Freq) {
		printf("Freq...");
		buf[0] = CMD_FREQ_SET;
		for (n = 3; Freq > 999; Freq/=10, n++);
		buf[4] = (BYTE)n;
		buf[3] = (BYTE)(Freq % 10); Freq /=10;
		buf[2] = (BYTE)(Freq % 10); Freq /=10;
		buf[1] = (BYTE)Freq;
		send_frame(SOH, ETX, buf, 5);
		if (!rcvr_frame(buf, 1, 100) || buf[0] != ACK) goto boot_exit;
	}

	/* Set baud rate if specified */
	if (Bps) {
		printf("Baud...");
		buf[0] = CMD_BAUD_SET;
		buf[1] = (BYTE)iBps;
		send_frame(SOH, ETX, buf, 2);
		Sleep(30);
		dcb.BaudRate = Bps;
		SetCommState(hComm, &dcb);
		Sleep(30);
		buf[0] = CMD_RESET;
		send_frame(SOH, ETX, buf, 1);
		if (!rcvr_frame(buf, 1, 100) || buf[0] != ACK) goto boot_exit;
	}

	printf("OK.");
	return 0;

boot_exit:
	printf("Failed.");
	return 3;
}




int program (void)
{
	BYTE buf[8], blk;
	DWORD addr, blksize, a, c;


	for (addr = blk = 0; addr < CodeSize; addr += blksize, blk++) {
		/* Get block size */
		blksize = *(BlockTbl+blk+1) - *(BlockTbl+blk);

		/* Erase block */
		printf("\nErasing block %d...", blk);
		buf[0] = CMD_BLOCK_ERASE;
		buf[1] = blk;
		send_frame(SOH, ETX, buf, 2);
		if (!rcvr_frame(buf, 1, 15000) || buf[0] != ACK) goto prg_exit;

		/* Skip bottom padded 0xFFs */
		for (c = a = 0; a < blksize; a++) {
			if (CodeBuff[addr+a] != 0xFF)
				c = a + 1;
		}
		if (c == 0) continue;
		c = (c + 255) & 0xFFFF00;

		/* Write block data */
		printf("\nWriting %06X-%06X..", addr, addr+blksize-1);
		buf[0] = CMD_PROGRAM;
		buf[1] = (BYTE)(addr >> 16);
		buf[2] = (BYTE)(addr >> 8);
		buf[3] = (BYTE)(addr);
		buf[4] = (BYTE)((addr+c-1) >> 16);
		buf[5] = (BYTE)((addr+c-1) >> 8);
		buf[6] = (BYTE)((addr+c-1));
		send_frame(SOH, ETX, buf, 7);
		if (!rcvr_frame(buf, 1, 100) || buf[0] != ACK) goto prg_exit;

		for (a = addr; c; a += 256, c -= 256) {
			send_frame(STX, (BYTE)((c > 256) ? ETB : ETX), &CodeBuff[a], 256);
			if (!rcvr_frame(buf, 2, 300) || buf[0] != ACK || buf[1] != ACK) goto prg_exit;
		}
		printf(".");
		if (!rcvr_frame(buf, 1, 9000) || buf[0] != ACK) goto prg_exit;
	}
	printf("\nCompleted.\n");
	return 0;

prg_exit:
	printf("Failed.\n");
	return 3;
}




int verify (void)
{
	BYTE buf[8], blk;
	DWORD addr, blksize, a, c;


	for (addr = blk = 0; addr < CodeSize; addr += blksize, blk++) {
		/* Get block size */
		blksize = *(BlockTbl+blk+1) - *(BlockTbl+blk);
		c = blksize;

		/* Verify block data */
		printf("\nVerifying %06X-%06X...", addr, addr+blksize-1);
		buf[0] = CMD_VERIFY;
		buf[1] = (BYTE)(addr >> 16);
		buf[2] = (BYTE)(addr >> 8);
		buf[3] = (BYTE)(addr);
		buf[4] = (BYTE)((addr+c-1) >> 16);
		buf[5] = (BYTE)((addr+c-1) >> 8);
		buf[6] = (BYTE)((addr+c-1));
		send_frame(SOH, ETX, buf, 7);
		if (!rcvr_frame(buf, 1, 100) || buf[0] != ACK) goto prg_exit;

		for (a = addr; c; a += 256, c -= 256) {
			send_frame(STX, (BYTE)((c > 256) ? ETB : ETX), &CodeBuff[a], 256);
			if (!rcvr_frame(buf, 2, 300) || buf[0] != ACK || buf[1] != ACK) goto prg_exit;
		}
	}
	printf("\nPassed.\n");
	return 0;

prg_exit:
	printf("Failed.\n");
	return 3;
}




int main (int argc, char **argv)
{
	int rc;


	if(rc = load_commands(argc, argv)) { 
		if(rc == 9) output_usage();
		goto exit;
	}

	hComm = CreateFile(PortNum, GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if(hComm == INVALID_HANDLE_VALUE) {
		fprintf(stderr, "%s could not be opened.\n", PortNum);
		rc = 5;
		goto exit;
	}
	SetCommState(hComm, &dcb);

	rc = boot();
	if(!rc) {
		if (Verify)
			rc = verify();
		else
			rc = program();
	}

exit:
	if (hComm != INVALID_HANDLE_VALUE) CloseHandle(hComm);

	return rc;
}

