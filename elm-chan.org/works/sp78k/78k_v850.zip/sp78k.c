/*---------------------------------------------------------------------------*/
/* 78K0S/Kx1+ Serial Programmer R0.01                      (C)ChaN,2006      */
/*---------------------------------------------------------------------------*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <conio.h>
#include <windows.h>


#define	INIFILE		"sp78k.ini"



/*-----------------------------------------------------------------------
  Global variables (initialized by load_commands())
-----------------------------------------------------------------------*/

DWORD CodeSize = 0;
DWORD FlashSize = 8192;
BYTE CodeBuff[8192];		/* Program code R/W buffer */


char PortNum[20] = "COM1";


DCB dcb = { sizeof(DCB),
			115200, TRUE, FALSE, FALSE, FALSE,
			DTR_CONTROL_ENABLE, FALSE,
			TRUE, FALSE, FALSE, FALSE, FALSE,
			RTS_CONTROL_DISABLE, FALSE, 0, 0,
			10, 10,
			8, EVENPARITY, ONESTOPBIT, '\x11', '\x13', '\xFF', '\xFF', 0 };
COMMTIMEOUTS commtimeouts1 = { 0, 1, 200, 1, 200};

HANDLE hComm = INVALID_HANDLE_VALUE;



/*-----------------------------------------------------------------------
  Messages
-----------------------------------------------------------------------*/



void output_usage ()
{
	int n;
	const char *const MesUsage[] = {
		"SP78K - Serial Programmer for 78K0S/Kx1+ R0.01 (C)ChaN,2006\n",
		" sp78k <sw..> <hex file>\n",
		"  -port=<port>\n",		// COM port (default:COM1)
		"  -bps=<speed>\n",		// Speed (default:115200/8MHz)
		"  -memsize=<size>\n",	// Target memory size. (default:8192)
		NULL
	};


	for(n = 0; MesUsage[n] != NULL; n++)
		printf(MesUsage[n]);
}



/*-----------------------------------------------------------------------
  Hex format manupilations
-----------------------------------------------------------------------*/


/* Pick a hexdecimal value from hex record */

DWORD get_valh (char **lp,	/* pointer to line read pointer */
			   int count, 	/* number of digits to get (2,4,6,8) */
			   BYTE *sum)	/* byte check sum */
{
	DWORD val = 0;
	BYTE n;


	do {
		n = *(*lp)++;
		if((n -= '0') >= 10) {
			if((n -= 7) < 10) return(0xFFFFFFFF);
			if(n > 0xF) return(0xFFFFFFFF);
		}
		val = (val << 4) + n;
		if(count & 1) *sum += (BYTE)val;
	} while(--count);
	return(val);
}




/* Load Intel/Motorola hex file into data buffer */ 

long input_hexfile (FILE *fp,			/* input stream */
				   BYTE *buffer,		/* data input buffer */
				   DWORD buffsize,		/* size of data buffer */
				   DWORD *datasize)		/* effective data size in the input buffer */
{
	char line[600];			/* line input buffer */
	char *lp;				/* line read pointer */
	long lnum = 0;			/* input line number */
	WORD seg = 0, hadr = 0;	/* address expantion values for intel hex */
	DWORD addr, count, n;
	BYTE sum;


	while(fgets(line, sizeof(line), fp) != NULL) {
		lnum++;
		lp = &line[1]; sum = 0;

		if(line[0] == ':') {	/* Intel Hex format */
			if((count = get_valh(&lp, 2, &sum)) > 0xFF) return(lnum);	/* byte count */
			if((addr = get_valh(&lp, 4, &sum)) > 0xFFFF) return(lnum);	/* offset */

			switch (get_valh(&lp, 2, &sum)) {	/* block type? */
				case 0x00 :	/* data block */
					addr += (seg << 4) + (hadr << 16);
					while(count--) {
						if((n = get_valh(&lp, 2, &sum)) > 0xFF) return(lnum);
						if(addr >= buffsize) continue;	/* clip by buffer size */
						buffer[addr++] = (BYTE)n;		/* store the data */
						if(addr > *datasize)			/* update data size information */
							*datasize = addr;
					}
					break;

				case 0x01 :	/* end block */
					if(count) return(lnum);
					break;

				case 0x02 :	/* segment block */
					if(count != 2) return(lnum);
					if((seg = (WORD)get_valh(&lp, 4, &sum)) == 0xFFFF) return(lnum);
					break;

				case 0x04 :	/* high address block */
					if(count != 2) return(lnum);
					if((hadr = (WORD)get_valh(&lp, 4, &sum)) == 0xFFFF) return(lnum);
					break;

				default:	/* invalid block */
					return(lnum);
			} /* switch */
			if(get_valh(&lp, 2, &sum) > 0xFF) return(lnum);	/* get check sum */
			if(sum) return(lnum);							/* test check sum */
		} /* if */

		if(line[0] == 'S') {	/* Motorola S format */
			if((*lp >= '1')&&(*lp <= '3')) {

				switch (*lp++) {	/* record type? (S1/S2/S3) */
					case '1' :
						if((count = get_valh(&lp, 2, &sum) - 3) > 0xFF) return(lnum);
						if((addr = get_valh(&lp, 4, &sum)) == 0xFFFFFFFF) return(lnum);
						break;
					case '2' :
						if((count = get_valh(&lp, 2, &sum) - 4) > 0xFF) return(lnum);
						if((addr = get_valh(&lp, 6, &sum)) == 0xFFFFFFFF) return(lnum);
						break;
					default :
						if((count = get_valh(&lp, 2, &sum) - 5) > 0xFF) return(lnum);
						if((addr = get_valh(&lp, 8, &sum)) == 0xFFFFFFFF) return(lnum);
				}
				while(count--) {
					if((n = get_valh(&lp, 2, &sum)) > 0xFF) return(lnum);
					if(addr >= buffsize) continue;	/* clip by buffer size */
					buffer[addr++] = (BYTE)n;		/* store the data */
					if(addr > *datasize)			/* update data size information */
						*datasize = addr;
				}
				if(get_valh(&lp, 2, &sum) > 0xFF) return(lnum);	/* get check sum */
				if(sum != 0xFF) return(lnum);					/* test check sum */
			} /* switch */
		} /* if */

	} /* while */

	return( feof(fp) ? 0 : -1 );
}





/*-----------------------------------------------------------------------
  Command line analysis
-----------------------------------------------------------------------*/


int load_commands (int argc, char **argv)
{
	char *cp, *sp, *cmdlst[20], cmdbuff[256], filename[256], *dmy;
	int cmd;
	long ln;
	FILE *fp;


	memset(CodeBuff, 0xFF, sizeof(CodeBuff));
	cmd = 0; cp = cmdbuff;

	/* Import ini file as command line parameters */
	if((fp = fopen(INIFILE, "rt")) == NULL) {
		if(SearchPath(NULL, INIFILE, NULL, sizeof(filename), filename, &dmy))
			fp = fopen(filename, "rt");
	}
	if(fp != NULL) {
		while(fgets(cp, cmdbuff + sizeof(cmdbuff) - cp, fp) != NULL) {
			if(cmd >= (sizeof(cmdlst) / sizeof(cmdlst[0]) - 1)) break;
			if(*cp <= ' ') break;
			cmdlst[cmd++] = cp;
			for(sp = cp; *sp > ' '; sp++);
			*sp = '\0'; cp = sp + 1;
		}
		fclose(fp);
	}

	/* Get command line parameters */
	while(--argc && (cmd < (sizeof(cmdlst) / sizeof(cmdlst[0]) - 1)))
		cmdlst[cmd++] = *++argv;
	cmdlst[cmd] = NULL;

	/* Analyze command line parameters... */
	for(cmd = 0; cmdlst[cmd] != NULL; cmd++) {
		cp = cmdlst[cmd];

		if(strstr(cp, "-port=") == cp) {	/* COM port */
			strcpy(PortNum, cp+6);
			continue;
		}
		if(strstr(cp, "-bps=") == cp) {	/* speed */
			dcb.BaudRate = atoi(cp+5);
			continue;
		}
		if(strstr(cp, "-memsize=") == cp) {	/* memory size */
			FlashSize = atoi(cp+9);
			if(FlashSize != 8192 && FlashSize != 4096 && FlashSize != 2048 && FlashSize != 1024) return 1;
			continue;
		}
		if(strstr(cp, "-") == cp) {	/* invalid command */
			printf("\"%s\" is an invalid command.\n", cp);
			return 5;
		} else {						/* program binary */
			printf("Loading \"%s\"...", cp);
			if((fp = fopen(cp, "rt")) == NULL) {
				printf("Unable to open \"%s\".\n", cp);
				return 1;
			}
			ln = input_hexfile(fp, CodeBuff, sizeof(CodeBuff), &CodeSize);
			fclose(fp);
			if(ln) {
				if(ln < 0) {
					printf("File access failure.\n", cp);
				} else {
					printf("%s (%ld) : Hex format error.\n", cp, ln);
				}
				return 1;
			}
			printf("OK\n");
			continue;
		}

	} /* for */

	if(CodeSize) return 0;

	return 5;
}



/*-----------------------------------------------------------------------
  Program code
-----------------------------------------------------------------------*/



BOOL send_cmd(const BYTE* buff, DWORD cnt)
{
	DWORD tc;
	BYTE rets[4];
	

	WriteFile(hComm, buff, cnt, &tc, NULL);
	ReadFile(hComm, rets, cnt, &tc, NULL);
	if(tc != cnt) return FALSE;
	if(memcmp(buff, rets, cnt)) return FALSE;

	return TRUE;
}



BYTE rcvr_resp()
{
	DWORD cnt;
	BYTE rv = 0;


	ReadFile(hComm, &rv, 1, &cnt, NULL);
	return rv;
}




int boot()
{
	BYTE buff[4], ret;


	fputs("Turn-ON target power and type any key...", stdout);
	_getch();
	fputs("\nEntering programming mode...", stdout);

	// �v���O���~���O���[�h�ɓ���
	PurgeComm(hComm, PURGE_RXCLEAR);
	EscapeCommFunction(hComm, SETRTS);	// DGCLK = L
	EscapeCommFunction(hComm, CLRRTS);	// DGCLK = H
	send_cmd("\x55", 1);				// Apply 5 neg-pulses to DGDATA
	Sleep(20);
	EscapeCommFunction(hComm, CLRDTR);	// ���Z�b�g�����E�N���b�N�����J�n
	Sleep(100);

	// ���[�h�m�F (�����R�}���h�𑗂���0x01���Ԃ邩�ǂ���)
	buff[0] = buff[1] = buff[2] = buff[3] = 0x00;
	if (send_cmd(buff, 4)) {
		ret = rcvr_resp();
	} else {
		ret = 0;
	}

	if (ret == 0x01) {
		fputs("OK", stdout);
		return 0;
	} else {
		fputs("Failed", stdout);
		return 1;
	}
}



int erase()
{
	BYTE c_era[4], res;
	BYTE max_page = (BYTE)((FlashSize - 1) >> 8);
	int n, v = 0;


	fputs("\nChip erase...", stdout);
	// �`�b�v�������s
	c_era[2] = 0; c_era[3] = 0xFF;
	for (n = 256; n; n--) {
		c_era[0] = 0x20;
		c_era[1] = max_page;
		if (!send_cmd(c_era, 4)) break;
		if (rcvr_resp() != 0x06) break;
		res = rcvr_resp();
		if (res != 0x06) break;
		c_era[0] = 0x30;
		if (!send_cmd(c_era, 4)) break;
		if (rcvr_resp() != 0x06) break;
		res = rcvr_resp();
		if (res == 0x1A) continue;
		if (res != 0x06) break;
		c_era[1] = 0x80;
		if (!send_cmd(c_era, 4)) break;
		if (rcvr_resp() != 0x06) break;
		res = rcvr_resp();
		if (res == 0x1A) continue;
		if (res == 0x06) { v = 1; break; }
	}

	if (v) {
		fputs("OK", stdout);
		return 0;
	} else {
		fputs("Failed", stdout);
		return 1;
	}

}



int program()
{
	BYTE c_prg[4];
	BYTE max_page = (BYTE)((CodeSize+255) >> 8);
	int n, ofs;


	fputs("\nWriting", stdout);
	c_prg[2] = 0; c_prg[3] = 0xFF;

	for (n = 0; n < max_page; n++) {
		fputs(".", stdout);
		c_prg[0] = 0x40;
		c_prg[1] = n;
		if (!send_cmd(c_prg, 4)) break;
		if (rcvr_resp() != 0x06) break;
		for (ofs = 0; ofs < 256; ofs++) {
			send_cmd(&CodeBuff[n*256+ofs], 1);
			rcvr_resp();
		}
		if (rcvr_resp() != 0x06) break;
		c_prg[0] = 0x19;
		if (!send_cmd(c_prg, 4)) break;
		if (rcvr_resp() != 0x06) break;
		if (rcvr_resp() != 0x06) break;
	}

	if (n == max_page) {
		fputs("OK", stdout);
		return 0;
	} else {
		fputs("Failed", stdout);
		return 1;
	}
}




/*-----------------------------------------------------------------------
  Main
-----------------------------------------------------------------------*/


int main (int argc, char **argv)
{
	int rc;


	if(rc = load_commands(argc, argv)) { 
		if(rc == 5) output_usage();
		goto exit;
	}

	hComm = CreateFile(PortNum, GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if(hComm == INVALID_HANDLE_VALUE) {
		fprintf(stderr, "%s could not be opened.\n", PortNum);
		goto exit;
	}
	SetCommState(hComm, &dcb);
	SetCommTimeouts(hComm, &commtimeouts1);

	if(rc = boot()) goto exit;
	if(rc = erase()) goto exit;
	if(rc = program()) goto exit;

exit:
	printf("\nTurn-OFF target power and type any key...");
	_getch();
	if(hComm != INVALID_HANDLE_VALUE) CloseHandle(hComm);

	return rc;
}

