#!/usr/bin/perl
#
# Multiple language BBS  R0.27a  (C)ChaN, 2004
#


$CookieSign = 'multielm';		# Cookie signature
$Uri = './multi.pl';			# URI to link it self
$DataDir = './msgs';			# Message directory (must be exist)
$DataExt = '.txt';				# Message data extension
$HdHtmlSrc = './header1.';		# Html header
$HdListView = './header2.';		# Listing page header
$FtPostForm = './footer.';		# Posting form description
$MesFile = './messages.';		# Any other message strings
								# * Extension is given by query string 'lang='.
								# In default, 'en' is selected automaticaly.

$MaxTxtLen = 4000;				# Maximum size of text
$MaxTxtWidth = 100;				# Maximum line length
$MaxSubLen = 50;				# Maximum size of subject
$MaxNamLen = 40;				# Maximum size of name and country
$ListItems = 80;				# Number of items per page
$ListItemsExt = 15;				# Number of items per page (extended list)

$Ver = 'R0.27a';				# Version string
@TimeZone = (+9,'JST');			# Time zone

@Month = qw(Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec);
@Dayw = qw(Sunday Monday Tuesday Wednesday Thursday Friday Saturday);

require 'jcode.pl';		# This is required when support Japanese codes.


# Main process

	&get_parms;			# Get cookie, query string and posted message.
	&init_resource;		# Initialize multi-language strings.

	if ($cmd{'show'} ne '') {
		&show_msg;					# Show specified message in verbose mode
	}
	elsif ($cmd{'bulk'} eq 'new') {
		&show_new;					# Read new messages in plane text
	}
	elsif ($cmd{'bulk'} ne '') {
		&show_texts;				# Read messages in plane text
	}
	elsif ($cmd{'html'} ne '') {
		&show_msgs;					# Read messages in html
	}
	elsif ($cmd{'post'} ne '') {
		&post_form;					# Show posting form
	}
	elsif ($cmd{'write'} ne '') {
		&write_msg;					# Write!
		&show_list;
	}
	else {
		&show_list;					# Show message list
	}
	exit;



# Write a message from posting form
sub write_msg {

	$addr = $ENV{'REMOTE_ADDR'};
	$host = gethostbyaddr(pack('C4',split(/\./,$addr)),2);
	if ($host eq '') {
		$host = $addr;
	} else {
		$host .= " [$addr]";
	}

	&lock;
	&scan_message;

	$mesr = $cmd{'rep'} * 1;	# Reply to
	$mesp = $msg_max + 1;		# Post as

	$cmd{'sub'} =~ s/ +$//;
	if (!($cmd{'sub'} =~ /\S/)) { &werror($mess[22], $mess[19]); }
	if (!($cmd{'txt'} =~ /\S/)) { &werror($mess[22], $mess[19]); }
	if (!($cmd{'un'} =~ /\S/)) { &werror($mess[21], $mess[19]); }
	if (!($cmd{'um'} =~ /^[-\w.]+@[-\w]+\.[-\w]+/)) { &werror($mess[20], $mess[19]); }
	if ($cmd{'txt'} =~ /[^\201-\237\340-\374][\240-\337]|^[\240-\337]/) { &werror($mess[28], $mess[19]); }
	if ($cmd{'un'} =~ /[^\201-\237\340-\374][\240-\337]|^[\240-\337]/) { &werror($mess[28], $mess[19]); }
	if ($cmd{'sub'} =~ /[^\201-\237\340-\374][\240-\337]|^[\240-\337]/) { &werror($mess[28], $mess[19]); }
	if (length($cmd{'txt'}) > $MaxTxtLen) { &werror($mess[26], $mess[19]); }
	if (length($cmd{'un'}) > $MaxNamLen) { &werror($mess[7], $mess[19]); }
	if (length($cmd{'uc'}) > $MaxNamLen) { &werror($mess[7], $mess[19]); }
	if (length($cmd{'sub'}) > $MaxSubLen) { &werror($mess[8], $mess[19]); }
	@txt = split(/\002/, $cmd{'txt'});
	foreach (@txt) {
		if (length($_) > $MaxTxtWidth) { &werror($mess[26], $mess[19]); }
	}
	for ($mes = $msg_max ; $mes > ($msg_max-4) ; $mes-- ) {
		if (&get_msgcontent($mes, *ct)) {
			if ($cmd{'txt'} eq $ct{'TEXT'}) { &werror($mess[25], $mess[19]); }
		}
	}

	if ($mesr > 0) {
		if (!&get_msgcontent($mesr, *ct)) { &werror($mess[23], $mess[19]); }
		$ct{'CHILD'} .= " $mesp"; $ct{'CHILD'} =~ s/^ //;
		if (!open(WHA, '> '.sprintf("$DataDir/m%04d$DataExt", $mesr))) { &werror($mess[24], $mess[19]); }
		if ($ct{'PARENT'} ne '') { print WHA "PARENT\t$ct{'PARENT'}\n"; }
		print WHA "CHILD\t$ct{'CHILD'}\n";
		print WHA "SUBJECT\t$ct{'SUBJECT'}\n";
		print WHA "DATE\t$ct{'DATE'}\n";
		print WHA "NAME\t$ct{'NAME'}\n";
		print WHA "MAIL\t$ct{'MAIL'}\n";
		if ($ct{'COUNTRY'} ne '') { print WHA "COUNTRY\t$ct{'COUNTRY'}\n"; }
		print WHA "HOST\t$ct{'HOST'}\n";
		print WHA "TEXT\t$ct{'TEXT'}\n";
		close(WHA);
	}

	$mespf = sprintf("$DataDir/m%04d$DataExt", $mesp);
	if (!open(WHA, "> $mespf")) { &werror($mess[25], $mess[19]); }
	if ($mesr > 0) { print WHA "PARENT\t$mesr\n"; }
	print WHA "SUBJECT\t$cmd{'sub'}\n";
	print WHA "DATE\t".time."\n";
	print WHA "NAME\t$cmd{'un'}\n";
	print WHA "MAIL\t$cmd{'um'}\n";
	if ($cmd{'uc'} ne '') { print WHA "COUNTRY\t$cmd{'uc'}\n"; }
	print WHA "HOST\t$host\n";
	print WHA "TEXT\t$cmd{'txt'}\n";
	close(WHA);
	chmod (0666, $mespf);

	unlink('exclude');
}



# Show post form
sub post_form {
	print "Content-Type: text/html; charset=$mess[0]\n\n";
	&put_filetext($HdHtmlSrc.$lng);

	$mes = sprintf('%04d', $cmd{'post'});

	print "<form action=\"$Uri\" method=\"post\">\n";
	print  "<table id=\"bptbl\"><tr><td colspan=\"2\" id=\"dh\">\n";
	if ($mes > 0) {
		if(&get_msgcontent($mes, *ct)) {
			print sprintf("$mess[14]<br><br>\n", sprintf("#%s <em>$ct{'SUBJECT'}</em> by $ct{'NAME'}", $mes));
			@txt = split(/\002/, $ct{'TEXT'});
			print "<span class=\"qu\">"; foreach (@txt) { print "$_<br>"; } print "</span>\n";
		} else {
			print "<strong>Message #$mes has been lost or an error occured.<br>This will be posted as a new message.<br></strong>\n";
			$cmd{'post'} = 0;
		}
	} else {
		print "<em>$mess[13]</em>\n";
	}
	print	"</td></tr>\n";
	print	"<tr><td class=\"dc\"><span>*</span>Your (nick)name: </td><td><input type=\"text\" size=\"50\" maxlength=\"$MaxNamLen\" name=\"un\" value=\"$cmd{'un'}\"></tr>\n";
	print   "<tr><td class=\"dc\"><span>*</span>E-mail: </td><td><input type=\"text\" size=\"50\" maxlength=\"$MaxNamLen\" name=\"um\" value=\"$cmd{'um'}\"></td></tr>\n";
	print   "<tr><td class=\"dc\">Country:</td><td><input type=\"text\" size=\"30\" maxlength=\"30\" name=\"uc\" value=\"$cmd{'uc'}\"></td></tr>\n";
	print   "<tr><td class=\"dc\"><span>*</span>Subject: </td><td><input type=\"text\" size=\"80\" maxlength=\"$MaxSubLen\" name=\"sub\"></td></tr>\n";
	print   "<tr><td class=\"dc\"><span>*</span>Text: </td><td><textarea cols=\"80\" rows=\"15\" wrap=\"off\" name=\"txt\"></textarea></td></tr>\n";
	print  "</table>";
	print  "<input type=\"hidden\" name=\"lang\" value=\"$lng\"><input type=\"hidden\" name=\"rep\" value=\"$mes\"><input type=\"submit\" name=\"write\" value=\"$mess[16]\"><br>\n";
	print "</form>\n";

	&put_filetext($FtPostForm.$lng);

	print sprintf("$mess[1]\n", $Ver);
}



# Show message list
sub show_list {

	&scan_message;

	$rp2 = $cmd{'rp'};
	if(($cmd{'vm'} & 2) == 2) { $rp2 = $msg_max; }

	if($cmd{'ss'}) {
		print "Set-Cookie: $CookieSign=vm\:$cmd{'vm'}\,rp\:$rp2\,un\:$un\,um\:$um\,uc\:$uc\,lang\:$lng\,ss\:1; expires=$CookieExp\n";
	} else {
		print "Set-Cookie: $CookieSign=ss:0;\n";
	}
	print "Content-Type: text/html; charset=$mess[0]\n\n";

	&put_filetext($HdHtmlSrc.$lng);
	&put_filetext($HdListView.$lng);

	@vm = ();  $vm[$cmd{'vm'}] = ' selected="1"';
	$ss = '';  if($cmd{'ss'}) { $ss = 'checked="checked"'; }
	$rp1 = $msg_min; $rp2 = $msg_max;
	if($cmd{'rp'} >= $rp1) { $rp1 = $cmd{'rp'}+1; }
	if (($rp1 > $msg_max) || ($cmd{'ss'} == 0)) { undef $rp1; undef $rp2; }


	print "<div id=\"blfm1\">\n";
	print "<form action=\"$Uri\" method=\"post\">\n";
	print "$mess[27] <select name=\"vm\">\n";
	print "<option value=\"0\"$vm[0]>$mess[3]</option><option value=\"1\"$vm[1]>$mess[4]</option><option value=\"2\"$vm[2]>$mess[5]</option><option value=\"3\"$vm[3]>$mess[6]</option>\n";
	print "</select>\n";
	print " <label><input type=\"checkbox\" name=\"ss\" value=\"2\" $ss> <small>$mess[10]</small></label>\n";
	print " <input type=\"submit\" name=\"lst\" value=\"$mess[9]\">\n";
	print " <input type=\"hidden\" name=\"lang\" value=\"$lng\">\n";
	print "</form>\n";
	print "<form action=\"$Uri\" method=\"post\">$mess[11] <input type=\"text\" size=\"5\" maxlength=\"5\" name=\"from\" value=\"$rp1\">-<input type=\"text\" size=\"5\" maxlength=\"5\" name=\"to\" value=\"$rp2\">";
	print " <input type=\"hidden\" name=\"lang\" value=\"$lng\"><input type=\"submit\" name=\"html\" value=\"$mess[29]\"><input type=\"submit\" name=\"bulk\" value=\"$mess[12]\">\n";
	print "</form>\n";
	print "</div>\n";

	print "<div id=\"blfm2\">\n";
	print "<form id=\"fm3\" action=\"$Uri\" method=\"post\">\n";
	if ($nmsg) {
		print   "$mess[17] $nmsg [#$msg_min-#$msg_max]<br>\n";
	} else {
		print "No message.<br>\n";
	}
	print "<input type=\"submit\" name=\"post\" value=\"$mess[2]\">\n";
	print "<input type=\"hidden\" name=\"lang\" value=\"$lng\">\n";
	print "</form>\n";
	print "</div>\n";


	if($cmd{'lp'} >= 999) {
		if(opendir(DIR, './')) {
			print "<br>\n";
			@files = reverse(sort(readdir(DIR))); closedir(DIR);
			foreach (@files) {
				if(/(\d{4}-\d{4})\.txt/) {
					print "<a href=\"$1.txt\">#$1</a><br>\n";
				}
			}
		}
		print "<br>\n";


	} else {

		if($cmd{'vm'} & 2) { $ListItems = $ListItemsExt; }
		$disp_s = $cmd{'lp'} * $ListItems;
		$disp_e = $disp_s + $ListItems - 1;

		if(($cmd{'vm'} != 1)&&($cmd{'exp'} ne '')) { print "<a id=\"EXP\"></a>$mess[31]<br>\n"; }

		print "<ul class=\"blst\">";
		if($cmd{'vm'} & 1) {
			$Layer = 1; @shown = ();
			for ($msg = $msg_max ; ($msg >= $msg_min)&&($disp_n <= $disp_e) ; $msg-- ) {
				if(!$shown[$msg-$msg_min]) { &link_item($msg); }
			}
		} else {
			for ($msg = $msg_max ; ($msg >= $msg_min)&&($disp_n <= $disp_e) ; $msg-- ) {
				if(&get_msgcontent($msg,*ct)) {
					if(($disp_n >= $disp_s) && ($disp_n <= $disp_e)) { &put_item(*ct, $msg); }
					$disp_n++;
				}
			}
		}
		print "</ul>\n";
	}


	print "<br><p id=\"bplst\">Page:";
	for ($pg = 0; $pg <= $nmsg / $ListItems ; $pg++) {
		$pg2 = $pg + 1;
		if ($pg == $cmd{'lp'}) {
			print " <span>[$pg2]</span>";
		} else {
			print " <a href=\"$Uri\?lang=$lng\&amp;lp=$pg\">[$pg2]</a>";
		}
	}
	if ($cmd{'lp'} >= 999) {
		print " <span>[archive]</span></p>\n";
	} else {
		print " <a href=\"$Uri\?lang=$lng\&amp;lp=999\">[archive]</a></p>\n";
	}

	print sprintf("$mess[1]\n</body></html>\n", $Ver);
}


# Put a list item with tracing reply links
sub link_item {
	local($msg) = @_;
	local(%ct,@fl,$n,$vm);

	$shown[$msg-$msg_min] = 1;
	if(!&get_msgcontent($msg,*ct)) { return; }
	if(($ct{'PARENT'} ne '') && ($Layer == 1)) { return; }

	$vm = $cmd{'vm'};
	if($msg == $cmd{'exp'}) {
		$cmd{'vm'} |= 2;
	}

	if($Layer == 1) {
		if(($disp_n >= $disp_s) && ($disp_n <= $disp_e)) {
			$disp_f = 1; &put_item(*ct, $msg);
		} else {
			$disp_f = 0;
		}
	} else {
		if($disp_f) { &put_item(*ct, $msg); }
	}
	$disp_n++;

	if($ct{'CHILD'} ne '') {
		@fl = split(/ /,$ct{'CHILD'});
		$Layer++; print "<ul class=\"blst\">";
		foreach (@fl) { &link_item( $_ ); }		# recursive call
		$Layer--; print "</ul>\n";
	}

	$cmd{'vm'} = $vm;
}


# Put a list item
sub put_item {
	local(*ct, $msg) = @_;

	$ct{'SUBJECT'} =~ s/&/&amp;/g;
	$ct{'SUBJECT'} =~ s/&amp;#/&#/g;
	$ct{'SUBJECT'} =~ s/</&lt;/g;
	$ct{'NAME'} =~ s/&/&amp;/g;
	$ct{'NAME'} =~ s/&amp;#/&#/g;
	$ct{'NAME'} =~ s/</&lt;/g;
	$ct{'COUNTRY'} =~ s/&/&amp;/g;
	$ct{'COUNTRY'} =~ s/&amp;#/&#/g;
	$ct{'COUNTRY'} =~ s/</&lt;/g;

	if($cmd{'vm'} & 6) { print "<hr>\n"; }

	if($msg == $cmd{'exp'}) {
		print "<a id=\"EXP\"></a>\n";
	}

	if($cmd{'vm'} & 1) {
		print "<li class=\"blsts\"><a class=\"sub\" href=\"$Uri\?lang=$lng\&amp;show=$msg\">$ct{'SUBJECT'}</a>";
		if(($msg > $cmd{'rp'})&& $cmd{'ss'}) { print " <span class=\"blnew\">New</span>"; }
		if(($cmd{'vm'} == 1)&&($ct{'CHILD'} ne '')) { $lp = $cmd{'lp'} * 1; print " <a href=\"$Uri\?lang=$lng\&amp;lp=$lp\&amp;exp=$msg#EXP\">$mess[30]</a>"; }
	} else {
		print sprintf("<li class=\"blstn\"><span class=\"num\">#%04d ",$ct{'NUM'});
		if($ct{'PARENT'} != 0) { print sprintf('Re:%04d ', $ct{'PARENT'}); }
		print "</span><a class=\"sub\" href=\"$Uri\?lang=$lng\&amp;show=$msg\">$ct{'SUBJECT'}</a>";
		if(($msg > $cmd{'rp'})&& $cmd{'ss'}) { print " <span class=\"blnew\">New!</span>"; }
	}

	if($cmd{'vm'} & 2) {
		print " by <span class=\"nam\">$ct{'NAME'}</span>";
		print " <span class=\"date\">$ct{'DATED'},  $ct{'DATET'} [<a href=\"$Uri\?lang=$lng\&amp;post=$msg\">Reply to this</a>]</span>\n<br>\n<pre>";
		@txt = split(/\002/, $ct{'TEXT'});
		foreach (@txt) { &put_line($_); }
		print "</pre></li>\n";
	} else {
		print " by <span class=\"nam\">$ct{'NAME'}</span> <span class=\"date\">$ct{'DATED'},  $ct{'DATET'}</span></li>\n";
	}
}


# Show a message in html mode
sub show_msg {
	local(@txt, $m);
	$msg = sprintf("%04d", $cmd{'show'});

	if(!&get_msgcontent($msg,*ct)) { &werror("Requested message #$msg is absent. It may be in the archive.<br>\n"); }

	if($cmd{'rp'} < $msg) { $cmd{'rp'} = $msg; }
	if($cmd{'ss'}) {
		print "Set-Cookie: $CookieSign=vm\:$cmd{'vm'}\,rp\:$cmd{'rp'}\,un\:$un\,um\:$um\,uc\:$uc\,lang\:$lng\,ss\:1; expires=$CookieExp\n";
	} else {
		print "Set-Cookie: $CookieSign=ss:0;\n";
	}
	print "Content-Type: text/html; charset=$mess[0]\n\n";
	&put_filetext($HdHtmlSrc.$lng);
	put_html(*ct);
	print "<p id=\"bret\"><a href=\"$Uri\?lang=$lng\">Return</a></p>\n";
	print sprintf("$mess[1]\n</body></html>\n", $Ver);
}


# Show multiple messages in html mode
sub show_msgs {

	&scan_message;
	if($cmd{'from'} > $cmd{'to'}) { $cmd{'to'} = $cmd{'from'} }
	if($cmd{'from'} < $msg_min) { $cmd{'from'} = $msg_min; }
	if($cmd{'from'} > $msg_max) { $cmd{'from'} = $msg_max; }
	if($cmd{'to'} < $msg_min) { $cmd{'to'} = $msg_min; }
	if($cmd{'to'} > $msg_max) { $cmd{'to'} = $msg_max; }

	if($cmd{'rp'} < $cmd{'to'}) { $cmd{'rp'} = $cmd{'to'}; }
	if($cmd{'ss'}) {
		print "Set-Cookie: $CookieSign=vm\:$cmd{'vm'}\,rp\:$cmd{'rp'}\,un\:$un\,um\:$um\,uc\:$uc\,lang\:$lng\,ss\:1; expires=$CookieExp\n";
	} else {
		print "Set-Cookie: $CookieSign=ss:0;\n";
	}

	print "Content-Type: text/html; charset=$mess[0]\n\n";

	&put_filetext($HdHtmlSrc.$lng);
	for ($msg = $cmd{'from'} ; $msg <= $cmd{'to'} ; $msg++ ) {
		if(&get_msgcontent($msg,*ct)) { &put_html(*ct); print "<br>\n";}
	}
	print "<p id=\"bret\"><a href=\"$Uri\?lang=$lng\">Return</a></p>\n";
	print sprintf("$mess[1]\n</body></html>\n", $Ver);
}


# Put a message in html mode
sub put_html {
	local(*ct) = @_;

	$ct{'SUBJECT'} =~ s/&/&amp;/g;
	$ct{'SUBJECT'} =~ s/&amp;#/&#/g;
	$ct{'SUBJECT'} =~ s/</&lt;/g;
	$ct{'NAME'} =~ s/&/&amp;/g;
	$ct{'NAME'} =~ s/&amp;#/&#/g;
	$ct{'NAME'} =~ s/</&lt;/g;
	$ct{'COUNTRY'} =~ s/&/&amp;/g;
	$ct{'COUNTRY'} =~ s/&amp;#/&#/g;
	$ct{'COUNTRY'} =~ s/</&lt;/g;

	print "<div class=\"bmes\">\n";
	print "<p class=\"bmhd\">\n";
	print "<span class=\"bmtm\">$ct{'DATED'}, $ct{'DATET'}<br></span>\n";
	print "<span class=\"bmtl\"><span class=\"numb\">#$msg:</span> <span class=\"subj\">$ct{'SUBJECT'}</span><br></span>\n";
	print "<span class=\"bmnm\"><span class=\"numb\">Name:</span> <a href=\"mailto:$ct{'MAIL'}\">$ct{'NAME'}</a>";
	if ($ct{'COUNTRY'} ne '') { print " <span class=\"numb\">\@$ct{'COUNTRY'}</span>"; }
	print "<br></span><!-- $ct{'HOST'} -->\n";
	print "<span class=\"bmlk\">";
	if ($ct{'PARENT'} ne '') {
		print "<span class=\"numb\">Parent:</span> <a href=\"$Uri\?lang=$lng\&amp;show=$ct{'PARENT'}\">#".sprintf('%04d', $ct{'PARENT'}).'</a>';
	}
	if ($ct{'CHILD'} ne '') {
		if ($ct{'PARENT'} ne '') { print ' | '; }
		print '<span class="numb">Child:</span>';
		@txt = split(/ /, $ct{'CHILD'});
		foreach (@txt) { print " <a href=\"$Uri\?lang=$lng\&amp;show=$_\">#".sprintf('%04d', $_).'</a>'; }
	}
	print "</span>\n</p>\n";
	print "<p class=\"bmtx\"><pre>\n";
	@txt = split(/\002/,$ct{'TEXT'});
	foreach (@txt) { &put_line($_); }
	print "</pre></p>\n";
	print "<p class=\"bmrp\"><a href=\"$Uri\?lang=$lng\&amp;post=$msg\">Reply to this</a></p><br>\n";
	print "</div>\n";

}


# Check if the line has a URL and put the line
sub put_line {
	local($_) = @_;

    if(/^>/) {
		s/&/&amp;/g; s/&amp;#/&#/g; s/</&lt;/g; s/>/&gt;/g;
		print "<span class=\"qu\">$_</span>\n";
		return;
    }
	if(/^$|^\W|\.$|\.\.|:[^\/]|^[^\.]+$|[ \!\"\$\'\(\)\*\,\;\<\>\@\[\\\]\^\{\|\}\177-\377]/) {
		s/&/&amp;/g; s/&amp;#/&#/g; s/</&lt;/g; s/>/&gt;/g;
		print "$_\n";
		return;
	}
	s/&/&amp;/g; s/&amp;#/&#/g; s/</&lt;/g; s/>/&gt;/g;
	if(/^\w+:\/\//) { print "<a href=\"$_\">$_</a>\n"; return; }
	print "<a href=\"http://$_\">$_</a>\n"; return;
}


# Show new messages in plane text mode
sub show_new {

	&scan_message;
	if($cmd{'ss'}) {
		print "Set-Cookie: $CookieSign=vm\:$cmd{'vm'}\,rp\:$msg_max\,un\:$un\,um\:$um\,uc\:$uc\,lang\:$lng\,ss\:1; expires=$CookieExp\n";
	} else {
		&deny;
	}
	print "Content-Type: text/plain; charset=$mess[0]\n\n";

	if($msg_max > $cmd{'rp'}) {
		for ($msg = $cmd{'rp'}+1 ; $msg <= $msg_max ; $msg++ ) {
			if(&get_msgcontent($msg,*ct)) { &put_text(*ct); }
		}
	} else {
		print "No new message.\n";
	}
}


# Show multiple messages in plane text mode
sub show_texts {

	&scan_message;
	if($cmd{'from'} > $cmd{'to'}) { $cmd{'to'} = $cmd{'from'} }
	if($cmd{'from'} < $msg_min) { $cmd{'from'} = $msg_min; }
	if($cmd{'from'} > $msg_max) { $cmd{'from'} = $msg_max; }
	if($cmd{'to'} < $msg_min) { $cmd{'to'} = $msg_min; }
	if($cmd{'to'} > $msg_max) { $cmd{'to'} = $msg_max; }

	if($cmd{'rp'} < $cmd{'to'}) { $cmd{'rp'} = $cmd{'to'}; }
	if($cmd{'ss'}) {
		print "Set-Cookie: $CookieSign=vm\:$cmd{'vm'}\,rp\:$cmd{'rp'}\,un\:$un\,um\:$um\,uc\:$uc\,lang\:$lng\,ss\:1; expires=$CookieExp\n";
	} else {
		print "Set-Cookie: $CookieSign=ss:0;\n";
	}

	print "Content-Type: text/plain; charset=$mess[0]\n\n";

	for ($msg = $cmd{'from'} ; $msg <= $cmd{'to'} ; $msg++ ) {
		if(&get_msgcontent($msg,*ct)) { &put_text(*ct); }
	}
}


# Put a message in plane text mode
sub put_text {
	local(*ct) = @_;

	print sprintf('#%04d    ',$ct{'NUM'}).$ct{'DATED'}.', '.$ct{'DATET'}."\n";
	print "Subject: $ct{'SUBJECT'}\n";
	print "Name: $ct{'NAME'} [$ct{'MAIL'}]\n";
	if ($ct{'COUNTRY'} ne '') { print "Country: $ct{'COUNTRY'}\n"; }
	if ($ct{'PARENT'} ne '') { print sprintf('Parent: #%04d', $ct{'PARENT'})."\n"; }
	if ($ct{'CHILD'} ne '') {
		print "Child:"; @txt = split(/ /, $ct{'CHILD'});
		foreach (@txt) { print sprintf(' #%04d', $_); }
		print "\n";
	}
	print "Text:\n";
	@txt = split(/\002/, $ct{'TEXT'});
	foreach (@txt) { print "$_\n"; }
	print "\n\n\n";
}



# Send a text file
sub put_filetext {
	if(open(RHA, $_[0])) {
		while (<RHA>) { chop; print "$_\n"; }
		close(RHA);
	}
}



# Scan messages. Get minimum number, maximum number and number of messages
sub scan_message {
	$msg_min = 9999; $msg_max = 0; $nmsg = 0;
	if(!opendir(DIR, $DataDir)) { &werror($mess[32]); }
	@files = readdir(DIR); closedir(DIR);
	foreach (@files) {
		if(/^m(\d{4})$DataExt$/) {
			$nmsg++;
			if($msg_min > $1) { $msg_min = $1 * 1; }
			if($msg_max < $1) { $msg_max = $1 * 1; }
		}
	}
}


# Get message content
sub get_msgcontent {
	local($msg, *ct) = @_;	# Message number, pointer to content table
	local($txt);

	%ct = ();
	if(!open(RHA, sprintf("$DataDir/m%04d$DataExt",$msg))) { return(0); }

	$ct{'NUM'} = $msg;
	while (<RHA>) {
		chop; ($key, $txt) = split(/\t/);
		$ct{$key} = $txt;
	}
	close(RHA);

	# Create Date and Time from UTC
	@dt = gmtime($ct{'DATE'}+$TimeZone[0]*3600);
	$ct{'DATED'} = sprintf('%2d/%02d/%04d', $dt[4]+1, $dt[3], $dt[5]+1900);
	$ct{'DATET'} = sprintf('%2d:%02d %s', $dt[2], $dt[1], $TimeZone[1]);

	# Invalidate mail address
	$ct{'MAIL'} =~ s/\@/ at /g;
	$ct{'MAIL'} =~ s/\./ /g;

	return(1);
}


# Get parameters from client
sub get_parms {
	($secg,$ming,$hourg,$mdayg,$mong,$yearg,$wdayg,$ydayg,$isdstg) = gmtime(time + 30*24*60*60);
	$CookieExp = sprintf("%s\, %02d\-%s\-%04d %02d:%02d:%02d GMT",$Dayw[$wdayg],$mdayg,$Month[$mong],$yearg +1900,$hourg,$ming,$secg);

	@cmds = split(/;/, $ENV{'HTTP_COOKIE'});	# Get cookie parameters
	foreach (@cmds) {
		s/^ //g;
		($key, $value) = split(/=/);
		$tmp{$key} = $value;
	}
	@cmds = split(/,/, $tmp{$CookieSign});
	foreach (@cmds) {
		($key, $value) = split(/:/);
		$value =~ s/%([0-9A-Fa-f]{2})/pack('H2', $1)/eg;
		$cmd{$key} = $value;
	}

	@cmds = split('&', $ENV{'QUERY_STRING'});	# Get query parameters
	foreach (@cmds) {
		($key, $value) = split(/=/);
		$value =~ s/\+/ /g;
		$value =~ s/%([0-9A-Fa-f]{2})/pack('H2', $1)/eg;
		$cmd{$key} = $value;
	}

	read(STDIN, $buffer, $ENV{'CONTENT_LENGTH'});	# Get posted parameters
	@cmds = split(/&/,$buffer);
	foreach (@cmds) {
		($key, $value) = split(/=/);
		$value =~ s/\+/ /g;
		$value =~ s/%([0-9A-Fa-f]{2})/pack('H2',$1)/eg;
		$value =~ s/\t/ /g;
		&jcode'convert(*value,'sjis');
		$value =~ s/\r\n/\002/g;
		$value =~ s/\n/\002/g;
		$value =~ s/\r/\002/g;
		$cmd{$key} = $value;
	}

	if(($cmd{'lst'} ne '') && ($cmd{'ss'} != 2)) { $cmd{'ss'} = 0; }

	$un = $cmd{'un'}; $un =~ s/\W/'%'.unpack('H2',$&)/ge;
	$um = $cmd{'um'}; $um =~ s/\W/'%'.unpack('H2',$&)/ge;
	$uc = $cmd{'uc'}; $uc =~ s/\W/'%'.unpack('H2',$&)/ge;
	$lng = $cmd{'lang'}; if(!($lng =~ /^[a-z][a-z]$/)) { $lng = 'en'; }

}


# Initialize multi-language resource
sub init_resource {

	if (!open(RHA, $MesFile.$lng)) {
		$lng = 'en';
		if (!open(RHA, $MesFile.$lng)) {
			print "Content-Type: text/plain; charset=$mess[0]\n\n";
			print "Resource file $MesFile$lng is not found.\n";
			exit;
		}
	}
	while (<RHA>) { chop; push(@mess, $_); }
	close(RHA);

}


# Show error message and abort.
sub werror {
	@ms = @_;
	print "Content-Type: text/html; charset=$mess[0]\n\n";
	&put_filetext($HdHtmlSrc.$lng);
	foreach (@ms) { print "$_<br><br>\n"; }
	print "$mess[15]<br>\n";
	print sprintf("$mess[1]\n</body></html>\n", $Ver);

	unlink('exclude');
	exit;
}


# Multi access exclusion
sub lock {
	$retry = 4;
	while (!symlink('.', 'exclude')) {
		if (--$retry <= 0) {
			&werror($mess[18], $mess[19]);
		}
		sleep(2);
	}
}


# Invalid access dennial
sub deny {
		print "Content-Type: text/plain; charset=$mess[0]\n\n";
		exit;
}


