-------------------------------------------------------------------------------
                   BIN2HEX / CSV2HEX / BIN2CSV / HEX2HEX
            Universal hex file converters for embedded programming
-------------------------------------------------------------------------------

BIN2HEX converts binary file into Intel-Hex file. This is suitable for creating
a hex file from rom image.

BIN2CSV converts binary file into csv file. This is suitable for analyzing
binary data with any spread sheet, or building data table into source file.

CSV2HEX converts csv file into Intel-Hex file. This is suitable for creating
data table in hex file format. It supports only signed/unsigned integer.

HEX2HEX shifts (adds) offset address in the Intel-Hex file.


(C)ChaN, 2002
http://elm-chan.org/
