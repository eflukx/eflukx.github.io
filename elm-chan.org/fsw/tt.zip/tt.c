/*----------------------------------------------------------------------------/
/  TT - Tiny Terminal  R0.2f (C)ChaN, 2005-2012
/-----------------------------------------------------------------------------/
/ TT is a simple terminal program for embedded projects. It is a free software
/ opened under license policy of GNU GPL.

   Copyright (C) 2012, ChaN, all right reserved.

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions are met:

   * Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.

   * Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in
     the documentation and/or other materials provided with the
     distribution.

   * Neither the name of the copyright holders nor the names of
     contributors may be used to endorse or promote products derived
     from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE. 
*/


#include <windows.h>
#include <commdlg.h>
#include <winuser.h>
#include <string.h>
#include <stdio.h>
#include <ctype.h>


#define	INIFILE		"tt.ini"

#define	CMD_EXIT	1
#define	CMD_SWLOG	2
#define CMD_EROFF	3
#define CMD_BREAK	4
#define	CMD_DUMP	5
#define	CMD_TRANSMIT	6
#define	CMD_XMODEM	7
#define	CMD_STOP_TRAN	8

#define	SOH		0x01
#define	EOT		0x04
#define	ACK		0x06
#define	NAK		0x15
#define	CAN		0x18

#define	TXM_BIN		1
#define	TXM_XMODEM	2


#define TMR_HUNG	300	/* Hung-up (ER=OFF) time */
#define TMR_BREAK	300	/* Break (TD=0) time */


HANDLE hComm;								/* Comm port */
HANDLE hLog = INVALID_HANDLE_VALUE;			/* Log file */
HANDLE hTransmit = INVALID_HANDLE_VALUE;	/* Transmission file */
HANDLE hKey, hScreen, hRcvrThread;			/* Handles for Key/Screen threads */
DWORD RcvrThreadID, ExitRcvr;
int AutoXmit, FileSize, FilePtr;

char sLogFile[_MAX_PATH];
char sLogFileTitle[_MAX_PATH];
char sPort[32];
char sTitle[256];
char sOpenFile[_MAX_PATH];

int comPort = 1;
int comBps = 9600;
int comData = 8;
int comStop = ONESTOPBIT;
int comParity = NOPARITY;
BOOL comCtsflow = FALSE;
int comPol = 0;		/* Signal polarity - b0:Invert ER, b1:Invert DR, b2:Invert TD (cannot send) */
int comHelp = 1;

volatile int ComCmd;
volatile int nTxb;
volatile char Rxc, Xmode, Xseq;
char Txb[256];
BYTE Rxb[1024];

BOOL fDump = FALSE;		/* HEX dump mode */
DWORD DumpAddr;			/* Dump address */

const char Usage1[] =
	"TT - Tiny Terminal R0.2f (C)ChaN, 2012\n\n"
	"Command line parameters:\n"
	" port=1,n81,9600 : Port number, format, baud rate\n"
	" bps=9600        : Baud rate\n"
	" flow=on         : RS/CS flow control (on,off)\n"
    " pol=0           : Invert outputs (b0:ER, b1:RS, b2:TD w/o tx)\n"
	" log=<file>      : Initial log file\n"
	" *These options can also be put in the \"tt.ini\".\n\n";

const char Usage2[] =
	"Keyboard command:\n"
	" Alt-X : Exit program\n"
	" Alt-L : Toggle logging\n"
	" Alt-V : Toggle view mode, TTY and HEX\n"
	" Alt-T : Transmit a file in byte stream\n"
	" Alt-Y : Transmit a file in XMODEM\n"
	" Alt-H : Hung-up (Invert ER for 300ms)\n"
	" Alt-B : Break (Transmit a 300ms space)\n"
	;



void set_title (void)
{
	char frm[4];


	frm[0] = (comParity == ODDPARITY) ? 'O' : ((comParity == EVENPARITY) ? 'E' : 'N');
	frm[1] = comData + '0';
	frm[2] = (comStop == TWOSTOPBITS) ? '2' : '1';
	frm[3] = 0;
	sprintf(sTitle, "TinyTerminal [%s:%s:%ubps]", sPort, frm, comBps);

	if (hLog != INVALID_HANDLE_VALUE)
		sprintf(sTitle + strlen(sTitle), " - %s", sLogFileTitle);

	if (AutoXmit)
		sprintf(sTitle + strlen(sTitle), " [Send: %u%%]", 100 * FilePtr / FileSize); 

	SetConsoleTitle(sTitle);
}



void switch_logging (void)
{
	OPENFILENAME lfn;


	if (hLog != INVALID_HANDLE_VALUE) {
		CloseHandle(hLog);
		hLog = INVALID_HANDLE_VALUE;
	}
	else {
		lfn.lStructSize			= sizeof(OPENFILENAME);
		lfn.Flags				= OFN_PATHMUSTEXIST | OFN_HIDEREADONLY;
		lfn.hwndOwner			= FindWindow(NULL, sTitle);
		lfn.lpstrTitle			= "Select Logfile";
		lfn.lpstrInitialDir		= NULL;
		lfn.lpstrFilter			= "Log Files (*.txt)\0*.txt\0All Files (*.*)\0*.*\0\0";
		lfn.lpstrCustomFilter	= NULL;
		lfn.nFilterIndex		= 0;
		lfn.lpstrDefExt			= "txt";
		lfn.lpstrFile			= sLogFile;
		lfn.nMaxFile			= sizeof sLogFile;
		lfn.lpstrFileTitle		= sLogFileTitle;
		lfn.nMaxFileTitle		= sizeof sLogFileTitle;
		if (GetSaveFileName(&lfn)) {
			hLog = CreateFile(sLogFile, GENERIC_WRITE, 0, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
			if (hLog != INVALID_HANDLE_VALUE)
				SetFilePointer(hLog, 0, NULL, FILE_END);
		}
	}
	set_title();
}



void stop_transmisson (void)
{
	CloseHandle(hTransmit);
	hTransmit = INVALID_HANDLE_VALUE;
	AutoXmit = 0;
	set_title();
	MessageBeep(MB_OK);
}



int create_sum(BYTE *buf, int cnt, int mode)
{
	int n, i;
	DWORD sum = 0;

	
	if (mode == 1) {
		for (i = 0; i < cnt; i++)
			sum += buf[i];
		buf[i] = (BYTE)sum;
		cnt += 1;
	}
	if (mode == 2) {
		for (i = 0; i < cnt; i++) {
			sum |= buf[i];
			for (n = 0; n < 8; n++) {
				sum <<= 1;
				if (sum & 0x1000000) sum ^= 0x1102100;
			}
		}
		buf[i++] = (BYTE)(sum >> 16);
		buf[i++] = (BYTE)(sum >> 8);
		cnt += 2;
	}

	return cnt;
}



void start_transmisson (int mode)
{
	OPENFILENAME lfn;
	BY_HANDLE_FILE_INFORMATION finfo;


	if (!AutoXmit) {
		lfn.lStructSize			= sizeof(OPENFILENAME);
		lfn.Flags				= OFN_PATHMUSTEXIST | OFN_HIDEREADONLY;
		lfn.hwndOwner			= FindWindow(NULL, sTitle);
		lfn.lpstrTitle			= (mode == 2) ? "Transmit in XMODEM" : "Transmit in Byte Stream";
		lfn.lpstrInitialDir		= NULL;
		lfn.lpstrFilter			= "All Files (*.*)\0*.*\0\0";
		lfn.lpstrCustomFilter	= NULL;
		lfn.nFilterIndex		= 0;
		lfn.lpstrDefExt			= NULL;
		lfn.lpstrFile			= sOpenFile;
		lfn.nMaxFile			= sizeof sOpenFile;
		lfn.lpstrFileTitle		= NULL;
		lfn.nMaxFileTitle		= 0;
		if (GetOpenFileName(&lfn)) {
			hTransmit = CreateFile(sOpenFile, GENERIC_READ, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
			if (hTransmit != INVALID_HANDLE_VALUE) {
				GetFileInformationByHandle(hTransmit, &finfo);
				FileSize = finfo.nFileSizeLow;
				FilePtr = 0;
				AutoXmit = mode;
				Xmode = 0;
				set_title();
			}
		}
	}
}



DWORD WINAPI RcvrThread (LPVOID parms)
{
	BYTE dbuff[17], c, f;
	BYTE str[24];
	DWORD d, sc, i, rc;


	while (!ExitRcvr) {
		if (ComCmd == CMD_EROFF) {
			EscapeCommFunction(hComm, (comPol & 1) ? SETDTR : CLRDTR);
			Sleep(TMR_HUNG);
			EscapeCommFunction(hComm, (comPol & 1) ? CLRDTR : SETDTR);
			ComCmd = 0;
		}
		if (ComCmd == CMD_BREAK) {
			ComCmd = 0;
			if (!(comPol & 4)) {
				EscapeCommFunction(hComm, SETBREAK);
				Sleep(TMR_BREAK);
				EscapeCommFunction(hComm, CLRBREAK);
			}
		}
		if (nTxb) {
			i = nTxb;
			if (!(comPol & 4)) WriteFile(hComm, Txb, nTxb, &i, NULL);
			nTxb -= i;
			if (nTxb)
				memmove(Txb, Txb + i, nTxb);
		}
		rc = 0;
		ReadFile(hComm, Rxb, sizeof Rxb, &rc, NULL);
		if (rc == 0) continue;
		Rxc = Rxb[0];
		if (AutoXmit == TXM_XMODEM) continue;

		if (fDump) {	/* HEX dump mode */
			for (i = 0; i < rc; i++) {
				c = Rxb[i];
				dbuff[DumpAddr & 15] = ((c >= ' ')&&(c <= '^')) ? c : '.';
				switch(DumpAddr & 15) {
					case 0:
						sprintf(str, "%08X: %02X", DumpAddr, c);
						sc = 12;
						break;
					case 8:
						sprintf(str, "-%02X", c);
						sc = 3;
						break;
					case 15:
						dbuff[16] = 0;
						sprintf(str, " %02X  %s\r\n", c, dbuff);
						sc = 23;
						break;
					default:
						sprintf(str, " %02X", c);
						sc = 3;
				}
				WriteConsole(hScreen, str, sc, &d, NULL);
				if (hLog != INVALID_HANDLE_VALUE)
					WriteFile(hLog, str, sc, &d, NULL);
				DumpAddr++;
			}
		} else {	/* TTY mode */
			if (hLog != INVALID_HANDLE_VALUE)
				WriteFile(hLog, Rxb, rc, &d, NULL);
			i = 0;
			do {
				sc = 0;
				c = Rxb[i];
				if (c < ' ' && c != '\r' && c != '\n' && c != '\b' && c != '\t') {
					f = 0;
					do {
						Rxb[i + sc] += '@';
						sc++; rc--;
						c = Rxb[i + sc];
						if (c == '\a') f = 1;
					} while (rc && c < ' ' && c != '\r' && c != '\n' && c != '\b' && c != '\t');
					SetConsoleTextAttribute(hScreen, FOREGROUND_RED | FOREGROUND_GREEN);
					WriteConsole(hScreen, &Rxb[i], sc, &d, NULL);
					SetConsoleTextAttribute(hScreen, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
					if (f) MessageBeep(MB_OK);
				} else {
					do {
						sc++; rc--;
						c = Rxb[i + sc];
					} while (rc && (c >= ' ' || c == '\r' || c == '\n' || c == '\b' || c == '\t'));
					WriteConsole(hScreen, &Rxb[i], sc, &d, NULL);
				}
				i += sc;
			} while (rc);
		}
	}
	ExitRcvr = 0;
	return 0;
}



int proc_key (void)
{
	int c, kcmd, nchr, nc;
	DWORD n;
	INPUT_RECORD ir;
	static BYTE xbuf[136];
	static xsize;



	if (AutoXmit && !nTxb) {
		if (AutoXmit == TXM_BIN) {
			ReadFile(hTransmit, Txb, sizeof Txb, &nc, NULL);
			FilePtr += nc;
			if (nc) {
				nTxb = nc;
			} else {
				stop_transmisson();
			}
			set_title();
		} else {
			c = Rxc;
			if (c) {
				Rxc = 0;
				if (Xmode == 0) {
					xbuf[0] = SOH; xbuf[1] = 0;
					switch (c) {
					case NAK:
						Xmode = 1;
						c = ACK;
						break;
					case 'C':
						Xmode = 2;
						c = ACK;
						break;
					default :
						c = 0;
					}
				}
				if (c == NAK || c == ACK) {
					if (c == ACK) {
						if (xbuf[0] == EOT) {
							stop_transmisson();
							xsize = 0;
						} else {
							ReadFile(hTransmit, &xbuf[3], 128, &nc, NULL);
							FilePtr += nc;
							if (nc) {
								xbuf[1]++; xbuf[2] = ~xbuf[1];
								memset(&xbuf[3 + nc], 0, 128 - nc);
								xsize = 3 + create_sum(&xbuf[3], 128, Xmode);
							} else {
								xbuf[0] = EOT;
								xsize = 1;
							}
						}
					}
					memcpy(Txb, xbuf, xsize);
					nTxb = xsize;
					set_title();
				}
			}
		}
	}

	kcmd = 0; nchr = 0;
	for (;;) {
		PeekConsoleInput(hKey, &ir, 1, &n);
		if (n == 0) break;
		ReadConsoleInput(hKey, &ir, 1, &n);
		if (ir.EventType != KEY_EVENT) break;
		if (ir.Event.KeyEvent.bKeyDown == FALSE) break;
		c = ir.Event.KeyEvent.uChar.AsciiChar;
		if (AutoXmit) {
			if (c == '\x1b')
				kcmd = CMD_STOP_TRAN;
			continue;
		}
		if (ir.Event.KeyEvent.dwControlKeyState & (LEFT_ALT_PRESSED | RIGHT_ALT_PRESSED) ) {
			switch (tolower(c)) {
				case '0' :
					if (!nTxb) Txb[nchr++] = 0;
					break;
				case 'x' :
					kcmd = CMD_EXIT;
					break;
				case 'l' :
					kcmd = CMD_SWLOG;
					break;
				case 'b' :
					kcmd = CMD_BREAK;
					break;
				case 'h' :
					kcmd = CMD_EROFF;
					break;
				case 'v' :
					kcmd = CMD_DUMP;
					break;
				case 't' :
					kcmd = CMD_TRANSMIT;
					break;
				case 'y' :
					kcmd = CMD_XMODEM;
					break;
			}
		} else {
			if (c) {
				for (n = 500; n && nTxb; n--) Sleep(1);
				if (n) Txb[nchr++] = c;
			}
		}
	}

	if (nchr) nTxb = nchr;

	return kcmd;
}




BOOL open_port (int comport)
{
	DCB dcb;
	COMMTIMEOUTS commtimeouts = { 0, 0, 10, 1, 10};	/* Rx:10ms, Tx:10ms */
	char portname[20];


	sprintf(sPort, "COM%u", comport);
	sprintf(portname, "\\\\.\\COM%u", comport);
	hComm = CreateFile(portname, GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hComm == INVALID_HANDLE_VALUE) {
		printf("\n%s coluld not be opened.\n", sPort);
		return FALSE;
	}

	dcb.DCBlength = sizeof dcb;
	if (GetCommState(hComm, &dcb)) {
		dcb.BaudRate = comBps;
		dcb.ByteSize = comData;
		dcb.StopBits = comStop;
		dcb.Parity = comParity;
		dcb.fParity = FALSE;
		dcb.fOutxCtsFlow = (comPol & 2) ? FALSE : comCtsflow;
		dcb.fOutxDsrFlow = FALSE;
		dcb.fDtrControl = (comPol & 1) ? DTR_CONTROL_DISABLE : DTR_CONTROL_ENABLE;
		dcb.fRtsControl = (comPol & 2) ? RTS_CONTROL_DISABLE : (comCtsflow ? RTS_CONTROL_HANDSHAKE : RTS_CONTROL_ENABLE);
		dcb.fDsrSensitivity = FALSE;
		if (SetCommState(hComm, &dcb)) {
			EscapeCommFunction(hComm, (comPol & 1) ? SETDTR : CLRDTR);
			Sleep(100);
			PurgeComm(hComm, PURGE_RXABORT|PURGE_RXCLEAR);
			EscapeCommFunction(hComm, (comPol & 1) ? CLRDTR : SETDTR);
			if (comPol & 4) EscapeCommFunction(hComm, SETBREAK);
			if (SetCommTimeouts(hComm, &commtimeouts))
				return TRUE;
		}
	}

	printf("\n%s coluld not be configured in required settings.\n", sPort);
	return FALSE;
}



int get_column (char **src, char *dst, int sz)
{
	BYTE c;
	int ret = 0;


	while (1) {
		c = **src;
		if (c < ' ') break;
		(*src)++;
		if (c == ',') break;
		if (sz > 1) {
			*dst++ = c;
			sz--;
		} else {
			ret = 1;
		}
	}
	*dst++ = 0;

	return ret;
}




BOOL load_cfg(int argc, char **argv)
{
	char *cp, *sp, *cmdlst[20], cmdbuff[256], str[10];
	char inifile[_MAX_PATH], *dmy;
	int cmd, n;
	FILE *fp;


	GetCurrentDirectory(sizeof sLogFile, sLogFile);
	cp = sLogFile + strlen(sLogFile);
	if (strchr(sLogFile, '\\') != (cp-1))
		strcpy(cp, "\\*.txt");

	cmd = 0; cp = cmdbuff;

	/* Import ini file as command line parameters */

	if ((fp = fopen(INIFILE, "rt")) == NULL) {
		if (SearchPath(NULL, INIFILE, NULL, sizeof inifile, inifile, &dmy))
			fp = fopen(inifile, "rt");
	}
	if (fp != NULL) {
		while(fgets(cp, cmdbuff + sizeof cmdbuff - cp, fp) != NULL) {
			if (cmd >= (sizeof cmdlst / sizeof cmdlst[0] - 1)) break;
			if (*cp <= ' ') break;
			if ((sp = strstr(cp, "\n")) != NULL) *sp = '\0';
			cmdlst[cmd++] = cp; cp += strlen(cp) + 1;
		}
		fclose(fp);
	}

	/* Get command line parameters */
	while(--argc && (cmd < (sizeof cmdlst / sizeof cmdlst[0] - 1)))
		cmdlst[cmd++] = *++argv;
	cmdlst[cmd] = NULL;

	/* Analyze command line parameters... */
	if (cmdlst[0] == NULL) return FALSE;	/* No parameter */
	for (cmd = 0; cmdlst[cmd] != NULL; cmd++) {
		cp = cmdlst[cmd];
		if (strstr(cp, "port=") == cp) {
			cp += 5;
			get_column(&cp, str, sizeof str);
			n = atoi(str);
			if (n) comPort = n;
			get_column(&cp, str, sizeof str);
			if (str[0]) {
				if (tolower(str[0]) == 'n') comParity = NOPARITY;
				if (tolower(str[0]) == 'o') comParity = ODDPARITY;
				if (tolower(str[0]) == 'e') comParity = EVENPARITY;
				if (str[1]) {
					if (str[1] == '8') comData = 8;
					if (str[1] == '7') comData = 7;
					if (str[2]) {
						if (str[2] == '1') comStop = ONESTOPBIT;
						if (str[2] == '2') comStop = TWOSTOPBITS;
					}
				}
			}
			get_column(&cp, str, sizeof str);
			n = atoi(str);
			if (n) comBps = n;
			continue;
		}
		if (strstr(cp, "help=") == cp) {
			comHelp = atoi(cp+5);
			continue;
		}
		if (strstr(cp, "bps=") == cp) {
			n = atoi(cp+4);
			if (n) comBps = n;
			continue;
		}
		if (strstr(cp, "pol=") == cp) {
			n = atoi(cp+4);
			if (n) comPol = n;
			continue;
		}
		if (strstr(cp, "flow=") == cp) {
			if (strstr(cp+5, "on") == cp+5) comCtsflow = TRUE;
			if (strstr(cp+5, "off") == cp+5) comCtsflow = FALSE;
			continue;
		}
		if (strstr(cp, "log=") == cp) {
			hLog = CreateFile(cp+4, GENERIC_WRITE, 0, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
			if (hLog != INVALID_HANDLE_VALUE) {
				SetFilePointer(hLog, 0, NULL, FILE_END);
				GetFileTitle(cp+4, sLogFileTitle, sizeof sLogFileTitle);
			}
			continue;
		}
		return FALSE;
	} /* for */

	return TRUE;
}




int main (int argc, char **argv)
{
	DWORD n;
	int cmd;


	if (!load_cfg(argc, argv)) {
		printf(Usage1);
		printf(Usage2);
		return 3;
	}

	if (!open_port(comPort)) return 1;

	if ((hScreen = GetStdHandle(STD_OUTPUT_HANDLE)) == INVALID_HANDLE_VALUE)
		return 2;
	if ((hKey = GetStdHandle(STD_INPUT_HANDLE)) == INVALID_HANDLE_VALUE)
		return 2;
	SetConsoleMode(hKey, 0);

	hRcvrThread = CreateThread(NULL, 0, RcvrThread, 0, 0, &RcvrThreadID);
	if (hRcvrThread == INVALID_HANDLE_VALUE) {
		CloseHandle(hComm);
		return 2;
	}

	set_title();
	if (comHelp) printf(Usage2);
	GetCurrentDirectory(sizeof sOpenFile, sOpenFile);
	strcat(sOpenFile, (sOpenFile[strlen(sOpenFile) - 1] == '\\') ? "*.*" : "\\*.*");

	for (;;) {
		do {
			Sleep(1);
			cmd = proc_key();
		} while (!cmd);
		switch (cmd) {
		case CMD_EXIT:
			ExitRcvr = 1;
			for (n = 500; n && ExitRcvr; n--) Sleep(1);
			CloseHandle(hComm);
			if (hTransmit != INVALID_HANDLE_VALUE)
				CloseHandle(hTransmit);
			if (hLog != INVALID_HANDLE_VALUE)
				CloseHandle(hLog);
			return 0;
		case CMD_SWLOG:
			switch_logging();
			break;
		case CMD_TRANSMIT:
			start_transmisson(TXM_BIN);
			break;
		case CMD_XMODEM:
			start_transmisson(TXM_XMODEM);
			break;
		case CMD_EROFF:
			ComCmd = CMD_EROFF;
			break;
		case CMD_BREAK:
			ComCmd = CMD_BREAK;
			break;
		case CMD_DUMP:
			fDump = ~fDump;
			DumpAddr = 0;
			WriteConsole(hScreen, "\r\n", 2, &n, NULL);
			if (hLog != INVALID_HANDLE_VALUE)
				WriteFile(hLog, "\r\n", 2, &n, NULL);
			break;
		case CMD_STOP_TRAN:
			stop_transmisson();
		}
	}

}

