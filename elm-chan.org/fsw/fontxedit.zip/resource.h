//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Script1.rc
//
#define IDD_MAINDLG                     101
#define IDI_ICON1                       104
#define IDR_ACCELERATOR1                105
#define IDD_PVDLG                       107
#define IDC_CURSOR1                     108
#define IDR_BINARY1                     109
#define IDC_DRAW                        1001
#define IDC_EXIT                        1002
#define IDC_IMG                         1003
#define IDC_EDIT                        1003
#define IDC_LOAD                        1004
#define IDC_SAVE                        1008
#define IDC_SAVEAS                      1009
#define IDC_FW                          1022
#define IDC_CHR                         1023
#define IDC_FH                          1024
#define IDC_FHC                         1025
#define IDC_FWC                         1026
#define IDC_CLR                         1036
#define IDC_APP                         1037
#define IDC_INV                         1038
#define IDC_REV                         1039
#define IDC_INFO                        1040
#define IDC_PVC                         1041
#define IDC_ROTU                        1042
#define IDC_ROTD                        1043
#define IDC_CHAR                        1044
#define IDC_ROTR                        1045
#define IDC_ROTL                        1046
#define IDC_PREV                        1047
#define IDC_NEXT                        1048
#define IDC_COPY                        1049
#define IDC_PASTE                       1050
#define IDC_CODE                        1052
#define IDC_PVSRC                       1054
#define IDC_PVIMG                       1058
#define IDC_TAB1                        1059
#define IDC_IMP                         1060
#define IDC_EXP                         1062

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        110
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1061
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
